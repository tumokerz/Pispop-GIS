/*
 * ============================================================
 * PISPOP-GIS
 * address-system.js
 *
 * Система адресации домов на основе улиц.
 *
 * - Каждая улица может иметь дома
 * - Дома нумеруются автоматически
 * - При клике на дом показывается карточка с адресом
 * - Групповое добавление домов (клик по улице -> заполнение вдоль линии)
 *
 * ============================================================
 */

(function () {
    "use strict";

    console.log("[PISPOP-GIS] address-system.js loading...");

    let map = null;
    let addressSource = null;
    let addressLayer = null;
    let houseTerritorySource = null;
    let houseTerritoryLayer = null;

    let houses = [];
    let selectedHouse = null;

    let addHouseMode = false;
    let selectedStreetId = null;

    // Режим группового добавления домов
    let bulkAddMode = false;
    let bulkAddStreetId = null;
    let bulkAddPoints = [];
    let bulkAddHandler = null;
    let dblClickHandler = null;

    // Состояние карточки
    // (плавающая карточка дома убрана - карточка теперь всегда в
    //  боковой панели, см. ui.js: openViewCard("house", ...))

    const DEFAULT_HOUSE_COLOR = "#e8c35c";

    /* =========================================================
       КАРТА
       ========================================================= */

    function getMap() {
        if (window.unmined && window.unmined.map && typeof window.unmined.map.getView === "function") {
            return window.unmined.map;
        }
        if (window.unmined && window.unmined.olMap && typeof window.unmined.olMap.getView === "function") {
            return window.unmined.olMap;
        }
        if (window.unmined) {
            const keys = Object.keys(window.unmined);
            for (let i = 0; i < keys.length; i++) {
                const value = window.unmined[keys[i]];
                if (value && typeof value.getView === "function" && typeof value.addLayer === "function") {
                    return value;
                }
            }
        }
        return null;
    }

    function toDataCoordinate(viewCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return viewCoordinate;
        }
        return ol.proj.transform(viewCoordinate, window.unmined.viewProjection, window.unmined.dataProjection);
    }

    function toViewCoordinate(dataCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return dataCoordinate;
        }
        return ol.proj.transform(dataCoordinate, window.unmined.dataProjection, window.unmined.viewProjection);
    }

    /* =========================================================
       ГЕНЕРАЦИЯ ID
       ========================================================= */

    function generateId() {
        return "house-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 8);
    }

    /* =========================================================
       ЗАГРУЗКА / СОХРАНЕНИЕ ДОМОВ
       ========================================================= */

    async function loadHouses() {
        try {
            const response = await fetch("/api/houses", { cache: "no-cache" });
            if (!response.ok) {
                houses = [];
                return houses;
            }
            const data = await response.json();
            houses = Array.isArray(data) ? data : [];
            console.log("[PISPOP-GIS] Houses loaded:", houses.length);
            return houses;
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot load houses:", error);
            houses = [];
            return houses;
        }
    }

    async function saveHouses() {
        try {
            const response = await fetch("/api/houses", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(houses)
            });
            if (!response.ok) throw new Error("HTTP " + response.status);
            console.log("[PISPOP-GIS] Houses saved:", houses.length);
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot save houses:", error);
        }
    }

    /* =========================================================
       СТИЛЬ ДОМА
       ========================================================= */

    function houseStyle(feature) {
        const house = feature.get("houseData");
        const isSelected = feature.get("selected");

        const number = (house && house.number) || "?";

        return new ol.style.Style({
            // Невидимый круг увеличивает область клика вокруг цифры
            // дома, иначе попасть точно по тексту очень сложно.
            image: new ol.style.Circle({
                radius: 10,
                fill: new ol.style.Fill({ color: "rgba(0,0,0,0.001)" })
            }),
            text: new ol.style.Text({
                text: String(number),
                font: isSelected
                    ? "800 16px 'Inter', Arial, sans-serif"
                    : "700 13px 'Inter', Arial, sans-serif",
                textAlign: "center",
                textBaseline: "middle",
                fill: new ol.style.Fill({
                    color: isSelected ? "#ff6b6b" : "#1f2430"
                }),
                stroke: new ol.style.Stroke({
                    color: "rgba(255,255,255,0.9)",
                    width: 3
                })
            }),
            zIndex: isSelected ? 100 : 10
        });
    }

    /* =========================================================
       ОТРИСОВКА ДОМОВ
       ========================================================= */

    function renderHouses() {
        if (!addressSource) return;
        addressSource.clear();

        houses.forEach(function (house) {
            if (typeof house.x !== "number" || typeof house.z !== "number") return;

            const feature = new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate([house.x, house.z])),
                houseData: house,
                selected: selectedHouse && selectedHouse.id === house.id
            });

            addressSource.addFeature(feature);
        });

        renderHouseTerritories();
    }

    /* =========================================================
       ГРАНИЦЫ (ТЕРРИТОРИИ) ДОМОВ
       ========================================================= */

    function houseTerritoryStyle(feature) {
        const isSelected = feature.get("selected");
        return new ol.style.Style({
            fill: new ol.style.Fill({
                color: isSelected ? "rgba(60,110,246,0.18)" : "rgba(232,195,92,0.18)"
            }),
            stroke: new ol.style.Stroke({
                color: isSelected ? "#3c6ef6" : "#c99a2e",
                width: isSelected ? 2.5 : 1.5,
                lineDash: isSelected ? undefined : [4, 4]
            }),
            zIndex: isSelected ? 90 : 5
        });
    }

    function renderHouseTerritories() {
        if (!houseTerritorySource) return;
        houseTerritorySource.clear();

        // Границу рисуем только у выбранного (открытого в карточке)
        // дома - у остальных она скрыта, чтобы не загромождать карту.
        if (!selectedHouse || !selectedHouse.territory) {
            return;
        }

        if (!Array.isArray(selectedHouse.territory) || selectedHouse.territory.length < 3) {
            return;
        }

        const ring = selectedHouse.territory.map(function (pt) {
            return toViewCoordinate(pt);
        });

        const feature = new ol.Feature({
            geometry: new ol.geom.Polygon([ring]),
            houseTerritoryData: selectedHouse,
            selected: true
        });

        houseTerritorySource.addFeature(feature);
    }

    async function setHouseTerritory(house, coordinates) {
        house.territory = coordinates;
        renderHouseTerritories();

        houses = houses.map(function (h) {
            return h.id === house.id ? house : h;
        });

        try {
            await saveHouses();
            showToast("Граница дома сохранена", "success");
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot save house territory:", error);
            showToast("Не удалось сохранить границу", "error");
        }

        if (selectedHouse && selectedHouse.id === house.id) {
            document.dispatchEvent(new CustomEvent("pispop:house-selected", {
                detail: house
            }));
        }
    }

    async function clearHouseTerritory(house) {
        house.territory = null;
        renderHouseTerritories();

        houses = houses.map(function (h) {
            return h.id === house.id ? house : h;
        });

        try {
            await saveHouses();
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot clear house territory:", error);
        }

        if (selectedHouse && selectedHouse.id === house.id) {
            document.dispatchEvent(new CustomEvent("pispop:house-selected", {
                detail: house
            }));
        }
    }

    /* =========================================================
       СОЗДАНИЕ СЛОЯ
       ========================================================= */

    function createAddressLayer() {
        if (!map) return false;

        houseTerritorySource = new ol.source.Vector();
        houseTerritoryLayer = new ol.layer.Vector({
            source: houseTerritorySource,
            zIndex: 149000,
            style: houseTerritoryStyle
        });
        map.addLayer(houseTerritoryLayer);

        addressSource = new ol.source.Vector();
        addressLayer = new ol.layer.Vector({
            source: addressSource,
            zIndex: 150000,
            style: houseStyle
        });

        map.addLayer(addressLayer);
        return true;
    }

    /* =========================================================
       ВИДИМОСТЬ ПО ЗУМУ
       ========================================================= */

    const HOUSE_VISIBLE_MIN_LEVEL = 1;
    const HOUSE_VISIBLE_MAX_LEVEL = 2;

    function getMaxZoom() {
        if (!map) return null;
        const view = map.getView();
        if (!view) return null;
        const maxZoom = view.getMaxZoom();
        return (typeof maxZoom === "number" && Number.isFinite(maxZoom)) ? maxZoom : null;
    }

    function updateVisibilityByZoom() {
        if (!map || !addressLayer) return;

        const view = map.getView();
        if (!view) return;

        const zoom = view.getZoom();
        const maxZoom = getMaxZoom();

        if (
            typeof zoom !== "number" ||
            !Number.isFinite(zoom) ||
            typeof maxZoom !== "number"
        ) {
            addressLayer.setVisible(false);
            return;
        }

        const userLevel = maxZoom - zoom + 1;

        const shouldShow =
            userLevel >= HOUSE_VISIBLE_MIN_LEVEL &&
            userLevel <= HOUSE_VISIBLE_MAX_LEVEL;

        addressLayer.setVisible(shouldShow);
    }

    /* =========================================================
       ВЫБОР ДОМА КЛИКОМ
       ========================================================= */

    function setupHouseSelection() {
        if (!map) return;

        map.on("singleclick", function (event) {
            if (addHouseMode || bulkAddMode) return;
            if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking()) return;

            let clickedHouse = null;

            map.forEachFeatureAtPixel(event.pixel, function (feature, layer) {
                if (layer !== addressLayer) return false;
                const house = feature.get("houseData");
                if (house) {
                    clickedHouse = house;
                    return true;
                }
                return false;
            }, { hitTolerance: 12 });

            if (clickedHouse) {
                selectHouse(clickedHouse);
            } else {
                // Закрываем карточку только если клик не по карточке
                if (!event.target || !event.target.closest) {
                    deselectHouse();
                }
            }
        });
    }

    function selectHouse(house) {
        // Если уже выбран этот же дом - ничего не делаем,
        // карточка уже отображается в боковой панели.
        if (selectedHouse && selectedHouse.id === house.id) {
            return;
        }

        selectedHouse = house;
        renderHouses();

        // ===== ДОБАВЛЯЕМ STREETNAME ДЛЯ КАРТОЧКИ =====
        if (house && window.PISPOP_STREETS) {
            const streets = window.PISPOP_STREETS.getStreets();
            const street = streets.find(function (s) { return s.id === house.streetId; });
            if (street) {
                house.streetName = street.name;
            }
        }

        document.dispatchEvent(new CustomEvent("pispop:house-selected", {
            detail: house
        }));
    }

    function deselectHouse() {
        if (!selectedHouse) return;
        selectedHouse = null;
        renderHouses();

        document.dispatchEvent(new CustomEvent("pispop:house-deselected"));
    }

    async function deleteHouse(house) {
        try {
            const response = await fetch("/api/houses/" + encodeURIComponent(house.id), {
                method: "DELETE"
            });

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            houses = houses.filter(function (h) {
                return h.id !== house.id;
            });

            renderHouses();
            deselectHouse();

            showToast("Дом удалён", "success");
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot delete house:", error);
            showToast("Не удалось удалить дом", "error");
        }
    }

    /* =========================================================
       КАРТОЧКА ДОМА показывается в боковой панели (см. ui.js,
       openViewCard) через события pispop:house-selected /
       pispop:house-deselected - отдельного плавающего окна
       больше нет.
       ========================================================= */

    /* =========================================================
       РЕЖИМ ДОБАВЛЕНИЯ ОДНОГО ДОМА
       ========================================================= */

    function startAddHouse(streetId) {
        if (!streetId) {
            console.warn("No street selected for house placement");
            showToast("Сначала выберите улицу", "error");
            return;
        }

        if (bulkAddMode) {
            stopBulkAdd();
        }

        // Закрываем карточку при начале добавления
        deselectHouse();

        addHouseMode = true;
        selectedStreetId = streetId;

        if (map) {
            map.getViewport().style.cursor = "crosshair";
        }

        document.dispatchEvent(new CustomEvent("pispop:add-house-mode", {
            detail: { active: true, streetId: streetId }
        }));

        showToast("Кликните на карту, чтобы поставить дом", "success");
        console.log("[PISPOP-GIS] Add house mode started for street:", streetId);
    }

    function stopAddHouse() {
        addHouseMode = false;
        selectedStreetId = null;

        if (map) {
            map.getViewport().style.cursor = "";
        }

        document.dispatchEvent(new CustomEvent("pispop:add-house-mode", {
            detail: { active: false }
        }));

        const hint = document.getElementById("adding-hint");
        if (hint) hint.classList.add("hidden");
    }

    /* =========================================================
       РЕЖИМ ГРУППОВОГО ДОБАВЛЕНИЯ ДОМОВ
       ========================================================= */

    function startBulkAdd(streetId) {
        if (!streetId) {
            showToast("Сначала выберите улицу", "error");
            return;
        }

        if (addHouseMode) {
            stopAddHouse();
        }

        // Закрываем карточку при начале добавления
        deselectHouse();

        bulkAddMode = true;
        bulkAddStreetId = streetId;
        bulkAddPoints = [];

        if (map) {
            map.getViewport().style.cursor = "crosshair";
        }

        showBulkAddHint();

        if (bulkAddHandler) {
            map.un("click", bulkAddHandler);
        }
        if (dblClickHandler) {
            map.un("dblclick", dblClickHandler);
        }

        bulkAddHandler = function (event) {
            if (!bulkAddMode) return;

            const dataCoord = toDataCoordinate(event.coordinate);
            const x = Math.round(dataCoord[0]);
            const z = Math.round(dataCoord[1]);

            bulkAddPoints.push([x, z]);
            showBulkAddPoints();

            console.log("[PISPOP-GIS] Bulk add point:", x, z);
        };

        dblClickHandler = function (event) {
            if (!bulkAddMode) return;
            event.preventDefault();
            finishBulkAdd();
        };

        map.on("click", bulkAddHandler);
        map.on("dblclick", dblClickHandler);

        document.dispatchEvent(new CustomEvent("pispop:bulk-add-mode", {
            detail: { active: true, streetId: streetId }
        }));

        showToast("Кликайте по карте для добавления точек. Двойной клик - завершить", "success");
        console.log("[PISPOP-GIS] Bulk add mode started for street:", streetId);
    }

    function showBulkAddPoints() {
        let tempSource = window._bulkAddTempSource;
        let tempLayer = window._bulkAddTempLayer;

        if (!tempSource) {
            tempSource = new ol.source.Vector();
            tempLayer = new ol.layer.Vector({
                source: tempSource,
                zIndex: 160000,
                style: new ol.style.Style({
                    image: new ol.style.Circle({
                        radius: 6,
                        fill: new ol.style.Fill({ color: "#ff6b6b" }),
                        stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
                    })
                })
            });
            map.addLayer(tempLayer);
            window._bulkAddTempSource = tempSource;
            window._bulkAddTempLayer = tempLayer;
        }

        tempSource.clear();

        bulkAddPoints.forEach(function (point) {
            const feature = new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate(point))
            });
            tempSource.addFeature(feature);
        });

        if (bulkAddPoints.length >= 2) {
            const line = new ol.Feature({
                geometry: new ol.geom.LineString(
                    bulkAddPoints.map(toViewCoordinate)
                )
            });
            line.setStyle(new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: "#ff6b6b",
                    width: 2,
                    lineDash: [6, 6]
                })
            }));
            tempSource.addFeature(line);
        }
    }

    function clearBulkAddPoints() {
        if (window._bulkAddTempSource) {
            window._bulkAddTempSource.clear();
        }
    }

    function showBulkAddHint() {
        let hint = document.getElementById("bulk-add-hint");
        if (hint) return;

        hint = document.createElement("div");
        hint.id = "bulk-add-hint";
        hint.innerHTML = `
            <strong>🏠 Групповое добавление домов</strong><br>
            Кликайте по карте вдоль улицы.<br>
            Дома будут расставлены через равные промежутки.<br>
            <span>Двойной клик — завершить.</span>
            <br><br>
            <button id="bulk-add-finish" style="padding:8px 16px;border:none;border-radius:6px;background:#3c6ef6;color:#fff;cursor:pointer;font-weight:600;">Готово</button>
            <button id="bulk-add-cancel" style="padding:8px 16px;border:none;border-radius:6px;background:#e5484d;color:#fff;cursor:pointer;font-weight:600;">Отмена</button>
        `;

        hint.style.position = "fixed";
        hint.style.left = "50%";
        hint.style.bottom = "25px";
        hint.style.transform = "translateX(-50%)";
        hint.style.zIndex = "99999";
        hint.style.padding = "16px 20px";
        hint.style.borderRadius = "12px";
        hint.style.background = "rgba(25,25,25,.95)";
        hint.style.color = "#fff";
        hint.style.fontFamily = "'Inter', Arial, sans-serif";
        hint.style.fontSize = "14px";
        hint.style.boxShadow = "0 8px 32px rgba(0,0,0,.4)";
        hint.style.display = "flex";
        hint.style.flexDirection = "column";
        hint.style.alignItems = "center";
        hint.style.gap = "8px";
        hint.style.minWidth = "240px";

        document.body.appendChild(hint);

        document.getElementById("bulk-add-finish").addEventListener("click", finishBulkAdd);
        document.getElementById("bulk-add-cancel").addEventListener("click", cancelBulkAdd);
    }

    function removeBulkAddHint() {
        const hint = document.getElementById("bulk-add-hint");
        if (hint) hint.remove();
    }

    function finishBulkAdd() {
        if (bulkAddPoints.length < 2) {
            showToast("Нужно минимум 2 точки", "error");
            return;
        }

        let streetName = "Улица";
        if (window.PISPOP_STREETS) {
            const streets = window.PISPOP_STREETS.getStreets();
            const street = streets.find(function (s) {
                return s.id === bulkAddStreetId;
            });
            if (street) {
                streetName = street.name;
            }
        }

        const totalHouses = prompt("Сколько домов добавить?", "10");
        if (totalHouses === null) {
            cancelBulkAdd();
            return;
        }

        const count = parseInt(totalHouses);
        if (isNaN(count) || count < 1) {
            showToast("Введите число больше 0", "error");
            return;
        }

        const streetHouses = houses.filter(function (h) {
            return h.streetId === bulkAddStreetId;
        });
        let nextNumber = streetHouses.length + 1;

        const points = interpolatePoints(bulkAddPoints, count);

        const newHouses = [];
        points.forEach(function (point) {
            const house = {
                id: generateId(),
                streetId: bulkAddStreetId,
                streetName: streetName,
                number: nextNumber++,
                x: point[0],
                z: point[1],
                color: DEFAULT_HOUSE_COLOR,
                createdAt: new Date().toISOString()
            };
            newHouses.push(house);
        });

        houses = houses.concat(newHouses);
        saveHouses();
        renderHouses();

        clearBulkAddPoints();
        stopBulkAdd();

        showToast("Добавлено " + newHouses.length + " домов на " + streetName, "success");
        console.log("[PISPOP-GIS] Bulk added:", newHouses.length, "houses");
    }

    function interpolatePoints(points, count) {
        if (points.length < 2) return points;

        let totalLength = 0;
        const lengths = [];
        for (let i = 1; i < points.length; i++) {
            const dx = points[i][0] - points[i-1][0];
            const dz = points[i][1] - points[i-1][1];
            const len = Math.sqrt(dx*dx + dz*dz);
            lengths.push(len);
            totalLength += len;
        }

        if (totalLength === 0) return points;

        const step = totalLength / (count - 1);

        const result = [];
        let accumulated = 0;
        let idx = 0;

        for (let i = 0; i < count; i++) {
            const target = i * step;

            let acc = 0;
            let segIdx = 0;
            for (let j = 0; j < lengths.length; j++) {
                if (acc + lengths[j] >= target || j === lengths.length - 1) {
                    segIdx = j;
                    break;
                }
                acc += lengths[j];
            }

            const remaining = target - acc;
            const segLen = lengths[segIdx] || 1;
            const t = Math.min(1, Math.max(0, remaining / segLen));

            const x1 = points[segIdx][0];
            const z1 = points[segIdx][1];
            const x2 = points[segIdx + 1][0];
            const z2 = points[segIdx + 1][1];

            result.push([
                Math.round(x1 + (x2 - x1) * t),
                Math.round(z1 + (z2 - z1) * t)
            ]);
        }

        return result;
    }

    function cancelBulkAdd() {
        stopBulkAdd();
        clearBulkAddPoints();
        showToast("Групповое добавление отменено");
    }

    function stopBulkAdd() {
        bulkAddMode = false;
        bulkAddStreetId = null;
        bulkAddPoints = [];

        if (bulkAddHandler && map) {
            map.un("click", bulkAddHandler);
            bulkAddHandler = null;
        }
        if (dblClickHandler && map) {
            map.un("dblclick", dblClickHandler);
            dblClickHandler = null;
        }

        if (map) {
            map.getViewport().style.cursor = "";
        }

        removeBulkAddHint();
        clearBulkAddPoints();

        document.dispatchEvent(new CustomEvent("pispop:bulk-add-mode", {
            detail: { active: false }
        }));
    }

    /* =========================================================
       ОБРАБОТЧИК КЛИКОВ ДЛЯ ДОБАВЛЕНИЯ
       ========================================================= */

    function setupHousePlacement() {
        if (!map) return;

        map.on("singleclick", function (event) {
            if (!addHouseMode || !selectedStreetId) return;

            const dataCoord = toDataCoordinate(event.coordinate);
            const x = Math.round(dataCoord[0]);
            const z = Math.round(dataCoord[1]);

            let streetName = "Улица";
            if (window.PISPOP_STREETS) {
                const streets = window.PISPOP_STREETS.getStreets();
                const street = streets.find(function (s) {
                    return s.id === selectedStreetId;
                });
                if (street) {
                    streetName = street.name;
                }
            }

            const streetHouses = houses.filter(function (h) {
                return h.streetId === selectedStreetId;
            });

            const nextNumber = streetHouses.length + 1;

            const newHouse = {
                id: generateId(),
                streetId: selectedStreetId,
                streetName: streetName,
                number: nextNumber,
                x: x,
                z: z,
                color: DEFAULT_HOUSE_COLOR,
                createdAt: new Date().toISOString()
            };

            houses.push(newHouse);
            saveHouses();
            renderHouses();

            selectHouse(newHouse);
            stopAddHouse();

            showToast("Дом №" + newHouse.number + " добавлен на " + newHouse.streetName, "success");
            console.log("[PISPOP-GIS] House created:", newHouse);
        });
    }

    /* =========================================================
       ИНТЕГРАЦИЯ С ВЫБОРОМ УЛИЦЫ
       ========================================================= */

    function setupStreetIntegration() {
        document.addEventListener("pispop:street-selected", function (event) {
            const street = event.detail;
            if (street) {
                console.log("[PISPOP-GIS] Street selected for houses:", street.name);
                // Закрываем карточку дома при выборе улицы
                deselectHouse();
            }
        });
    }

    /* =========================================================
       КНОПКИ
       ========================================================= */

    function setupButtons() {
        const addHouseBtn = document.getElementById("tool-add-house");
        if (addHouseBtn) {
            const newBtn = addHouseBtn.cloneNode(true);
            addHouseBtn.parentNode.replaceChild(newBtn, addHouseBtn);

            newBtn.addEventListener("click", function () {
                if (addHouseMode) {
                    stopAddHouse();
                    newBtn.classList.remove("active");
                    return;
                }

                if (bulkAddMode) {
                    stopBulkAdd();
                    const bulkBtn = document.getElementById("tool-bulk-add-houses");
                    if (bulkBtn) bulkBtn.classList.remove("active");
                }

                if (!window.PISPOP_STREETS) {
                    showToast("Система улиц недоступна", "error");
                    return;
                }

                const streets = window.PISPOP_STREETS.getStreets();
                if (!streets || streets.length === 0) {
                    showToast("Сначала создайте улицу", "error");
                    return;
                }

                const selectedStreet = window.PISPOP_STREETS.getSelectedStreet();
                if (!selectedStreet) {
                    showToast("Сначала выберите улицу на карте", "error");
                    return;
                }

                startAddHouse(selectedStreet.id);
                newBtn.classList.add("active");
            });
        }

        const bulkAddBtn = document.getElementById("tool-bulk-add-houses");
        if (bulkAddBtn) {
            const newBtn = bulkAddBtn.cloneNode(true);
            bulkAddBtn.parentNode.replaceChild(newBtn, bulkAddBtn);

            newBtn.addEventListener("click", function () {
                if (bulkAddMode) {
                    stopBulkAdd();
                    newBtn.classList.remove("active");
                    return;
                }

                if (addHouseMode) {
                    stopAddHouse();
                    const singleBtn = document.getElementById("tool-add-house");
                    if (singleBtn) singleBtn.classList.remove("active");
                }

                if (!window.PISPOP_STREETS) {
                    showToast("Система улиц недоступна", "error");
                    return;
                }

                const streets = window.PISPOP_STREETS.getStreets();
                if (!streets || streets.length === 0) {
                    showToast("Сначала создайте улицу", "error");
                    return;
                }

                const selectedStreet = window.PISPOP_STREETS.getSelectedStreet();
                if (!selectedStreet) {
                    showToast("Сначала выберите улицу на карте", "error");
                    return;
                }

                startBulkAdd(selectedStreet.id);
                newBtn.classList.add("active");
            });
        }
    }

    /* =========================================================
       ТОСТЫ
       ========================================================= */

    function showToast(text, type) {
        if (typeof Toastify === "function") {
            Toastify({
                text: text,
                duration: 2500,
                gravity: "bottom",
                position: "center",
                close: true,
                style: {
                    background: type === "error" ? "#c62828" :
                                type === "success" ? "#2e7d32" : "#333"
                }
            }).showToast();
        } else {
            console.log("[PISPOP-GIS]", text);
        }
    }

    /* =========================================================
       ИНИЦИАЛИЗАЦИЯ
       ========================================================= */

    async function initAddressSystem() {
        console.log("[PISPOP-GIS] Initializing address system...");

        map = getMap();
        if (!map) {
            console.error("[PISPOP-GIS] Map not found");
            return;
        }

        if (!createAddressLayer()) {
            console.error("[PISPOP-GIS] Failed to create address layer");
            return;
        }

        const view = map.getView();
        if (view) {
            view.on("change:resolution", updateVisibilityByZoom);
        }
        updateVisibilityByZoom();

        await loadHouses();
        renderHouses();

        setupHouseSelection();
        setupHousePlacement();
        setupStreetIntegration();
        setupButtons();

        console.log("[PISPOP-GIS] Address system initialized with", houses.length, "houses");
    }

    /* =========================================================
       ПУБЛИЧНЫЙ API
       ========================================================= */

    window.PISPOP_ADDRESS = {
        getHouses: function () { return houses; },
        getHouse: function (id) { return houses.find(function (h) { return h.id === id; }); },
        addHouse: startAddHouse,
        stopAdding: stopAddHouse,
        bulkAdd: startBulkAdd,
        stopBulkAdd: stopBulkAdd,
        refresh: function () {
            return loadHouses().then(function () {
                renderHouses();
            });
        },
        isAddingMode: function () { return addHouseMode; },
        isBulkMode: function () { return bulkAddMode; },
        selectHouse: selectHouse,
        deselectHouse: deselectHouse,
        deleteHouse: deleteHouse,
        setHouseTerritory: setHouseTerritory,
        clearHouseTerritory: clearHouseTerritory,
        hasHouseAtPixel: function (pixel) {
            if (!map || !addressLayer) return false;
            let found = false;
            map.forEachFeatureAtPixel(pixel, function (feature, layer) {
                if (layer !== addressLayer) return false;
                if (feature.get("houseData")) {
                    found = true;
                    return true;
                }
                return false;
            }, { hitTolerance: 12 });
            return found;
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initAddressSystem);
    } else {
        initAddressSystem();
    }

})();