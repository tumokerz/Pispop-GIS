/* PISPOP-GIS — заглушка мини-игры Геогессер */
(function(){
    "use strict";

    document.addEventListener("DOMContentLoaded", function(){
        var start = document.getElementById("geoguess-start");
        var next = document.getElementById("geoguess-next");
        var close = document.getElementById("geoguess-close");
        var game = document.getElementById("geoguess-game");
        var status = document.getElementById("geoguess-status");

        if (game) game.classList.add("hidden");
        if (next) next.classList.add("hidden");
        if (close) close.classList.add("hidden");

        if (start) {
            start.textContent = "Появится позже";
            start.disabled = true;
        }

        var title = document.querySelector("#panel-minigames .minigame-title");
        if (title) title.textContent = "🌍 Геогессер пока находится в разработке";
        if (status) status.textContent = "Геогессер появится позже.";
    });
})();
