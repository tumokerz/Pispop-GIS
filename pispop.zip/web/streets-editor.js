/*
 * ============================================================
 * PISPOP-GIS
 * streets-editor.js
 *
 * Редактор улиц и тропинок для адресации домов.
 * 
 * - Отдельный слой для улиц (не путать с ледяными дорогами)
 * - Улицы имеют названия
 * - На улицы можно добавлять дома с номерами
 * - Синхронизация с address-system.js
 *
 * ============================================================
 */

(function () {
    "use strict";

    console.log("[PISPOP-GIS] streets-editor.js loading...");

    const STREETS_FILE = "streets.json";
    const DEFAULT_STREET_COLOR = "#e8a87c";
    const SELECTED_STREET_COLOR = "#ff6b6b";

    let map = null;
    let streetSource = null;
    let streetLayer = null;

    let streetsData = {
        version: 1,
        streets: []
    };

    let streetsLoaded = false;
    let editorEnabled = false;
    let drawingStreet = false;
    let currentStreetCoordinates = [];
    let selectedStreet = null;
    let clickHandler = null;

    let addHouseMode = false;
    let selectedStreetId = null;

    /* =========================================================
       КАРТА И КООРДИНАТЫ
       ========================================================= */

    function getMap() {
        if (window.unmined && window.unmined.map && typeof window.unmined.map.getView === "function") {
            return window.unmined.map;
        }
        if (window.unmined && window.unmined.olMap && typeof window.unmined.olMap.getView === "function") {
            return window.unmined.olMap;
        }
        if (window.unmined) {
            const keys = Object.keys(window.unmined);
            for (let i = 0; i < keys.length; i++) {
                const value = window.unmined[keys[i]];
                if (value && typeof value.getView === "function" && typeof value.addLayer === "function") {
                    return value;
                }
            }
        }
        return null;
    }

    function toDataCoordinate(viewCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return viewCoordinate;
        }
        return ol.proj.transform(viewCoordinate, window.unmined.viewProjection, window.unmined.dataProjection);
    }

    function toViewCoordinate(dataCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return dataCoordinate;
        }
        return ol.proj.transform(dataCoordinate, window.unmined.dataProjection, window.unmined.viewProjection);
    }

    /* =========================================================
       ЗАГРУЗКА УЛИЦ
       ========================================================= */

    async function loadStreets() {
        try {
            const response = await fetch("/api/streets", { cache: "no-cache" });
            if (!response.ok) throw new Error("HTTP " + response.status);
            const data = await response.json();
            streetsData = data;
            if (!Array.isArray(streetsData.streets)) {
                streetsData.streets = [];
            }
            streetsLoaded = true;
            console.log("[PISPOP-GIS] Streets loaded:", streetsData.streets.length);
            return true;
        } catch (error) {
            streetsLoaded = false;
            console.error("[PISPOP-GIS] Cannot load streets:", error);
            streetsData.streets = [];
            return false;
        }
    }

    async function saveStreetsToServer() {
        try {
            const response = await fetch("/api/streets", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(streetsData)
            });
            if (!response.ok) throw new Error("HTTP " + response.status);
            console.log("[PISPOP-GIS] Streets saved");
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot save streets:", error);
        }
    }

    function generateId() {
        return "street-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 8);
    }

    /* =========================================================
       СТИЛЬ УЛИЦЫ
       ========================================================= */

    function getStreetStyle(street) {
        const isSelected = selectedStreet && selectedStreet.id === street.id;
        const color = isSelected ? SELECTED_STREET_COLOR : (street.color || DEFAULT_STREET_COLOR);
        const width = isSelected ? 8 : 4;

        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: color,
                width: width,
                lineCap: "round",
                lineJoin: "round"
            }),
            zIndex: isSelected ? 50 : 10
        });
    }

    function getDrawingStyle() {
        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: DEFAULT_STREET_COLOR,
                width: 4,
                lineCap: "round",
                lineJoin: "round",
                lineDash: [10, 6]
            }),
            image: new ol.style.Circle({
                radius: 5,
                fill: new ol.style.Fill({ color: DEFAULT_STREET_COLOR }),
                stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
            })
        });
    }

    /* =========================================================
       ОТРИСОВКА
       ========================================================= */

    function streetToFeature(street) {
        if (!street || !Array.isArray(street.coordinates) || street.coordinates.length < 2) {
            return null;
        }

        try {
            const geometry = new ol.geom.LineString(
                street.coordinates.map(toViewCoordinate)
            );

            const feature = new ol.Feature({ geometry: geometry });
            feature.setId(street.id);
            feature.set("streetData", street);
            feature.setStyle(getStreetStyle(street));

            return feature;
        } catch (error) {
            console.error("Street conversion error:", error);
            return null;
        }
    }

    function renderStreets() {
        if (!streetSource) return;
        streetSource.clear();

        streetsData.streets.forEach(function (street) {
            const feature = streetToFeature(street);
            if (feature) {
                streetSource.addFeature(feature);
            }
        });

        console.log("[PISPOP-GIS] Rendered streets:", streetsData.streets.length);
    }

    function renderCurrentDrawing() {
        if (!drawingStreet || !streetSource) return;

        // Удаляем старую рисовалку
        // (используем отдельный источник для рисования)
    }

    /* =========================================================
       СОЗДАНИЕ СЛОЯ
       ========================================================= */

    function createStreetLayer() {
        if (!map) return false;

        streetSource = new ol.source.Vector();
        streetLayer = new ol.layer.Vector({
            source: streetSource,
            zIndex: 50000, // Между дорогами (1000) и метками (200000)
            visible: true
        });

        map.addLayer(streetLayer);
        return true;
    }

    /* =========================================================
       РЕДАКТОР УЛИЦ
       ========================================================= */

    function toggleStreetEditor() {
        editorEnabled = !editorEnabled;

        if (editorEnabled) {
            enableStreetEditor();
        } else {
            disableStreetEditor();
        }
    }

    function enableStreetEditor() {
        editorEnabled = true;
        const button = document.getElementById("tool-streets");
        if (button) {
            button.classList.add("active");
            button.textContent = "🚶 Выйти из редактора улиц";
        }
        if (streetLayer) {
            streetLayer.setVisible(true);
        }
        showToast("Редактор улиц включён", "success");
        console.log("[PISPOP-GIS] Street editor ENABLED");
    }

    function disableStreetEditor() {
        editorEnabled = false;
        stopDrawingStreet();
        const button = document.getElementById("tool-streets");
        if (button) {
            button.classList.remove("active");
            button.textContent = "🚶 Редактор улиц";
        }
        showToast("Редактор улиц выключен");
        console.log("[PISPOP-GIS] Street editor DISABLED");
    }

    /* =========================================================
       РИСОВАНИЕ УЛИЦЫ
       ========================================================= */

    function startDrawingStreet() {
        if (!editorEnabled) {
            enableStreetEditor();
        }

        if (!map) {
            map = getMap();
            if (!map) {
                showToast("Карта не найдена", "error");
                return;
            }
        }

        stopDrawingStreet();

        drawingStreet = true;
        currentStreetCoordinates = [];
        showDrawingHint();

        clickHandler = function (event) {
            if (!drawingStreet) return;

            const coordinate = toDataCoordinate(event.coordinate);
            if (!coordinate || coordinate.length < 2) return;

            currentStreetCoordinates.push([
                Math.round(coordinate[0]),
                Math.round(coordinate[1])
            ]);

            // Показываем точки на карте
            renderDrawingPoints();

            console.log("[PISPOP-GIS] Street point:", coordinate);
        };

        map.on("click", clickHandler);
        map.getViewport().style.cursor = "crosshair";

        console.log("[PISPOP-GIS] Drawing street started");
    }

    function stopDrawingStreet() {
        drawingStreet = false;

        if (map && clickHandler) {
            try {
                map.un("click", clickHandler);
            } catch (error) {}
            clickHandler = null;
            map.getViewport().style.cursor = "";
        }

        removeDrawingHint();
        clearDrawingPoints();
    }

    function renderDrawingPoints() {
        // Очищаем старые точки
        clearDrawingPoints();

        if (currentStreetCoordinates.length === 0) return;

        // Рисуем точки
        currentStreetCoordinates.forEach(function (point) {
            const feature = new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate(point))
            });
            feature.setStyle(new ol.style.Style({
                image: new ol.style.Circle({
                    radius: 6,
                    fill: new ol.style.Fill({ color: DEFAULT_STREET_COLOR }),
                    stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
                })
            }));
            streetSource.addFeature(feature);
        });

        // Рисуем линию
        if (currentStreetCoordinates.length >= 2) {
            const line = new ol.Feature({
                geometry: new ol.geom.LineString(
                    currentStreetCoordinates.map(toViewCoordinate)
                )
            });
            line.setStyle(getDrawingStyle());
            streetSource.addFeature(line);
        }
    }

    function clearDrawingPoints() {
        // Удаляем все фичи, которые не являются сохранёнными улицами
        const features = streetSource.getFeatures();
        const toRemove = features.filter(function (f) {
            return !f.get("streetData");
        });
        toRemove.forEach(function (f) {
            streetSource.removeFeature(f);
        });
    }

    function finishDrawingStreet() {
        if (currentStreetCoordinates.length < 2) {
            showToast("Нужно поставить минимум 2 точки", "error");
            return;
        }

        // Запрашиваем название улицы
        const streetName = prompt("Введите название улицы:", "Новая улица");
        if (streetName === null) {
            // Отмена
            cancelDrawingStreet();
            return;
        }

        const newStreet = {
            id: generateId(),
            name: streetName.trim() || "Безымянная улица",
            coordinates: currentStreetCoordinates.map(function (p) { return [p[0], p[1]]; }),
            color: DEFAULT_STREET_COLOR,
            createdAt: new Date().toISOString()
        };

        streetsData.streets.push(newStreet);

        stopDrawingStreet();
        currentStreetCoordinates = [];

        renderStreets();
        saveStreetsToServer();

        // Выбираем созданную улицу
        selectStreet(newStreet.id);

        showToast("Улица \"" + newStreet.name + "\" создана", "success");
        console.log("[PISPOP-GIS] Street created:", newStreet);
    }

    function cancelDrawingStreet() {
        stopDrawingStreet();
        currentStreetCoordinates = [];
        clearDrawingPoints();
        showToast("Рисование отменено");
    }

    /* =========================================================
       ПОДСКАЗКА
       ========================================================= */

    function showDrawingHint() {
        let hint = document.getElementById("street-editor-hint");
        if (hint) return;

        hint = document.createElement("div");
        hint.id = "street-editor-hint";
        hint.innerHTML = `
            <strong>🚶 Редактор улиц</strong><br>
            Кликайте по карте для добавления точек.<br>
            <span>Двойной клик — завершить улицу.</span>
            <br><br>
            <button id="street-finish-btn">Готово</button>
            <button id="street-cancel-btn">Отмена</button>
        `;

        hint.style.position = "fixed";
        hint.style.left = "50%";
        hint.style.bottom = "25px";
        hint.style.transform = "translateX(-50%)";
        hint.style.zIndex = "99999";
        hint.style.padding = "12px 16px";
        hint.style.borderRadius = "10px";
        hint.style.background = "rgba(25,25,25,.95)";
        hint.style.color = "#fff";
        hint.style.fontFamily = "Arial,sans-serif";
        hint.style.fontSize = "14px";
        hint.style.boxShadow = "0 5px 25px rgba(0,0,0,.35)";

        document.body.appendChild(hint);

        document.getElementById("street-finish-btn").addEventListener("click", finishDrawingStreet);
        document.getElementById("street-cancel-btn").addEventListener("click", cancelDrawingStreet);
    }

    function removeDrawingHint() {
        const hint = document.getElementById("street-editor-hint");
        if (hint) hint.remove();
    }

    /* =========================================================
       ВЫБОР УЛИЦЫ
       ========================================================= */

    function setupStreetSelection() {
        if (!map) return;

        map.on("singleclick", function (event) {
            if (drawingStreet) return;
            if (!streetLayer) return;

            let clickedStreet = null;

            map.forEachFeatureAtPixel(event.pixel, function (feature, layer) {
                if (layer !== streetLayer) return false;
                const street = feature.get("streetData");
                if (street) {
                    clickedStreet = street;
                    return true;
                }
                return false;
            });

            if (clickedStreet) {
                selectStreet(clickedStreet.id);
            } else {
                deselectStreet();
            }
        });
    }

    function selectStreet(id) {
        const street = streetsData.streets.find(function (s) {
            return s.id === id;
        });

        if (!street) return;

        selectedStreet = street;
        renderStreets();

        // Отправляем событие для адресной системы
        document.dispatchEvent(new CustomEvent("pispop:street-selected", {
            detail: street
        }));

        // Показываем карточку улицы
        showStreetCard(street);

        console.log("[PISPOP-GIS] Street selected:", street.name);
    }

    function deselectStreet() {
        selectedStreet = null;
        renderStreets();
        hideStreetCard();

        document.dispatchEvent(new CustomEvent("pispop:street-deselected"));

        console.log("[PISPOP-GIS] Street deselected");
    }

    /* =========================================================
       КАРТОЧКА УЛИЦЫ
       ========================================================= */

    function showStreetCard(street) {
        let card = document.getElementById("street-card");
        if (!card) {
            card = document.createElement("div");
            card.id = "street-card";
            document.body.appendChild(card);

            card.style.position = "fixed";
            card.style.bottom = "80px";
            card.style.left = "50%";
            card.style.transform = "translateX(-50%)";
            card.style.zIndex = "99998";
            card.style.background = "#fff";
            card.style.borderRadius = "16px";
            card.style.padding = "20px 24px";
            card.style.boxShadow = "0 8px 32px rgba(0,0,0,0.3)";
            card.style.minWidth = "280px";
            card.style.maxWidth = "400px";
            card.style.fontFamily = "'Inter', Arial, sans-serif";
            card.style.border = "1px solid #e3e5e9";
        }

        // Считаем дома на этой улице
        let housesCount = 0;
        if (window.PISPOP_ADDRESS) {
            const allHouses = window.PISPOP_ADDRESS.getHouses();
            housesCount = allHouses.filter(function (h) {
                return h.streetId === street.id;
            }).length;
        }

        card.innerHTML = `
            <div class="street-card-header">
                <span class="street-card-name">🚶 ${street.name}</span>
                <button class="street-card-close" id="street-card-close">✕</button>
            </div>
            <div class="street-card-body">
                <div class="street-card-info">
                    <span>🏠 Домов: ${housesCount}</span>
                    <span>📍 ${street.coordinates.length} точек</span>
                </div>
                <div class="street-card-actions">
                    <button class="primary-btn" id="street-add-house">🏠 Добавить дом</button>
                    <button class="danger-btn" id="street-delete">🗑 Удалить улицу</button>
                </div>
            </div>
        `;

        card.style.display = "block";

        document.getElementById("street-card-close").addEventListener("click", function () {
            card.style.display = "none";
            deselectStreet();
        });

        document.getElementById("street-add-house").addEventListener("click", function () {
            if (window.PISPOP_ADDRESS) {
                window.PISPOP_ADDRESS.addHouse(street.id);
            }
        });

        document.getElementById("street-delete").addEventListener("click", function () {
            if (confirm("Удалить улицу \"" + street.name + "\" и все дома на ней?")) {
                // Удаляем все дома на этой улице
                if (window.PISPOP_ADDRESS) {
                    const houses = window.PISPOP_ADDRESS.getHouses();
                    const toDelete = houses.filter(function (h) {
                        return h.streetId === street.id;
                    });
                    toDelete.forEach(function (h) {
                        // Удаляем каждый дом (асинхронно)
                        fetch("/api/houses/" + encodeURIComponent(h.id), {
                            method: "DELETE"
                        }).catch(function (err) {
                            console.error("Failed to delete house:", err);
                        });
                    });
                }

                // Удаляем улицу
                streetsData.streets = streetsData.streets.filter(function (s) {
                    return s.id !== street.id;
                });

                selectedStreet = null;
                renderStreets();
                saveStreetsToServer();
                card.style.display = "none";

                if (window.PISPOP_ADDRESS) {
                    window.PISPOP_ADDRESS.refresh();
                }

                showToast("Улица удалена", "success");
            }
        });
    }

    function hideStreetCard() {
        const card = document.getElementById("street-card");
        if (card) card.style.display = "none";
    }

    /* =========================================================
       КНОПКИ ИНТЕРФЕЙСА
       ========================================================= */

    /* =========================================================
       КНОПКИ ИНТЕРФЕЙСА
       ========================================================= */

    function setupUI() {
        // Кнопка редактора улиц
        const toolStreets = document.getElementById("tool-streets");
        if (toolStreets) {
            // Удаляем старые обработчики
            const newStreetsBtn = toolStreets.cloneNode(true);
            toolStreets.parentNode.replaceChild(newStreetsBtn, toolStreets);
            
            newStreetsBtn.addEventListener("click", function (event) {
                event.preventDefault();
                event.stopPropagation();
                toggleStreetEditor();
            });
        }

        // Кнопка рисования улицы (появляется в режиме редактора)
        const startStreetBtn = document.getElementById("tool-start-street");
        if (startStreetBtn) {
            // Удаляем старые обработчики
            const newStartBtn = startStreetBtn.cloneNode(true);
            startStreetBtn.parentNode.replaceChild(newStartBtn, startStreetBtn);
            
            newStartBtn.addEventListener("click", function (event) {
                event.preventDefault();
                event.stopPropagation();
                
                console.log("[PISPOP-GIS] Start street button clicked");
                
                if (drawingStreet) {
                    // Если уже рисуем - завершаем
                    finishDrawingStreet();
                } else {
                    // Иначе начинаем рисование
                    startDrawingStreet();
                }
            });

            // Изначально скрыта
            newStartBtn.classList.add("hidden");
        }
    }

    /* =========================================================
       ДВОЙНОЙ КЛИК - ЗАВЕРШЕНИЕ РИСОВАНИЯ
       ========================================================= */

    function setupDoubleClick() {
        if (!map) return;

        map.on("dblclick", function (event) {
            if (!drawingStreet) return;
            event.preventDefault();
            finishDrawingStreet();
        });
    }

    /* =========================================================
       ТОСТЫ
       ========================================================= */

    function showToast(text, type) {
        if (typeof Toastify === "function") {
            Toastify({
                text: text,
                duration: 2500,
                gravity: "bottom",
                position: "center",
                close: true,
                style: {
                    background: type === "error" ? "#c62828" :
                        type === "success" ? "#2e7d32" : "#333"
                }
            }).showToast();
        } else {
            console.log("[PISPOP-GIS]", text);
        }
    }

    /* =========================================================
       ИНИЦИАЛИЗАЦИЯ
       ========================================================= */

    async function initStreetEditor() {
        console.log("[PISPOP-GIS] Initializing street editor...");

        map = getMap();
        if (!map) {
            console.error("[PISPOP-GIS] Map not found");
            return;
        }

        if (!createStreetLayer()) {
            console.error("[PISPOP-GIS] Failed to create street layer");
            return;
        }

        await loadStreets();
        renderStreets();

        setupStreetSelection();
        setupDoubleClick();
        setupUI();

        console.log("[PISPOP-GIS] Street editor initialized with", streetsData.streets.length, "streets");
    }

    /* =========================================================
       ПУБЛИЧНЫЙ API
       ========================================================= */

    window.PISPOP_STREETS = {
        getData: function () { return streetsData; },
        getStreets: function () { return streetsData.streets; },
        getSelectedStreet: function () { return selectedStreet; },
        toggle: toggleStreetEditor,
        startDrawing: startDrawingStreet,
        finishDrawing: finishDrawingStreet,
        cancelDrawing: cancelDrawingStreet,
        refresh: function () {
            return loadStreets().then(function () {
                renderStreets();
            });
        },
        selectStreet: selectStreet,
        deselectStreet: deselectStreet
    };

    // Запускаем
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initStreetEditor);
    } else {
        initStreetEditor();
    }

})();