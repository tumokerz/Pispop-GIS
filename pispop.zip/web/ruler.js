(function(){
  "use strict";
  var map=null, layer=null, source=null, active=false, points=[];
  function getMap(){return window.unmined && window.unmined.map && window.unmined.map.getView ? window.unmined.map : (window.unmined&&window.unmined.olMap?window.unmined.olMap:null);}
  function toData(c){return window.unmined&&window.unmined.viewProjection&&window.unmined.dataProjection?ol.proj.transform(c,window.unmined.viewProjection,window.unmined.dataProjection):c;}
  function toView(c){return window.unmined&&window.unmined.viewProjection&&window.unmined.dataProjection?ol.proj.transform(c,window.unmined.dataProjection,window.unmined.viewProjection):c;}
  function dist(a,b){return Math.hypot(a[0]-b[0],a[1]-b[1]);}
  function fmt(n){return Math.round(n).toLocaleString('ru-RU')+' блоков';}
  function ensure(){map=getMap();if(!map)return false;if(layer)return true;source=new ol.source.Vector();layer=new ol.layer.Vector({source:source,zIndex:20000,style:function(f){if(f.get('rulerPoint'))return new ol.style.Style({image:new ol.style.Circle({radius:6,fill:new ol.style.Fill({color:'#3c6ef6'}),stroke:new ol.style.Stroke({color:'#fff',width:2})})});return new ol.style.Style({stroke:new ol.style.Stroke({color:'#3c6ef6',width:4}),text:new ol.style.Text({text:f.get('label')||'',offsetY:-14,font:'bold 12px Arial',fill:new ol.style.Fill({color:'#1f2430'}),backgroundFill:new ol.style.Fill({color:'#fff'}),padding:[3,5,3,5]})});}});map.addLayer(layer);return true;}
  function addPointFromViewCoordinate(viewCoordinate){var p=toData(viewCoordinate);p=[Number(p[0]),Number(p[1])];if(!isFinite(p[0])||!isFinite(p[1]))return;if(points.length&&dist(points[points.length-1],p)<0.5)return;var vf=toView(p);var pf=new ol.Feature(new ol.geom.Point(vf));pf.set('rulerPoint',true);source.addFeature(pf);if(points.length){var prev=points[points.length-1],d=dist(prev,p),lf=new ol.Feature(new ol.geom.LineString([toView(prev),vf]));lf.set('label',fmt(d));source.addFeature(lf);}points.push(p);}
  function onMapClick(evt){if(!active)return;addPointFromViewCoordinate(evt.coordinate);}
  function clear(){if(source)source.clear();points=[];}
  function attach(){if(!map)return;map.un('singleclick',onMapClick);map.on('singleclick',onMapClick);var vp=map.getViewport&&map.getViewport();if(vp&&!vp.__pispopRulerDom){vp.__pispopRulerDom=function(e){if(!active)return; if(e.target.closest&&e.target.closest('.ol-control'))return; e.preventDefault(); e.stopImmediatePropagation(); var c=map.getEventCoordinate(e); if(c)addPointFromViewCoordinate(c);};vp.addEventListener('click',vp.__pispopRulerDom,true);}}
  function detach(){if(!map)return;map.un('singleclick',onMapClick);var vp=map.getViewport&&map.getViewport();if(vp&&vp.__pispopRulerDom){vp.removeEventListener('click',vp.__pispopRulerDom,true);delete vp.__pispopRulerDom;}}
  function toggle(){if(!ensure())return;active=!active;var b=document.getElementById('map-ruler');if(active){attach();b&&b.classList.add('active');}else{b&&b.classList.remove('active');detach();clear();}}
  function init(){var tries=0;function wait(){if(ensure()){var b=document.getElementById('map-ruler');if(b&&!b.dataset.rulerBound){b.dataset.rulerBound='1';b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();toggle();});}return;}if(++tries<200)setTimeout(wait,100);}wait();}
  window.PISPOP_RULER={isActive:function(){return active;},toggle:toggle,clear:clear};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
