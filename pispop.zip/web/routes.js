/*
 * ============================================================
 * PISPOP-GIS
 * routes.js
 *
 * Построитель маршрута между двумя точками.
 *
 * Считает два варианта:
 *  - пешком, по прямой;
 *  - с использованием ледяной дороги: пешком до ближайшей точки
 *    ледяной дороги (roads-editor.js, тип "ice") рядом с точкой А,
 *    ДАЛЬШЕ СТРОГО ВДОЛЬ нарисованных отрезков дороги (как по
 *    графу - учитываются реальные повороты) до точки рядом с Б,
 *    и пешком до Б. Дорога на карте нарисована отдельными кусками,
 *    но в игре это одна сплошная сеть - поэтому куски, которые
 *    формально не совпадают концами, всё равно "сшиваются" в один
 *    граф через их реально ближайшие друг к другу точки. Маршрут
 *    при этом всё равно идёт по факту нарисованных линий (с
 *    поворотами), а не срезает через всю карту напрямик.
 *
 * На коротких расстояниях вариант через ледянку не считается
 * и не показывается - обход до дороги того не стоит.
 *
 * ============================================================
 */

(function () {

    "use strict";

    // Ледянку не предлагаем, если расстояние по прямой меньше
    // этого значения (в блоках) - обход до дороги того не стоит.
    const ICE_ROAD_MIN_DISTANCE = 400;

    // Во сколько раз езда по льду быстрее ходьбы пешком (лодка на
    // льду в Minecraft куда быстрее ходьбы). Используется, чтобы
    // выбирать маршрут по РЕАЛЬНОМУ ВРЕМЕНИ в пути, а не по голому
    // числу блоков - иначе алгоритм мог посчитать "короче" слезть с
    // дороги чуть раньше и топать пешком остаток пути, хотя вдоль
    // берега дорога слегка петляет и по факту доехать до конца
    // всегда быстрее, просто не короче по прямой.
    const WALK_SPEED = 4.317;
    const BOAT_ICE_SPEED = 40;

    // Точки отрезков дороги ближе этого расстояния друг к другу
    // (в блоках) считаются одной и той же точкой стыковки - так
    // отдельно нарисованные куски дороги, чьи концы примыкают
    // друг к другу (но не пиксель-в-пиксель), склеиваются в одну
    // сеть. Куски дороги, между которыми реальный разрыв больше
    // этого значения, остаются раздельными - маршрут не будет
    // "срезать" через несуществующий лёд между ними.
    const NODE_MERGE_DISTANCE = 3;

    // Отдельно нарисованные куски дороги "сшиваются" друг с другом
    // в единую сеть без ограничения по расстоянию (см.
    // buildRoadGraph) - в игре это всегда одна сплошная дорога,
    // даже если в roads.json она записана отдельными кусками.
    // Маршрут и отрисовка не делают между ними разницы - для
    // пользователя это одна и та же дорога.
    const MAX_BRIDGE_DISTANCE = 0;

    let map = null;

    let routeSource = null;
    let routeLayer = null;

    let pickingMode = false;
    let nextPick = "from"; // "from" | "to"

    let pointFrom = null; // [x, z]
    let pointTo = null;   // [x, z]

    let initialized = false;


    /* ========================================================
       КАРТА
       ======================================================== */

    function getMap() {

        if (
            window.unmined &&
            window.unmined.map &&
            typeof window.unmined.map.getView === "function"
        ) {
            return window.unmined.map;
        }

        if (
            window.unmined &&
            window.unmined.olMap &&
            typeof window.unmined.olMap.getView === "function"
        ) {
            return window.unmined.olMap;
        }

        if (window.unmined) {

            const keys = Object.keys(window.unmined);

            for (let i = 0; i < keys.length; i++) {

                const value = window.unmined[keys[i]];

                if (
                    value &&
                    typeof value.getView === "function" &&
                    typeof value.addLayer === "function"
                ) {
                    return value;
                }

            }

        }

        return null;

    }


    /* ========================================================
       ПРЕОБРАЗОВАНИЕ КООРДИНАТ
       ======================================================== */

    /*
     * pointFrom/pointTo хранятся в data-координатах (Minecraft
     * X/Z), но на карте рисуются через view-координаты —
     * смотри пояснение в ui.js/markers.js.
     */

    function toDataCoordinate(viewCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return viewCoordinate;
        }

        return ol.proj.transform(
            viewCoordinate,
            window.unmined.viewProjection,
            window.unmined.dataProjection
        );

    }

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }


    /* ========================================================
       РАССТОЯНИЕ И ЛЕДЯНАЯ ДОРОГА
       ======================================================== */

    function distance(a, b) {

        const dx = a[0] - b[0];
        const dz = a[1] - b[1];

        return Math.sqrt(dx * dx + dz * dz);

    }

    /* ---------------------------------------------------------
       ГРАФ ЛЕДЯНОЙ ДОРОГИ

       Дорога на карте нарисована как набор отдельных отрезков
       (roads-editor.js). Строим граф: узлы - все точки всех
       отрезков (близкие точки в пределах NODE_MERGE_DISTANCE
       считаются одной и той же точкой стыковки), рёбра - соседние
       точки внутри одного отрезка. Маршрут по льду ищется как
       кратчайший путь по ЭТОМУ графу (алгоритм Дейкстры) - то
       есть строго вдоль нарисованных линий, с учётом того, какие
       куски дороги реально соединены между собой, а какие нет.
       --------------------------------------------------------- */

    function getIceRoads() {

        if (!window.PISPOP_ROADS) {
            return [];
        }

        const data = window.PISPOP_ROADS.getData();

        if (!data || !Array.isArray(data.roads)) {
            return [];
        }

        return data.roads.filter(function (road) {

            if (road.type !== "ice") {
                return false;
            }

            var coords = Array.isArray(road.coordinates) ? road.coordinates : null;
            if ((!coords || coords.length < 2) && Array.isArray(road.segments) && road.segments.length) {
                coords = road.segments.reduce(function(all, seg){ return all.concat(all.length ? seg.slice(1) : seg); }, []);
            }
            if (!coords || coords.length < 2) {
                return false;
            }
            road.__routeCoordinates = coords;

            // Отбрасываем "битые" записи со старым багом сохранения -
            // координаты вида 0.004, 0.003 вместо реальных блоков
            // (артефакт давней версии редактора). Такая точка ближе
            // к (0,0), чем на 1 блок по обеим осям - для настоящих
            // координат мира это невозможно, зато такие записи
            // создают вырожденный плотный кластер точек и ломают
            // построение сети дорог.
            const hasDegeneratePoint = road.coordinates.some(function (pt) {
                return Math.abs(pt[0]) < 1 && Math.abs(pt[1]) < 1;
            });

            return !hasDegeneratePoint;

        });

    }

    let graphCache = null;
    let graphCacheKey = null;

    function buildGraphKey(roads) {
        return roads.length + ":" + roads.reduce(function (sum, r) {
            return sum + ((r.coordinates && r.coordinates.length) || 0);
        }, 0);
    }

    function buildRoadGraph() {

        const roads = getIceRoads();
        const key = JSON.stringify(roads.map(function (r) {
            return { id: r.id, coordinates: r.coordinates };
        }));

        if (graphCache && graphCacheKey === key) return graphCache;

        /*
         * Только реальные геометрические соединения.
         * НИКАКИХ мостов между компонентами по принципу "ближайшие дороги".
         * Это принципиально важно для тоннелей: две линии могут проходить
         * рядом или пересекаться на 2D-карте, но маршрут не должен прыгать
         * с одной на другую просто потому, что они близки.
         */
        const CONNECT_TOLERANCE = 3;
        const segments = [];

        roads.forEach(function (road) {
            const c = road.__routeCoordinates || road.coordinates;
            for (let i = 1; i < c.length; i++) {
                const a = [Number(c[i - 1][0]), Number(c[i - 1][1])];
                const b = [Number(c[i][0]), Number(c[i][1])];
                if (!isFinite(a[0]) || !isFinite(a[1]) || !isFinite(b[0]) || !isFinite(b[1])) continue;
                if (distance(a, b) <= 0.001) continue;
                segments.push({ a: a, b: b, roadId: road.id, split: [a, b] });
            }
        });

        function cross(a, b) { return a[0] * b[1] - a[1] * b[0]; }
        function sub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }

        function projectionOnSegment(p, a, b) {
            const dx = b[0] - a[0], dz = b[1] - a[1];
            const len2 = dx * dx + dz * dz;
            if (!len2) return { point: a.slice(), t: 0, distance: distance(p, a) };
            const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / len2));
            const q = [a[0] + t * dx, a[1] + t * dz];
            return { point: q, t: t, distance: distance(p, q) };
        }

        function pointOnSegment(p, a, b, tolerance) {
            const q = projectionOnSegment(p, a, b);
            return q.distance <= tolerance;
        }

        function addSplit(seg, p) {
            for (let i = 0; i < seg.split.length; i++) {
                if (distance(seg.split[i], p) <= 0.01) return;
            }
            seg.split.push([p[0], p[1]]);
        }

        function intersection(s1, s2) {
            const p = s1.a, r = sub(s1.b, s1.a);
            const q = s2.a, v = sub(s2.b, s2.a);
            const rxs = cross(r, v);
            const qmp = sub(q, p);

            if (Math.abs(rxs) > 1e-9) {
                const t = cross(qmp, v) / rxs;
                const u = cross(qmp, r) / rxs;
                if (t >= -1e-9 && t <= 1 + 1e-9 && u >= -1e-9 && u <= 1 + 1e-9) {
                    return [[p[0] + t * r[0], p[1] + t * r[1]]];
                }
                return [];
            }

            // Коллинеарные отрезки: соединяем только их общий участок/концы.
            if (Math.abs(cross(qmp, r)) <= 1e-9) {
                const result = [];
                [s1.a, s1.b, s2.a, s2.b].forEach(function (pt) {
                    if (pointOnSegment(pt, s1.a, s1.b, 0.01) && pointOnSegment(pt, s2.a, s2.b, 0.01)) {
                        if (!result.some(function (x) { return distance(x, pt) <= 0.01; })) result.push(pt);
                    }
                });
                return result;
            }
            return [];
        }

        // Реальные пересечения линий превращаем в узлы.
        for (let i = 0; i < segments.length; i++) {
            for (let j = i + 1; j < segments.length; j++) {
                intersection(segments[i], segments[j]).forEach(function (p) {
                    addSplit(segments[i], p);
                    addSplit(segments[j], p);
                });
            }
        }

        // Разрешаем только маленькую погрешность в ручной разметке:
        // конец одного сегмента может быть на расстоянии до 3 блоков
        // от СЕРЕДИНЫ другого. Это создаёт Т-стык, но не дальний мост.
        segments.forEach(function (seg, i) {
            [seg.a, seg.b].forEach(function (endpoint) {
                for (let j = 0; j < segments.length; j++) {
                    if (i === j) continue;
                    const other = segments[j];
                    const p = projectionOnSegment(endpoint, other.a, other.b);
                    if (p.distance <= CONNECT_TOLERANCE && p.t > 0.000001 && p.t < 0.999999) {
                        addSplit(seg, p.point);
                        addSplit(other, p.point);
                    }
                }
            });
        });

        const nodes = [];
        const edges = [];
        const NODE_EPS = 3;

        function findOrCreateNode(point) {
            for (let i = 0; i < nodes.length; i++) {
                if (distance(nodes[i], point) <= NODE_EPS) return i;
            }
            nodes.push([point[0], point[1]]);
            return nodes.length - 1;
        }

        function addEdge(a, b) {
            if (a === b) return;
            const w = distance(nodes[a], nodes[b]);
            if (w <= 0.001) return;
            if (edges.some(function (e) { return (e.a === a && e.b === b) || (e.a === b && e.b === a); })) return;
            edges.push({ a: a, b: b, weight: w });
        }

        segments.forEach(function (seg) {
            const dx = seg.b[0] - seg.a[0], dz = seg.b[1] - seg.a[1];
            const len2 = dx * dx + dz * dz;
            seg.split.sort(function (p, q) {
                const tp = ((p[0] - seg.a[0]) * dx + (p[1] - seg.a[1]) * dz) / len2;
                const tq = ((q[0] - seg.a[0]) * dx + (q[1] - seg.a[1]) * dz) / len2;
                return tp - tq;
            });
            let prev = findOrCreateNode(seg.split[0]);
            for (let i = 1; i < seg.split.length; i++) {
                const cur = findOrCreateNode(seg.split[i]);
                addEdge(prev, cur);
                prev = cur;
            }
        });

        const adjacency = nodes.map(function () { return []; });
        edges.forEach(function (edge) {
            adjacency[edge.a].push({ to: edge.b, weight: edge.weight, bridge: false });
            adjacency[edge.b].push({ to: edge.a, weight: edge.weight, bridge: false });
        });

        graphCache = { nodes: nodes, adjacency: adjacency, edges: edges };
        graphCacheKey = key;

        console.log('[PISPOP-ROUTES] Граф без воздушных соединений:',
            'сегментов', segments.length, 'узлов', nodes.length, 'рёбер', edges.length);

        return graphCache;

    }

    /*
     * Ближайшая точка НА отрезке [a, b] к точке p - не обязательно
     * вершина, а любая точка вдоль линии (перпендикулярная проекция,
     * ограниченная концами отрезка).
     */
    function nearestPointOnSegment(p, a, b) {

        const dx = b[0] - a[0];
        const dz = b[1] - a[1];
        const lengthSq = dx * dx + dz * dz;

        if (lengthSq === 0) {
            return a;
        }

        let t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / lengthSq;
        t = Math.max(0, Math.min(1, t));

        return [a[0] + t * dx, a[1] + t * dz];

    }

    /*
     * Ближайшая точка ко всей сети - проверяет КАЖДЫЙ отрезок между
     * соседними точками дороги (не только сами точки-вершины), так
     * что если точка стоит напротив середины длинного прямого куска
     * дороги, находится вход прямо перед ней, а не у далёкого конца
     * этого куска.
     */
    function nearestPointOnGraph(graph, point) {

        let best = null;

        graph.edges.forEach(function (edge) {

            const a = graph.nodes[edge.a];
            const b = graph.nodes[edge.b];

            const projected = nearestPointOnSegment(point, a, b);
            const d = distance(point, projected);

            if (!best || d < best.distance) {

                best = {
                    point: projected,
                    distance: d,
                    edgeA: edge.a,
                    edgeB: edge.b
                };

            }

        });

        return best;

    }

    /*
     * Вставляет точку, найденную nearestPointOnGraph, как отдельный
     * узел в КОПИЮ графа (nodes/adjacency передаются по ссылке и
     * дополняются на месте) - соединяет её с обоими концами того
     * отрезка, на котором она лежит, так что кратчайший путь можно
     * посчитать именно от неё, а не от ближайшей вершины.
     */
    function insertPointOnGraph(nodes, adjacency, projected) {

        const index = nodes.length;
        nodes.push(projected.point);
        adjacency.push([]);

        function connect(otherIndex) {

            const weight = distance(projected.point, nodes[otherIndex]);

            if (weight <= 0) {
                return;
            }

            adjacency[index].push({ to: otherIndex, weight: weight });
            adjacency[otherIndex].push({ to: index, weight: weight });

        }

        connect(projected.edgeA);
        connect(projected.edgeB);

        return index;

    }

    /*
     * Дейкстра от startIndex до всех остальных узлов графа.
     * Возвращает { dist: [...], prev: [...] }. До узлов из другого,
     * не связанного с startIndex, куска дороги dist останется
     * Infinity - значит настоящего пути по дороге туда нет.
     */
    function shortestPaths(graph, startIndex) {

        const dist = graph.nodes.map(function () { return Infinity; });
        const prev = graph.nodes.map(function () { return -1; });
        const visited = graph.nodes.map(function () { return false; });

        dist[startIndex] = 0;

        for (let iter = 0; iter < graph.nodes.length; iter++) {

            let u = -1;
            let uDist = Infinity;

            for (let i = 0; i < graph.nodes.length; i++) {
                if (!visited[i] && dist[i] < uDist) {
                    uDist = dist[i];
                    u = i;
                }
            }

            if (u === -1) {
                break;
            }

            visited[u] = true;

            graph.adjacency[u].forEach(function (edge) {

                const alt = dist[u] + edge.weight;

                if (alt < dist[edge.to]) {
                    dist[edge.to] = alt;
                    prev[edge.to] = u;
                }

            });

        }

        return { dist: dist, prev: prev };

    }

    function reconstructPath(prev, targetIndex) {

        const path = [];
        let current = targetIndex;

        while (current !== -1) {
            path.unshift(current);
            current = prev[current];
        }

        return path;

    }

    /*
     * Направление света от одной точки к другой (8 румбов).
     * В координатах Minecraft: -Z = север, +Z = юг,
     * -X = запад, +X = восток.
     */
    function compassDirection(from, to) {

        const dx = to[0] - from[0];
        const dz = to[1] - from[1];

        let angle = Math.atan2(dx, -dz) * 180 / Math.PI;
        if (angle < 0) angle += 360;

        // Пользователю удобнее ориентироваться по сторонам экрана,
        // а не по компасу: запад = налево, восток = направо,
        // север = вверх, юг = вниз.
        const labels = [
            "вверх", "вверх-направо", "направо", "вниз-направо",
            "вниз", "вниз-налево", "налево", "вверх-налево"
        ];

        const index = Math.round(angle / 45) % 8;

        return labels[index];

    }

    // В пределах этого расстояния (в блоках) от точки входа/выхода
    // на лёд считаем, что это "та самая" станция ледяной дороги,
    // и называем её по имени метки, а не просто "выйдите на лёд".
    const STATION_MATCH_DISTANCE = 150;

    function nearestIceStation(point) {

        if (!window.PISPOP_MARKERS) {
            return null;
        }

        const stations = window.PISPOP_MARKERS.getMarkers().filter(function (m) {
            return m.category === "ice_station";
        });

        let best = null;
        let bestDistance = Infinity;

        stations.forEach(function (station) {

            const d = distance(point, [station.x, station.z]);

            if (d < bestDistance) {
                bestDistance = d;
                best = station;
            }

        });

        if (best) {
            console.log(
                "[PISPOP-ROUTES] Ближайшая станция-метка:", best.title,
                "в", Math.round(bestDistance), "блоках от точки входа/выхода на лёд",
                bestDistance <= STATION_MATCH_DISTANCE ? "(подходит)" : "(слишком далеко, порог " + STATION_MATCH_DISTANCE + ")"
            );
        }

        if (best && bestDistance <= STATION_MATCH_DISTANCE) {
            return best;
        }

        return null;

    }

    /*
     * Пошаговое описание маршрута через ледяную дорогу:
     * "пройдите X блоков на север до станции" и т.д.
     */

    // Точки дороги, нарисованной вручную, редко ложатся идеально по
    // прямой - обычно есть небольшое "дрожание" в пределах
    // нескольких десятков блоков. Перед тем как строить текстовую
    // инструкцию (не для отрисовки на карте - там нужна точность),
    // путь сглаживается этим методом (Дуглас-Пекер) с этим допуском
    // в блоках: мелкие отклонения от общей линии убираются, чтобы
    // они не выглядели как настоящий поворот дороги.
    const LEG_SIMPLIFY_TOLERANCE = 40;

    function perpendicularDistance(p, a, b) {

        const dx = b[0] - a[0];
        const dz = b[1] - a[1];
        const lengthSq = dx * dx + dz * dz;

        if (lengthSq === 0) {
            return distance(p, a);
        }

        const t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / lengthSq;
        const projected = [a[0] + t * dx, a[1] + t * dz];

        return distance(p, projected);

    }

    function simplifyPath(points, tolerance) {

        if (points.length < 3) {
            return points.slice();
        }

        let maxDistance = 0;
        let index = 0;
        const end = points.length - 1;

        for (let i = 1; i < end; i++) {

            const d = perpendicularDistance(points[i], points[0], points[end]);

            if (d > maxDistance) {
                maxDistance = d;
                index = i;
            }

        }

        if (maxDistance > tolerance) {

            const left = simplifyPath(points.slice(0, index + 1), tolerance);
            const right = simplifyPath(points.slice(index), tolerance);

            return left.slice(0, -1).concat(right);

        }

        return [points[0], points[end]];

    }

    /*
     * Разбивает (уже сглаженный) путь на прямые участки одного
     * направления - то есть на реальные "проедьте туда-то,
     * поверните, проедьте туда-то". Соседние точки с одинаковым
     * направлением объединяются в один участок, чтобы не заваливать
     * инструкцию мелкими поворотами там, где дорога почти прямая -
     * независимо от того, что в roads.json это может быть формально
     * другой отрезок: для маршрута вся сеть - одна дорога.
     */
    function splitPathIntoLegs(path) {

        const legs = [];
        let segStart = 0;

        for (let i = 1; i < path.length; i++) {

            const isLast = i === path.length - 1;

            if (!isLast) {

                const dirHere = compassDirection(path[segStart], path[i]);
                const dirNext = compassDirection(path[i], path[i + 1]);

                if (dirHere === dirNext) {
                    continue;
                }

            }

            legs.push({
                from: path[segStart],
                to: path[i],
                distance: distance(path[segStart], path[i]),
                direction: compassDirection(path[segStart], path[i])
            });

            segStart = i;

        }

        return legs;

    }

    function buildIceSteps(from, to, entry, exit, legs) {

        const steps = [];

        const stationFrom = nearestIceStation(entry.point);
        const stationTo = nearestIceStation(exit.point);

        // Шаг 1: пешком от А до дороги
        if (entry.distance < 3) {

            steps.push("Вы уже находитесь у ледяной дороги.");

        } else {

            const dir = compassDirection(from, entry.point);

            steps.push(
                "Пройдите " + Math.round(entry.distance) + " блоков на " + dir +
                (stationFrom ? " до станции «" + (stationFrom.title || "без названия") + "»" : " до ледяной дороги")
            );

        }

        // Шаг 2: сесть в лодку
        steps.push(
            stationFrom
                ? "Сядьте в лодку на станции «" + (stationFrom.title || "без названия") + "»"
                : "Сядьте в лодку и выйдите на лёд"
        );

        // Шаг 3: путь по льду - строго вдоль дороги, с поворотами
        // там, где они реально есть (в том числе там, где на карте
        // это формально разные записанные куски одной и той же
        // сети - для маршрута они не отличаются от единой линии).
        legs.forEach(function (leg, index) {

            const prefix = index === 0 ? "Проедьте по льду " : "Поверните и проедьте ";

            steps.push(
                prefix + Math.round(leg.distance) + " блоков на " + leg.direction
            );

        });

        // Шаг 4: сойти с лодки
        steps.push(
            stationTo
                ? "Сойдите со льда на станции «" + (stationTo.title || "без названия") + "»"
                : "Сойдите со льда"
        );

        // Шаг 5: пешком от дороги до Б
        if (exit.distance < 3) {

            steps.push("Вы на месте.");

        } else {

            const dir = compassDirection(exit.point, to);

            steps.push(
                "Пройдите " + Math.round(exit.distance) + " блоков на " + dir + " до места назначения"
            );

        }

        return steps;

    }

    /*
     * Считает оба варианта маршрута между from и to (data-координаты).
     * Возвращает:
     * {
     *   walkDistance: число,
     *   waterCrossing: null | { distance: число } - примерно сколько
     *     блоков пешего маршрута проходит по воде;
     *   iceRoute: null | {
     *     distance: число,
     *     legFrom, legTo: число (пешком до/от ледяной дороги),
     *     legIce: число (путь по льду напрямую между точками входа),
     *     path: [[x,z], [x,z]] - точки входа/выхода на лёд, для отрисовки
     *     steps: [строка, ...] - пошаговое текстовое описание
     *   }
     * }
     */
    /*
     * Пошаговая пешая инструкция - направление и расстояние,
     * плюс предупреждение, если по пути есть вода.
     */
    function buildWalkSteps(from, to, waterCrossing) {

        const steps = [];
        const dir = compassDirection(from, to);

        steps.push(
            "Идите " + Math.round(distance(from, to)) + " блоков на " + dir +
            " до места назначения"
        );

        if (waterCrossing) {

            steps.push(
                "⚠️ На пути есть вода - около " + waterCrossing.distance +
                " блоков придётся проплыть"
            );

        }

        return steps;

    }

    function computeRoute(from, to) {

        const walkDistance = distance(from, to);

        let waterCrossing = null;

        if (window.PISPOP_WATER) {
            waterCrossing = window.PISPOP_WATER.checkCrossing(from, to);
        }

        const walkSteps = buildWalkSteps(from, to, waterCrossing);

        let iceRoute = null;

        if (walkDistance >= ICE_ROAD_MIN_DISTANCE) {

            const graph = buildRoadGraph();

            console.log(
                "[PISPOP-ROUTES] Узлов ледяной сети:", graph.nodes.length,
                "| отрезков roads.json (type=ice):", getIceRoads().length
            );

            if (graph.nodes.length > 1) {

                // Точка входа/выхода почти никогда не совпадает
                // ровно с вершиной графа - обычно лежит где-то на
                // отрезке между двумя вершинами. Ищем такую точку
                // отдельно (вдоль ЛЮБОГО отрезка сети целиком, не
                // только по существующим точкам) и добавляем её как
                // ещё один узел-кандидат - вдобавок к перебору всех
                // обычных узлов сети (см. ниже), а не вместо него:
                // так учитывается вся линия целиком, а не только её
                // отмеченные точки, и при этом по-прежнему
                // проверяются разные комбинации входа/выхода, а не
                // только самая близкая.
                const nodes = graph.nodes.slice();
                const adjacency = graph.adjacency.map(function (list) {
                    return list.slice();
                });

                const entryProjection = nearestPointOnGraph(graph, from);
                const exitProjection = nearestPointOnGraph(graph, to);

                const preciseEntryIndex = entryProjection
                    ? insertPointOnGraph(nodes, adjacency, entryProjection)
                    : -1;

                const preciseExitIndex = exitProjection
                    ? insertPointOnGraph(nodes, adjacency, exitProjection)
                    : -1;

                const entryCandidates = [];
                const exitCandidates = [];

                for (let i = 0; i < graph.nodes.length; i++) {
                    entryCandidates.push(i);
                    exitCandidates.push(i);
                }

                if (preciseEntryIndex !== -1) {
                    entryCandidates.push(preciseEntryIndex);
                }

                if (preciseExitIndex !== -1) {
                    exitCandidates.push(preciseExitIndex);
                }

                // Выбор лучшей пары считается по ВРЕМЕНИ в пути, а
                // не по голым блокам: езда по льду в разы быстрее
                // ходьбы (см. ICE_SPEED_MULTIPLIER), поэтому в графе
                // для поиска пути рёбра дороги "весят" меньше, чем
                // те же расстояния пешком. Без этого алгоритм мог
                // посчитать выгодным слезть с дороги чуть раньше и
                // топать пешком остаток, если дорога вдоль берега
                // слегка петляет и по голым блокам выходит чуть
                // длиннее прямой - хотя доехать до конца всегда
                // быстрее по факту.
                const timeAdjacency = adjacency.map(function (list) {
                    return list.map(function (edge) {
                        return { to: edge.to, weight: edge.weight / BOAT_ICE_SPEED };
                    });
                });

                const timeGraph = { nodes: nodes, adjacency: timeAdjacency };

                let best = null;

                entryCandidates.forEach(function (p) {

                    const entryDistance = distance(from, nodes[p]);
                    const result = shortestPaths(timeGraph, p);

                    exitCandidates.forEach(function (q) {

                        if (q === p) {
                            return;
                        }

                        const graphTimeCost = result.dist[q];

                        if (!isFinite(graphTimeCost)) {
                            return;
                        }

                        const exitDistance = distance(nodes[q], to);
                        const timeCost = entryDistance / WALK_SPEED + graphTimeCost + exitDistance / WALK_SPEED;

                        if (!best || timeCost < best.timeCost) {

                            best = {
                                timeCost: timeCost,
                                entryIndex: p,
                                exitIndex: q,
                                entryDistance: entryDistance,
                                exitDistance: exitDistance,
                                prev: result.prev
                            };

                        }

                    });

                });

                console.log(
                    "[PISPOP-ROUTES] Лучший маршрут через сеть (перебор всех пар вход/выход, по времени в пути):",
                    best ? "найден" : "не найден (сеть не связана)"
                );

                if (best) {

                    const entry = { point: nodes[best.entryIndex], distance: best.entryDistance };
                    const exit = { point: nodes[best.exitIndex], distance: best.exitDistance };

                    console.log(
                        "[PISPOP-ROUTES] Вход на лёд рядом с А:", entry.point,
                        "на расстоянии", Math.round(entry.distance), "блоков"
                    );
                    console.log(
                        "[PISPOP-ROUTES] Выход со льда рядом с Б:", exit.point,
                        "на расстоянии", Math.round(exit.distance), "блоков"
                    );

                    const pathIndices = reconstructPath(best.prev, best.exitIndex);
                    const networkPath = pathIndices.map(function (i) {
                        return nodes[i];
                    });

                    // Выбор пары вход/выход был сделан по времени в
                    // пути (см. timeGraph выше), но пользователю
                    // показываем настоящее число блоков - считаем его
                    // отдельно, суммируя реальные (не "временные")
                    // расстояния вдоль уже выбранного пути.
                    let realIceDistance = 0;
                    for (let i = 1; i < networkPath.length; i++) {
                        realIceDistance += distance(networkPath[i - 1], networkPath[i]);
                    }

                    const totalDistance = entry.distance + realIceDistance + exit.distance;

                    // Для карты используется точный путь по сети (по
                    // каждой настоящей точке). Для текстовой
                    // инструкции путь сначала сглаживается (убирает
                    // мелкое дрожание ручной разметки), а потом уже
                    // делится на цельные шаги "проедьте туда-то".
                    const simplifiedPath = simplifyPath(networkPath, LEG_SIMPLIFY_TOLERANCE);
                    const legs = splitPathIntoLegs(simplifiedPath);

                    iceRoute = {
                        distance: totalDistance,
                        timeSeconds: entry.distance / WALK_SPEED + realIceDistance / BOAT_ICE_SPEED + exit.distance / WALK_SPEED,
                        walkToRoadSeconds: entry.distance / WALK_SPEED,
                        iceSeconds: realIceDistance / BOAT_ICE_SPEED,
                        walkFromRoadSeconds: exit.distance / WALK_SPEED,
                        legFrom: entry.distance,
                        legIce: realIceDistance,
                        legTo: exit.distance,
                        path: networkPath,
                        legs: legs,
                        steps: buildIceSteps(from, to, entry, exit, legs)
                    };

                }

            }

        }

        return {
            walkDistance: walkDistance,
            walkTimeSeconds: walkDistance / WALK_SPEED,
            walkSteps: walkSteps,
            waterCrossing: waterCrossing,
            iceRoute: iceRoute
        };

    }


    /* ========================================================
       ОТРИСОВКА
       ======================================================== */

    function render() {

        routeSource.clear();

        if (pointFrom) {

            routeSource.addFeature(new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate(pointFrom)),
                pointKind: "from"
            }));

        }

        if (pointTo) {

            routeSource.addFeature(new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate(pointTo)),
                pointKind: "to"
            }));

        }

        if (pointFrom && pointTo) {

            routeSource.addFeature(new ol.Feature({
                geometry: new ol.geom.LineString([
                    toViewCoordinate(pointFrom),
                    toViewCoordinate(pointTo)
                ]),
                pointKind: "line"
            }));

            const result = computeRoute(pointFrom, pointTo);

            if (result.iceRoute) {

                const path = result.iceRoute.path;
                const iceStart = path[0];
                const iceEnd = path[path.length - 1];

                // Пешком от А до сети дорог
                routeSource.addFeature(new ol.Feature({
                    geometry: new ol.geom.LineString([
                        toViewCoordinate(pointFrom),
                        toViewCoordinate(iceStart)
                    ]),
                    pointKind: "ice-leg"
                }));

                // Сам путь по сети ледяных дорог. Рисуется по КАЖДОЙ
                // настоящей точке пути (result.iceRoute.path), а не
                // по укрупнённым "легам" из текстовой инструкции -
                // те объединяют несколько точек в один шаг ради
                // краткости текста и для рисования на карте не
                // годятся: если дорога плавно изгибается, но в целом
                // идёт в одну сторону, укрупнённый шаг превратился бы
                // в прямую линию, срезающую через этот изгиб.
                routeSource.addFeature(new ol.Feature({
                    geometry: new ol.geom.LineString(
                        path.map(toViewCoordinate)
                    ),
                    pointKind: "ice-road"
                }));

                // Пешком от сети дорог до Б
                routeSource.addFeature(new ol.Feature({
                    geometry: new ol.geom.LineString([
                        toViewCoordinate(iceEnd),
                        toViewCoordinate(pointTo)
                    ]),
                    pointKind: "ice-leg"
                }));

                routeSource.addFeature(new ol.Feature({
                    geometry: new ol.geom.Point(toViewCoordinate(iceStart)),
                    pointKind: "station"
                }));

                routeSource.addFeature(new ol.Feature({
                    geometry: new ol.geom.Point(toViewCoordinate(iceEnd)),
                    pointKind: "station"
                }));

            }

        }

    }

    function routeStyle(feature) {

        const kind = feature.get("pointKind");

        if (kind === "line") {

            return new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: "#ffd400",
                    width: 5,
                    lineDash: [2, 10],
                    lineCap: "round"
                })
            });

        }

        if (kind === "ice-leg") {

            return new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: "#ffe45c",
                    width: 4,
                    lineDash: [2, 8],
                    lineCap: "round"
                })
            });

        }

        if (kind === "ice-road") {

            return new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: "#35b94a",
                    width: 6,
                    lineCap: "round"
                })
            });

        }

        if (kind === "station") {

            return new ol.style.Style({
                image: new ol.style.Circle({
                    radius: 6,
                    fill: new ol.style.Fill({ color: "#35b94a" }),
                    stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
                })
            });

        }

        const color = kind === "from" ? "#35b94a" : "#ffd400";

        return new ol.style.Style({
            image: new ol.style.Circle({
                radius: 8,
                fill: new ol.style.Fill({ color: color }),
                stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
            })
        });

    }


    /* ========================================================
       РЕЖИМ ВЫБОРА ТОЧЕК
       ======================================================== */

    function startPicking() {

        pickingMode = true;
        nextPick = "from";

        document.dispatchEvent(
            new CustomEvent("pispop:route-picking", { detail: true })
        );

        if (map) {
            map.getViewport().style.cursor = "crosshair";
        }

    }

    function stopPicking() {

        pickingMode = false;

        document.dispatchEvent(
            new CustomEvent("pispop:route-picking", { detail: false })
        );

        if (map) {
            map.getViewport().style.cursor = "";
        }

    }

    function clearRoute() {

        pointFrom = null;
        pointTo = null;

        render();

        document.dispatchEvent(
            new CustomEvent("pispop:route-updated", {
                detail: { from: null, to: null, walkDistance: null, walkTimeSeconds: null, walkSteps: null, waterCrossing: null, iceRoute: null }
            })
        );

    }

    function emitUpdate() {

        render();

        const result = (pointFrom && pointTo)
            ? computeRoute(pointFrom, pointTo)
            : { walkDistance: null, walkTimeSeconds: null, walkSteps: null, waterCrossing: null, iceRoute: null };

        document.dispatchEvent(
            new CustomEvent("pispop:route-updated", {
                detail: {
                    from: pointFrom,
                    to: pointTo,
                    walkDistance: result.walkDistance,
                    walkTimeSeconds: result.walkTimeSeconds,
                    walkSteps: result.walkSteps,
                    waterCrossing: result.waterCrossing,
                    iceRoute: result.iceRoute
                }
            })
        );

    }

    function setPoint(kind, coordinate) {

        const rounded = [Math.round(coordinate[0]), Math.round(coordinate[1])];

        if (kind === "from") {
            pointFrom = rounded;
        } else {
            pointTo = rounded;
        }

        emitUpdate();

    }

    function swapPoints() {

        const tmp = pointFrom;
        pointFrom = pointTo;
        pointTo = tmp;

        emitUpdate();

    }

    function setupClick() {

        map.on("singleclick", function (event) {

            if (!pickingMode) {
                return;
            }

            const dataCoord = toDataCoordinate(event.coordinate);

            const coordinate = [
                Math.round(dataCoord[0]),
                Math.round(dataCoord[1])
            ];

            if (nextPick === "from") {

                pointFrom = coordinate;
                nextPick = "to";

            } else {

                pointTo = coordinate;
                stopPicking();

            }

            emitUpdate();

        });

    }


    /* ========================================================
       ИНИЦИАЛИЗАЦИЯ
       ======================================================== */

    function initialize() {

        if (initialized) {
            return true;
        }

        map = getMap();

        if (!map) {
            return false;
        }

        routeSource = new ol.source.Vector();

        routeLayer = new ol.layer.Vector({
            source: routeSource,
            zIndex: 250000,
            style: routeStyle
        });

        map.addLayer(routeLayer);

        setupClick();

        initialized = true;

        console.log("PISPOP-GIS: routes.js подключён.");

        return true;

    }

    let attempts = 0;
    const MAX_ATTEMPTS = 100;

    function waitForMap() {

        attempts++;

        if (initialize()) {
            return;
        }

        if (attempts >= MAX_ATTEMPTS) {
            console.error("PISPOP-GIS: карта не найдена (routes).");
            return;
        }

        setTimeout(waitForMap, 200);

    }


    /* ========================================================
       ПУБЛИЧНЫЙ API
       ======================================================== */

    window.PISPOP_ROUTES = {

        startPicking: startPicking,
        stopPicking: stopPicking,
        clear: clearRoute,

        isPicking: function () {
            return pickingMode;
        },

        // Ставит точку А или Б программно (например, из карточки
        // объекта через кнопку "Отсюда"/"Сюда"), не через клик по карте.
        setFrom: function (coordinate) {
            setPoint("from", coordinate);
        },

        setTo: function (coordinate) {
            setPoint("to", coordinate);
        },

        swap: swapPoints,

        getRoute: function () {

            const result = (pointFrom && pointTo)
                ? computeRoute(pointFrom, pointTo)
                : { walkDistance: null, walkTimeSeconds: null, walkSteps: null, waterCrossing: null, iceRoute: null };

            return {
                from: pointFrom,
                to: pointTo,
                walkDistance: result.walkDistance,
                walkTimeSeconds: result.walkTimeSeconds,
                walkSteps: result.walkSteps,
                waterCrossing: result.waterCrossing,
                iceRoute: result.iceRoute
            };

        }

    };


    waitForMap();

}());
