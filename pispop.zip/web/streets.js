/*
 * ============================================================
 * PISPOP-GIS
 * streets.js
 *
 * Простой редактор улиц с отдельным JSON-файлом.
 * 
 * - Рисование улиц по кликам
 * - Двойной клик - завершить
 * - Сохранение в /data/streets.json
 * - Выбор улицы для добавления домов
 *
 * ============================================================
 */

(function () {
    "use strict";

    console.log("[PISPOP-GIS] streets.js loading...");

    var map = null;
    var streetSource = null;
    var streetLayer = null;
    var drawSource = null;
    var drawLayer = null;

    var streets = [];
    var selectedStreet = null;
    var isDrawing = false;
    var drawPoints = [];
    var clickHandler = null;
    var dblClickHandler = null;

    var editorActive = false;

    var STREET_COLOR = "#72551d";
    var STREET_SELECTED_COLOR = "#ff6b6b";
    var STREET_WIDTH = 4;
    var STREET_SELECTED_WIDTH = 8;

    /* =========================================================
       КАРТА
       ========================================================= */

    function getMap() {
        if (window.unmined && window.unmined.map && typeof window.unmined.map.getView === "function") {
            return window.unmined.map;
        }
        if (window.unmined && window.unmined.olMap && typeof window.unmined.olMap.getView === "function") {
            return window.unmined.olMap;
        }
        if (window.unmined) {
            var keys = Object.keys(window.unmined);
            for (var i = 0; i < keys.length; i++) {
                var value = window.unmined[keys[i]];
                if (value && typeof value.getView === "function" && typeof value.addLayer === "function") {
                    return value;
                }
            }
        }
        return null;
    }

    function toDataCoordinate(viewCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return viewCoordinate;
        }
        return ol.proj.transform(viewCoordinate, window.unmined.viewProjection, window.unmined.dataProjection);
    }

    function toViewCoordinate(dataCoordinate) {
        if (!window.unmined || !window.unmined.viewProjection || !window.unmined.dataProjection) {
            return dataCoordinate;
        }
        return ol.proj.transform(dataCoordinate, window.unmined.dataProjection, window.unmined.viewProjection);
    }

    /* =========================================================
       ГЕНЕРАЦИЯ ID
       ========================================================= */

    function generateId() {
        return "street-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 8);
    }

    /* =========================================================
       ЗАГРУЗКА / СОХРАНЕНИЕ
       ========================================================= */

    async function loadStreets() {
        try {
            var response = await fetch("/api/streets", { cache: "no-cache" });
            if (!response.ok) {
                streets = [];
                return streets;
            }
            var data = await response.json();
            streets = Array.isArray(data) ? data : [];
            console.log("[PISPOP-GIS] Streets loaded:", streets.length);
            return streets;
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot load streets:", error);
            streets = [];
            return streets;
        }
    }

    async function saveStreets() {
        try {
            var response = await fetch("/api/streets", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(streets)
            });
            if (!response.ok) throw new Error("HTTP " + response.status);
            console.log("[PISPOP-GIS] Streets saved:", streets.length);
        } catch (error) {
            console.error("[PISPOP-GIS] Cannot save streets:", error);
        }
    }

    /* =========================================================
       СТИЛИ
       ========================================================= */

    function getStreetStyle(street) {
        var isSelected = selectedStreet && selectedStreet.id === street.id;
        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: isSelected ? STREET_SELECTED_COLOR : (street.color || STREET_COLOR),
                width: isSelected ? STREET_SELECTED_WIDTH : STREET_WIDTH,
                lineCap: "round",
                lineJoin: "round"
            }),
            zIndex: isSelected ? 50 : 10
        });
    }

    function getDrawStyle() {
        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                color: STREET_COLOR,
                width: 3,
                lineCap: "round",
                lineJoin: "round",
                lineDash: [8, 6]
            }),
            image: new ol.style.Circle({
                radius: 5,
                fill: new ol.style.Fill({ color: STREET_COLOR }),
                stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
            })
        });
    }

    /* =========================================================
       ОТРИСОВКА
       ========================================================= */

    function renderStreets() {
        if (!streetSource) return;
        streetSource.clear();

        streets.forEach(function (street) {
            if (!Array.isArray(street.coordinates) || street.coordinates.length < 2) return;

            try {
                var geometry = new ol.geom.LineString(
                    street.coordinates.map(toViewCoordinate)
                );
                var feature = new ol.Feature({ geometry: geometry });
                feature.setId(street.id);
                feature.set("streetData", street);
                feature.setStyle(getStreetStyle(street));
                streetSource.addFeature(feature);
            } catch (e) {
                console.warn("Failed to render street:", street.id, e);
            }
        });

        console.log("[PISPOP-GIS] Rendered streets:", streets.length);
    }

    function renderDrawing() {
        if (!drawSource) return;
        drawSource.clear();

        if (drawPoints.length === 0) return;

        // Точки
        drawPoints.forEach(function (point) {
            var feature = new ol.Feature({
                geometry: new ol.geom.Point(toViewCoordinate(point))
            });
            feature.setStyle(new ol.style.Style({
                image: new ol.style.Circle({
                    radius: 6,
                    fill: new ol.style.Fill({ color: STREET_COLOR }),
                    stroke: new ol.style.Stroke({ color: "#ffffff", width: 2 })
                })
            }));
            drawSource.addFeature(feature);
        });

        // Линия
        if (drawPoints.length >= 2) {
            var line = new ol.Feature({
                geometry: new ol.geom.LineString(
                    drawPoints.map(toViewCoordinate)
                )
            });
            line.setStyle(getDrawStyle());
            drawSource.addFeature(line);
        }
    }

    /* =========================================================
       СОЗДАНИЕ СЛОЁВ
       ========================================================= */

    function createLayers() {
        if (!map) return false;

        streetSource = new ol.source.Vector();
        streetLayer = new ol.layer.Vector({
            source: streetSource,
            zIndex: 50000,
            visible: true
        });
        map.addLayer(streetLayer);

        drawSource = new ol.source.Vector();
        drawLayer = new ol.layer.Vector({
            source: drawSource,
            zIndex: 60000,
            visible: true
        });
        map.addLayer(drawLayer);

        return true;
    }

    /* =========================================================
       РЕДАКТОР
       ========================================================= */

    function toggleEditor() {
        editorActive = !editorActive;

        if (editorActive) {
            enableEditor();
        } else {
            disableEditor();
        }
    }

    function enableEditor() {
        editorActive = true;

        var btn = document.getElementById("tool-streets");
        if (btn) {
            btn.classList.add("active");
            btn.textContent = "🚶 Выйти из редактора улиц";
        }

        var startBtn = document.getElementById("tool-start-street");
        if (startBtn) {
            startBtn.classList.remove("hidden");
        }

        if (streetLayer) {
            streetLayer.setVisible(true);
        }

        showToast("Редактор улиц включён", "success");
        console.log("[PISPOP-GIS] Street editor ENABLED");
    }

    function disableEditor() {
        editorActive = false;
        stopDrawing();

        var btn = document.getElementById("tool-streets");
        if (btn) {
            btn.classList.remove("active");
            btn.textContent = "🚶 Редактор улиц";
        }

        var startBtn = document.getElementById("tool-start-street");
        if (startBtn) {
            startBtn.classList.add("hidden");
        }

        showToast("Редактор улиц выключен");
        console.log("[PISPOP-GIS] Street editor DISABLED");
    }

    /* =========================================================
       РИСОВАНИЕ
       ========================================================= */

    function startDrawing() {
        if (!editorActive) {
            enableEditor();
        }

        if (!map) {
            map = getMap();
            if (!map) {
                showToast("Карта не найдена", "error");
                return;
            }
        }

        stopDrawing();

        isDrawing = true;
        drawPoints = [];
        renderDrawing();

        map.getViewport().style.cursor = "crosshair";

        showDrawingHint();

        // Обработчик клика
        clickHandler = function (event) {
            if (!isDrawing) return;

            var coord = toDataCoordinate(event.coordinate);
            if (!coord) return;

            drawPoints.push([Math.round(coord[0]), Math.round(coord[1])]);
            renderDrawing();

            console.log("[PISPOP-GIS] Street point:", drawPoints[drawPoints.length - 1]);
        };

        // Обработчик двойного клика для завершения
        dblClickHandler = function (event) {
            if (!isDrawing) return;
            event.preventDefault();
            finishDrawing();
        };

        map.on("click", clickHandler);
        map.on("dblclick", dblClickHandler);

        console.log("[PISPOP-GIS] Street drawing started");
    }

    function stopDrawing() {
        isDrawing = false;

        if (map && clickHandler) {
            try {
                map.un("click", clickHandler);
            } catch (e) {}
            clickHandler = null;
        }

        if (map && dblClickHandler) {
            try {
                map.un("dblclick", dblClickHandler);
            } catch (e) {}
            dblClickHandler = null;
        }

        if (map) {
            map.getViewport().style.cursor = "";
        }

        removeDrawingHint();

        if (drawSource) {
            drawSource.clear();
        }

        drawPoints = [];
    }

    function finishDrawing() {
        if (drawPoints.length < 2) {
            showToast("Нужно минимум 2 точки", "error");
            return;
        }

        var name = prompt("Название улицы:", "Новая улица");
        if (name === null) {
            // Отмена
            stopDrawing();
            return;
        }

        var street = {
            id: generateId(),
            name: name.trim() || "Безымянная улица",
            coordinates: drawPoints.map(function (p) { return [p[0], p[1]]; }),
            color: STREET_COLOR,
            createdAt: new Date().toISOString()
        };

        streets.push(street);
        stopDrawing();
        renderStreets();
        saveStreets();

        // Выбираем созданную улицу
        selectStreet(street.id);

        showToast("Улица \"" + street.name + "\" создана", "success");
        console.log("[PISPOP-GIS] Street created:", street);
    }

    function cancelDrawing() {
        stopDrawing();
        showToast("Рисование отменено");
    }

    /* =========================================================
       ПОДСКАЗКА
       ========================================================= */

    function showDrawingHint() {
        var hint = document.getElementById("street-draw-hint");
        if (hint) return;

        hint = document.createElement("div");
        hint.id = "street-draw-hint";
        hint.innerHTML = `
            <strong>🚶 Рисование улицы</strong><br>
            Кликайте по карте для добавления точек.<br>
            <span>Двойной клик — завершить.</span>
            <br><br>
            <button id="street-draw-finish" style="padding:8px 16px;border:none;border-radius:6px;background:#3c6ef6;color:#fff;cursor:pointer;font-weight:600;">Готово</button>
            <button id="street-draw-cancel" style="padding:8px 16px;border:none;border-radius:6px;background:#e5484d;color:#fff;cursor:pointer;font-weight:600;">Отмена</button>
        `;

        hint.style.position = "fixed";
        hint.style.left = "50%";
        hint.style.bottom = "25px";
        hint.style.transform = "translateX(-50%)";
        hint.style.zIndex = "99999";
        hint.style.padding = "16px 20px";
        hint.style.borderRadius = "12px";
        hint.style.background = "rgba(25,25,25,.95)";
        hint.style.color = "#fff";
        hint.style.fontFamily = "'Inter', Arial, sans-serif";
        hint.style.fontSize = "14px";
        hint.style.boxShadow = "0 8px 32px rgba(0,0,0,.4)";
        hint.style.display = "flex";
        hint.style.flexDirection = "column";
        hint.style.alignItems = "center";
        hint.style.gap = "8px";
        hint.style.minWidth = "240px";

        document.body.appendChild(hint);

        document.getElementById("street-draw-finish").addEventListener("click", finishDrawing);
        document.getElementById("street-draw-cancel").addEventListener("click", cancelDrawing);
    }

    function removeDrawingHint() {
        var hint = document.getElementById("street-draw-hint");
        if (hint) hint.remove();
    }

    /* =========================================================
       ВЫБОР УЛИЦЫ
       ========================================================= */

    function setupSelection() {
        if (!map) return;

        map.on("singleclick", function (event) {
            if (isDrawing) return;
            if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking()) return;

            // Если под курсором дом (метка дома всегда лежит поверх
            // линии улицы) - отдаём приоритет выбору дома и не трогаем
            // состояние выбора улицы, иначе дом будет "сам себя"
            // снимать с выбора при каждом клике (см. address-system.js).
            if (window.PISPOP_ADDRESS && window.PISPOP_ADDRESS.hasHouseAtPixel && window.PISPOP_ADDRESS.hasHouseAtPixel(event.pixel)) {
                return;
            }

            var found = null;

            map.forEachFeatureAtPixel(event.pixel, function (feature, layer) {
                if (layer !== streetLayer) return false;
                var data = feature.get("streetData");
                if (data) {
                    found = data;
                    return true;
                }
                return false;
            }, { hitTolerance: 8 });

            if (found) {
                selectStreet(found.id);
            } else {
                deselectStreet();
            }
        });
    }

    function selectStreet(id) {
        var street = streets.find(function (s) { return s.id === id; });
        if (!street) return;

        selectedStreet = street;
        renderStreets();

        document.dispatchEvent(new CustomEvent("pispop:street-selected", {
            detail: street
        }));

        console.log("[PISPOP-GIS] Street selected:", street.name);
    }

    function deselectStreet() {
        selectedStreet = null;
        renderStreets();

        document.dispatchEvent(new CustomEvent("pispop:street-deselected"));

        console.log("[PISPOP-GIS] Street deselected");
    }

    function deleteStreet(street) {
        return fetch("/api/streets/" + encodeURIComponent(street.id), {
            method: "DELETE"
        })
            .then(function () {
                if (window.PISPOP_ADDRESS) {
                    var allHouses = window.PISPOP_ADDRESS.getHouses();
                    var toDelete = allHouses.filter(function (h) {
                        return h.streetId === street.id;
                    });
                    toDelete.forEach(function (h) {
                        fetch("/api/houses/" + encodeURIComponent(h.id), {
                            method: "DELETE"
                        }).catch(function (err) { console.error(err); });
                    });
                    window.PISPOP_ADDRESS.refresh();
                }

                streets = streets.filter(function (s) { return s.id !== street.id; });
                if (selectedStreet && selectedStreet.id === street.id) {
                    deselectStreet();
                }
                renderStreets();
                showToast("Улица удалена", "success");
            })
            .catch(function (err) {
                console.error("Failed to delete street:", err);
                showToast("Ошибка удаления", "error");
            });
    }

    /* =========================================================
       ТОСТЫ
       ========================================================= */

    function showToast(text, type) {
        if (typeof Toastify === "function") {
            Toastify({
                text: text,
                duration: 2500,
                gravity: "bottom",
                position: "center",
                close: true,
                style: {
                    background: type === "error" ? "#c62828" :
                                type === "success" ? "#2e7d32" : "#333"
                }
            }).showToast();
        } else {
            console.log("[PISPOP-GIS]", text);
        }
    }

    /* =========================================================
       КНОПКИ (исправленный обработчик)
       ========================================================= */

    function setupButtons() {
        // Кнопка редактора улиц
        var toggleBtn = document.getElementById("tool-streets");
        if (toggleBtn) {
            // Удаляем старые обработчики
            var newToggleBtn = toggleBtn.cloneNode(true);
            toggleBtn.parentNode.replaceChild(newToggleBtn, toggleBtn);
            
            newToggleBtn.addEventListener("click", function (e) {
                e.preventDefault();
                console.log("[PISPOP-GIS] Toggle streets button clicked");
                toggleEditor();
            });
            console.log("[PISPOP-GIS] tool-streets button connected");
        } else {
            console.warn("[PISPOP-GIS] #tool-streets not found!");
        }

        // Кнопка рисования улицы
        var startBtn = document.getElementById("tool-start-street");
        if (startBtn) {
            var newStartBtn = startBtn.cloneNode(true);
            startBtn.parentNode.replaceChild(newStartBtn, startBtn);
            
            newStartBtn.addEventListener("click", function (e) {
                e.preventDefault();
                console.log("[PISPOP-GIS] Start street button clicked");
                if (isDrawing) {
                    finishDrawing();
                } else {
                    startDrawing();
                }
            });
            // Изначально скрыта, если редактор не активен
            if (!editorActive) {
                newStartBtn.classList.add("hidden");
            }
            console.log("[PISPOP-GIS] tool-start-street button connected");
        } else {
            console.warn("[PISPOP-GIS] #tool-start-street not found!");
        }
    }

    /* =========================================================
       ИНИЦИАЛИЗАЦИЯ
       ========================================================= */

    async function init() {
        console.log("[PISPOP-GIS] Initializing streets...");

        map = getMap();
        if (!map) {
            console.error("[PISPOP-GIS] Map not found");
            return;
        }

        if (!createLayers()) {
            console.error("[PISPOP-GIS] Failed to create layers");
            return;
        }

        await loadStreets();
        renderStreets();

        setupSelection();
        setupButtons();

        console.log("[PISPOP-GIS] Streets initialized with", streets.length, "streets");
    }

    /* =========================================================
       ПУБЛИЧНЫЙ API
       ========================================================= */

    window.PISPOP_STREETS = {
        getStreets: function () { return streets; },
        getSelectedStreet: function () { return selectedStreet; },
        toggle: toggleEditor,
        startDrawing: startDrawing,
        finishDrawing: finishDrawing,
        cancelDrawing: cancelDrawing,
        refresh: function () {
            return loadStreets().then(function () {
                renderStreets();
            });
        },
        selectStreet: selectStreet,
        deselectStreet: deselectStreet,
        deleteStreet: deleteStreet,
        isDrawing: function () { return isDrawing; },
        isActive: function () { return editorActive; }
    };

    // Запуск
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }

})();