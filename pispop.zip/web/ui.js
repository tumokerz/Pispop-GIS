/*
 * ============================================================
 * PISPOP-GIS
 * ui.js
 *
 * Связывает:
 *  - узкую колонку иконок (rail): поиск / маршруты / радио
 *  - широкую сворачиваемую панель (sidebar) с тремя вкладками,
 *    соответствующими кнопкам rail
 *  - категории-фильтры меток
 *  - карточки объектов (метка / территория) внутри панели
 *  - режим рисования территорий
 *  - маршрутизатор (routes.js)
 *
 * ============================================================
 */

(function () {

    "use strict";

    var map = null;

    var territoryDraw = null;
    var territoryDrawSource = null;
    var territoryDrawLayer = null;
    var drawingTerritory = false;

    var houseBoundaryDraw = null;
    var houseBoundaryDrawSource = null;
    var houseBoundaryDrawLayer = null;
    var drawingHouseBoundary = false;
    var houseBoundaryTarget = null;

    /*
     * Активная категория-фильтр (null = показывать все метки).
     */
    var activeCategory = null;

    /*
     * Контекст открытой карточки:
     * { kind: "marker" | "territory", data: {...}, isNew: bool }
     */
    var cardContext = null;

    // Временная метка для поиска
    var tempMarkerFeature = null;
    var tempMarkerLayer = null;
    var tempMarkerTimeout = null;


    /* ========================================================
       ФУНКЦИЯ pointInPolygon (глобальная для других модулей)
       ======================================================== */

    window.pointInPolygon = function (x, z, coordinates) {
        var inside = false;
        for (var i = 0, j = coordinates.length - 1; i < coordinates.length; j = i++) {
            var xi = coordinates[i][0];
            var zi = coordinates[i][1];
            var xj = coordinates[j][0];
            var zj = coordinates[j][1];
            var intersects = ((zi > z) !== (zj > z)) &&
                (x < (xj - xi) * (z - zi) / (zj - zi) + xi);
            if (intersects) inside = !inside;
        }
        return inside;
    };


    /* ========================================================
       ПОЛУЧЕНИЕ КАРТЫ
       ======================================================== */

    function getMap() {

        if (
            window.unmined &&
            window.unmined.map &&
            typeof window.unmined.map.getView === "function"
        ) {
            return window.unmined.map;
        }

        if (
            window.unmined &&
            window.unmined.olMap &&
            typeof window.unmined.olMap.getView === "function"
        ) {
            return window.unmined.olMap;
        }

        if (window.unmined) {

            var keys = Object.keys(window.unmined);

            for (var i = 0; i < keys.length; i++) {

                var value = window.unmined[keys[i]];

                if (
                    value &&
                    typeof value.getView === "function" &&
                    typeof value.addLayer === "function"
                ) {
                    return value;
                }

            }

        }

        return null;

    }


    /* ========================================================
       ПРЕОБРАЗОВАНИЕ КООРДИНАТ
       ======================================================== */

    function toDataCoordinate(viewCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return viewCoordinate;
        }

        return ol.proj.transform(
            viewCoordinate,
            window.unmined.viewProjection,
            window.unmined.dataProjection
        );

    }

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }


    /* ========================================================
       ВРЕМЕННАЯ МЕТКА ДЛЯ ПОИСКА
       ======================================================== */

    function createTempMarkerLayer() {
        if (tempMarkerLayer) return;

        tempMarkerLayer = new ol.layer.Vector({
            source: new ol.source.Vector(),
            zIndex: 300000,
            style: function (feature) {
                var isPulsing = feature.get("pulsing");
                var radius = isPulsing ? 20 : 12;

                return new ol.style.Style({
                    image: new ol.style.Circle({
                        radius: radius,
                        fill: new ol.style.Fill({
                            color: isPulsing ? "rgba(255, 215, 0, 0.3)" : "rgba(255, 215, 0, 0.6)"
                        }),
                        stroke: new ol.style.Stroke({
                            color: "#ffd700",
                            width: 3
                        })
                    }),
                    text: new ol.style.Text({
                        text: "📍",
                        font: "24px sans-serif",
                        textAlign: "center",
                        textBaseline: "middle",
                        offsetY: -2
                    })
                });
            }
        });

        map.addLayer(tempMarkerLayer);
    }

    function showTempMarker(coordinate) {
        clearTempMarker();

        createTempMarkerLayer();

        var viewCoord = toViewCoordinate(coordinate);

        var feature = new ol.Feature({
            geometry: new ol.geom.Point(viewCoord),
            pulsing: true
        });

        tempMarkerLayer.getSource().addFeature(feature);
        tempMarkerFeature = feature;

        var pulse = true;
        var interval = setInterval(function () {
            if (!tempMarkerFeature) {
                clearInterval(interval);
                return;
            }
            pulse = !pulse;
            tempMarkerFeature.set("pulsing", pulse);
            tempMarkerLayer.changed();
        }, 500);

        if (tempMarkerTimeout) {
            clearTimeout(tempMarkerTimeout);
        }

        tempMarkerTimeout = setTimeout(function () {
            clearTempMarker();
            clearInterval(interval);
        }, 10000);

        feature._pulseInterval = interval;

        showTempMarkerActions(coordinate);
    }

    function showTempMarkerActions(coordinate) {
        var actions = document.getElementById("temp-marker-actions");
        if (!actions) {
            actions = document.createElement("div");
            actions.id = "temp-marker-actions";
            actions.style.position = "fixed";
            actions.style.bottom = "80px";
            actions.style.left = "50%";
            actions.style.transform = "translateX(-50%)";
            actions.style.zIndex = "99998";
            actions.style.display = "flex";
            actions.style.gap = "10px";
            actions.style.background = "rgba(25,25,25,.92)";
            actions.style.padding = "12px 20px";
            actions.style.borderRadius = "12px";
            actions.style.boxShadow = "0 8px 32px rgba(0,0,0,.4)";
            actions.style.fontFamily = "'Inter', Arial, sans-serif";
            document.body.appendChild(actions);
        }

        actions.innerHTML = `
            <span style="color:#fff;font-size:14px;margin-right:8px;">
                📍 X: ${coordinate[0]}  Z: ${coordinate[1]}
            </span>
            <button id="temp-marker-save" style="padding:8px 16px;border:none;border-radius:8px;background:#3c6ef6;color:#fff;cursor:pointer;font-weight:600;font-size:13px;">
                💾 Сохранить метку
            </button>
            <button id="temp-marker-close" style="padding:8px 12px;border:none;border-radius:8px;background:rgba(255,255,255,0.15);color:#fff;cursor:pointer;font-size:13px;">
                ✕
            </button>
        `;

        actions.style.display = "flex";

        document.getElementById("temp-marker-save").addEventListener("click", function () {
            var presetCategory = activeCategory && activeCategory.kind === "marker"
                ? activeCategory.id
                : "default";

            openMarkerCard(
                {
                    x: coordinate[0],
                    z: coordinate[1],
                    title: "",
                    description: "",
                    address: "",
                    category: presetCategory,
                    color: categoryColor(presetCategory)
                },
                true
            );

            clearTempMarker();
            actions.style.display = "none";
        });

        document.getElementById("temp-marker-close").addEventListener("click", function () {
            clearTempMarker();
            actions.style.display = "none";
        });
    }

    function clearTempMarker() {
        if (tempMarkerFeature) {
            if (tempMarkerFeature._pulseInterval) {
                clearInterval(tempMarkerFeature._pulseInterval);
            }
            if (tempMarkerLayer && tempMarkerLayer.getSource()) {
                tempMarkerLayer.getSource().clear();
            }
            tempMarkerFeature = null;
        }

        if (tempMarkerTimeout) {
            clearTimeout(tempMarkerTimeout);
            tempMarkerTimeout = null;
        }

        var actions = document.getElementById("temp-marker-actions");
        if (actions) {
            actions.style.display = "none";
        }
    }


    /* ========================================================
       DOM ССЫЛКИ
       ======================================================== */

    var el = {};

    function cacheEls() {

        el.sidebar = document.getElementById("sidebar");
        el.sidebarCollapse = document.getElementById("sidebar-collapse");

        el.railSearch = document.getElementById("rail-search");
        el.railRoutes = document.getElementById("rail-routes");
        el.railRadio = document.getElementById("rail-radio");
        el.railMinigames = document.getElementById("rail-minigames");

        el.panelSearch = document.getElementById("panel-search");
        el.panelRoutes = document.getElementById("panel-routes");
        el.panelRadio = document.getElementById("panel-radio");
        el.panelMinigames = document.getElementById("panel-minigames");
        el.panelProfile = document.getElementById("profile-sidebar-card");
        el.profileSidebarBack = document.getElementById("profile-sidebar-back");

        el.mapTitle = document.getElementById("map-title");

        el.searchInput = document.getElementById("search-input");
        el.searchClear = document.getElementById("search-clear");
        el.searchResults = document.getElementById("search-results");

        el.categoryFilters = document.getElementById("category-filters");
        el.categoryResults = document.getElementById("category-results");
        el.markerPhotoInput = document.getElementById("marker-photo-input");
        el.markerPhotoPreview = document.getElementById("marker-photo-preview");
        el.viewCardPhotos = document.getElementById("panel-view-card-photos");
        el.markerPhotoModal = document.getElementById("marker-photo-modal");
        el.markerPhotoModalImage = document.getElementById("marker-photo-modal-image");
        el.markerPhotoModalClose = document.getElementById("marker-photo-modal-close");

        el.layerSettlements = document.getElementById("layer-settlements");
        el.layerMarkers = document.getElementById("layer-markers");
        el.layerRoads = document.getElementById("layer-roads");

        el.toolAddMarker = document.getElementById("tool-add-marker");
        el.toolAddTerritory = document.getElementById("tool-add-territory");
        el.toolAddWater = document.getElementById("tool-add-water");
        el.toolAutoWater = document.getElementById("tool-auto-water");
        el.toolAutoWaterFile = document.getElementById("tool-auto-water-file");
        el.toolAutoWaterStatus = document.getElementById("tool-auto-water-status");
        el.toolRoads = document.getElementById("tool-roads");

        el.settlementList = document.getElementById("settlement-list");
        el.markerList = document.getElementById("marker-list");

        el.addingHint = document.getElementById("adding-hint");
        el.addingCancel = document.getElementById("adding-cancel");

        el.routeFrom = document.getElementById("route-from");
        el.routeTo = document.getElementById("route-to");
        el.routeSwap = document.getElementById("route-swap");
        el.routePick = document.getElementById("route-pick");
        el.routeClear = document.getElementById("route-clear");
        el.routeSummary = document.getElementById("route-summary");
        el.routeGuideTabs = document.getElementById("route-guide-tabs");
        el.routeGuideWalkBtn = document.getElementById("route-guide-walk-btn");
        el.routeGuideIceBtn = document.getElementById("route-guide-ice-btn");
        el.routeGuideWalk = document.getElementById("route-guide-walk");
        el.routeGuideIce = document.getElementById("route-guide-ice");

        /* ===== КАРТОЧКИ ВНУТРИ ПАНЕЛИ ===== */

        el.cardContainer = document.getElementById("panel-card-container");
        el.cardBack = document.getElementById("panel-card-back");
        el.cardTitle = document.getElementById("panel-card-title");
        el.cardColor = document.getElementById("panel-card-color");
        el.cardAddress = document.getElementById("panel-card-address");
        el.cardDescription = document.getElementById("panel-card-description");
        el.cardCategories = document.getElementById("panel-card-categories");
        el.cardDelete = document.getElementById("panel-card-delete");
        el.cardSave = document.getElementById("panel-card-save");

        /* view-card внутри панели */
        el.viewCardContainer = document.getElementById("panel-view-card-container");
        el.viewCardBack = document.getElementById("panel-view-card-back");
        el.viewCardIcon = document.getElementById("panel-view-card-icon");
        el.viewCardTitle = document.getElementById("panel-view-card-title");
        el.viewCardName = document.getElementById("panel-view-card-name");
        el.viewCardAddress = document.getElementById("panel-view-card-address");
        el.viewCardDescription = document.getElementById("panel-view-card-description");
        el.viewCardEdit = document.getElementById("panel-view-card-edit");
        el.viewCardAddMarker = document.getElementById("panel-view-card-add-marker");
        el.viewCardBoundary = document.getElementById("panel-view-card-boundary");
        el.viewCardRouteFrom = document.getElementById("panel-view-card-route-from");
        el.viewCardRouteTo = document.getElementById("panel-view-card-route-to");
        el.viewCardClose = document.getElementById("panel-view-card-close");

    }


    /* ========================================================
       ЗАГОЛОВОК КАРТЫ
       ======================================================== */

    function setupMapTitle() {

        if (
            typeof UnminedMapProperties !== "undefined" &&
            UnminedMapProperties.worldName
        ) {
            el.mapTitle.textContent = UnminedMapProperties.worldName;
        }

    }


    /* ========================================================
       ПАНЕЛЬ / RAIL: ПЕРЕКЛЮЧЕНИЕ ВКЛАДОК
       ======================================================== */

    function showPanel(name) {

        hideAllCards();

        el.panelSearch.classList.toggle("hidden", name !== "search");
        el.panelRoutes.classList.toggle("hidden", name !== "routes");
        el.panelRadio.classList.toggle("hidden", name !== "radio");
        el.panelMinigames.classList.toggle("hidden", name !== "minigames");
        if (el.panelProfile) el.panelProfile.classList.toggle("hidden", name !== "profile");

        el.railSearch.classList.toggle("active", name === "search");
        el.railRoutes.classList.toggle("active", name === "routes");
        el.railRadio.classList.toggle("active", name === "radio");
        el.railMinigames.classList.toggle("active", name === "minigames");

        el.sidebar.classList.remove("collapsed");
        document.body.classList.remove("sidebar-collapsed");

    }

    function setupAdminGate() {
        document.addEventListener("click", function(event){
            var adminEl = event.target.closest(".admin-only");
            if (adminEl && (!window.PISPOP_AUTH || !window.PISPOP_AUTH.isAdmin())) {
                event.preventDefault(); event.stopPropagation();
                if(window.PISPOP_AUTH) window.PISPOP_AUTH.open();
            }
        }, true);
    }

    function showProfilePanel() {
        hideAllCards();
        if (el.panelSearch) el.panelSearch.classList.add("hidden");
        if (el.panelRoutes) el.panelRoutes.classList.add("hidden");
        if (el.panelRadio) el.panelRadio.classList.add("hidden");
        if (el.panelMinigames) el.panelMinigames.classList.add("hidden");
        if (el.panelProfile) el.panelProfile.classList.remove("hidden");
        if (el.sidebar) el.sidebar.classList.remove("collapsed");
        document.body.classList.remove("sidebar-collapsed");
    }

    function setupRail() {

        el.railSearch.addEventListener("click", function () {

            if (
                el.railSearch.classList.contains("active") &&
                !el.sidebar.classList.contains("collapsed")
            ) {
                collapseSidebar();
                return;
            }

            showPanel("search");

        });

        el.railRoutes.addEventListener("click", function () {

            if (
                el.railRoutes.classList.contains("active") &&
                !el.sidebar.classList.contains("collapsed")
            ) {
                collapseSidebar();
                return;
            }

            showPanel("routes");

        });

        el.railMinigames.addEventListener("click", function () {
            if (el.railMinigames.classList.contains("active") && !el.sidebar.classList.contains("collapsed")) { collapseSidebar(); return; }
            showPanel("minigames");
        });

        el.railRadio.addEventListener("click", function () {

            if (
                el.railRadio.classList.contains("active") &&
                !el.sidebar.classList.contains("collapsed")
            ) {
                collapseSidebar();
                return;
            }

            showPanel("radio");

        });

    }


    /* ========================================================
       СВОРАЧИВАНИЕ ПАНЕЛИ
       ======================================================== */

    function collapseSidebar() {

        el.sidebar.classList.add("collapsed");
        document.body.classList.add("sidebar-collapsed");

    }

    function expandSidebar() {

        el.sidebar.classList.remove("collapsed");
        document.body.classList.remove("sidebar-collapsed");

    }

    function setupCollapse() {

        el.sidebarCollapse.addEventListener("click", function () {

            if (el.sidebar.classList.contains("collapsed")) {
                expandSidebar();
            } else {
                collapseSidebar();
            }

        });

    }


    /* ========================================================
       СКРЫТИЕ ВСЕХ КАРТОЧЕК
       ======================================================== */

    function hideAllCards() {
        el.cardContainer.classList.add("hidden");
        el.viewCardContainer.classList.add("hidden");
        cardContext = null;
        viewCardContext = null;
    }


    /* ========================================================
       СЛОИ
       ======================================================== */

    function findLayerByZIndex(targetZIndex) {

        if (!map) {
            return null;
        }

        var found = null;

        map.getLayers().forEach(function (layer) {

            if (layer.getZIndex && layer.getZIndex() === targetZIndex) {
                found = layer;
            }

        });

        return found;

    }

    // Слои как отдельный пользовательский раздел убраны.
    // Функция оставлена как совместимый no-op, чтобы старый код инициализации
    // не падал, если HTML больше не содержит layer-* элементов.
    function setupLayerToggles() {
        return;
    }

    /* ========================================================
       КАТЕГОРИИ-ФИЛЬТРЫ
       ======================================================== */

    // ===== ПОЛНЫЙ РЕЗЕРВНЫЙ СПИСОК КАТЕГОРИЙ =====
    var FALLBACK_CATEGORIES = [
        { id: "warehouse", label: "Склады", color: "#8d6e63", icon: "📦", kind: "marker" },
        { id: "farm", label: "Фермы", color: "#588157", icon: "🌾", kind: "marker" },
        { id: "factory", label: "Заводы", color: "#6d597a", icon: "🏭", kind: "marker" },
        { id: "landmark", label: "Достопримечательности", color: "#e09f3e", icon: "🏛", kind: "marker" },
        { id: "parking", label: "Парковка", color: "#457b9d", icon: "🅿️", kind: "marker" },
        { id: "park", label: "Парки", color: "#2a9d8f", icon: "🌳", kind: "marker" },
        { id: "ice_station", label: "Станция ледяной дороги", color: "#8cbbd9", icon: "🚉", kind: "marker" },
        { id: "rail_station", label: "ЖД-станция", color: "#6b7280", icon: "🚆", kind: "marker" },
        { id: "metro_station", label: "Станция метро", color: "#b04cff", icon: "🚇", kind: "marker" },
        { id: "food", label: "Места питания", color: "#e76f51", icon: "🍽️", kind: "marker" },
        { id: "statue", label: "Статуи", color: "#b8860b", icon: "🗿", kind: "marker" },
        { id: "mobspawn", label: "Фермы мобов", color: "#4e4e4c", icon: "💀", kind: "marker" },
        { id: "shop", label: "Магазин", color: "#f59e0b", icon: "🛒", kind: "marker" }
    ];

    function getAllCategories() {

        var markerCategories = [];

        // Пытаемся получить категории из markers.js
        if (window.PISPOP_MARKERS && window.PISPOP_MARKERS.categories) {
            markerCategories = window.PISPOP_MARKERS.categories
                .filter(function (c) { return c.id !== "default"; })
                .map(function (c) {
                    return Object.assign({ kind: "marker" }, c);
                });
        }

        // Если категорий нет — используем резервный список
        if (markerCategories.length === 0) {
            markerCategories = FALLBACK_CATEGORIES.slice();
        }

        // ЯВНО ДОБАВЛЯЕМ КАТЕГОРИИ, ЕСЛИ ИХ НЕТ
        var categoryIds = markerCategories.map(function(c) { return c.id; });
        
        if (categoryIds.indexOf("mobspawn") === -1) {
            markerCategories.push({
                id: "mobspawn",
                label: "Фермы мобов",
                color: "#4e4e4c",
                icon: "💀",
                kind: "marker"
            });
        }
        
        if (categoryIds.indexOf("shop") === -1) {
            markerCategories.push({
                id: "shop",
                label: "Магазин",
                color: "#f59e0b",
                icon: "🛒",
                kind: "marker"
            });
        }

        var territoryCategories = [];
        if (window.PISPOP_SETTLEMENTS && window.PISPOP_SETTLEMENTS.categories) {
            territoryCategories = window.PISPOP_SETTLEMENTS.categories
                .map(function (c) {
                    return Object.assign({ kind: "territory" }, c);
                });
        }

        return markerCategories.concat(territoryCategories);

    }

    function renderCategoryFilters() {

        el.categoryFilters.innerHTML = "";

        var categories = getAllCategories();

        categories.forEach(function (category) {

            var chip = document.createElement("button");
            chip.type = "button";
            chip.className = "category-filter-chip";
            chip.dataset.category = category.id;

            if (
                activeCategory &&
                activeCategory.id === category.id &&
                activeCategory.kind === category.kind
            ) {
                chip.classList.add("selected");
            }

            // Структура с кругом для иконки
            var wrap = document.createElement("span");
            wrap.className = "category-filter-icon-wrap";

            var icon = document.createElement("span");
            icon.className = "category-filter-icon";
            icon.textContent = category.icon;

            var label = document.createElement("span");
            label.className = "category-filter-label";
            label.textContent = category.label;

            wrap.appendChild(icon);
            chip.appendChild(wrap);
            chip.appendChild(label);

            chip.addEventListener("click", function () {

                var isSame =
                    activeCategory &&
                    activeCategory.id === category.id &&
                    activeCategory.kind === category.kind;

                activeCategory = isSame ? null : category;

                renderCategoryFilters();
                renderCategoryResults();

                // Обновляем подсветку меток
                if (window.PISPOP_MARKERS) {
                    var highlightCat = activeCategory && activeCategory.kind === "marker"
                        ? activeCategory.id
                        : null;
                    window.PISPOP_MARKERS.setHighlightCategory(highlightCat);
                }

                // Обновляем подсветку территорий
                if (window.PISPOP_SETTLEMENTS && typeof window.PISPOP_SETTLEMENTS.setHighlightCategory === "function") {
                    var highlightCat = activeCategory && activeCategory.kind === "territory"
                        ? activeCategory.id
                        : null;
                    window.PISPOP_SETTLEMENTS.setHighlightCategory(highlightCat);
                }

            });

            el.categoryFilters.appendChild(chip);

        });

    }


    /* ========================================================
       СПИСОК ОБЪЕКТОВ КАТЕГОРИИ (в видимой области карты)
       ======================================================== */

    function getViewportExtentData() {

        if (!map) {
            return null;
        }

        var view = map.getView();
        var size = map.getSize();

        if (!view || !size) {
            return null;
        }

        var viewExtent = view.calculateExtent(size);

        var corner1 = toDataCoordinate([viewExtent[0], viewExtent[1]]);
        var corner2 = toDataCoordinate([viewExtent[2], viewExtent[3]]);

        return {
            minX: Math.min(corner1[0], corner2[0]),
            maxX: Math.max(corner1[0], corner2[0]),
            minZ: Math.min(corner1[1], corner2[1]),
            maxZ: Math.max(corner1[1], corner2[1])
        };

    }

    function pointInExtent(x, z, extent) {

        return (
            x >= extent.minX && x <= extent.maxX &&
            z >= extent.minZ && z <= extent.maxZ
        );

    }

    function polygonIntersectsExtent(coordinates, extent) {

        return coordinates.some(function (point) {
            return pointInExtent(point[0], point[1], extent);
        });

    }

    function renderCategoryResults() {

        if (!el.categoryResults) {
            return;
        }

        el.categoryResults.innerHTML = "";

        if (!activeCategory) {
            el.categoryResults.classList.add("hidden");
            updateMarkerHighlight();
            return;
        }

        var extent = getViewportExtentData();

        el.categoryResults.classList.remove("hidden");

        var items = [];

        if (activeCategory.kind === "marker") {

            var markers =
                (window.PISPOP_MARKERS && window.PISPOP_MARKERS.getMarkers()) || [];

            items = markers.filter(function (marker) {

                if (marker.category !== activeCategory.id) {
                    return false;
                }

                if (!extent) {
                    return true;
                }

                return pointInExtent(marker.x, marker.z, extent);

            });

        } else {

            var settlements =
                (window.PISPOP_SETTLEMENTS && window.PISPOP_SETTLEMENTS.getSettlements()) || [];

            items = settlements.filter(function (settlement) {

                if (settlement.category !== activeCategory.id) {
                    return false;
                }

                if (!extent || !Array.isArray(settlement.coordinates)) {
                    return true;
                }

                return polygonIntersectsExtent(settlement.coordinates, extent);

            });

        }

        if (items.length === 0) {

            var empty = document.createElement("div");
            empty.className = "entity-list-empty";
            empty.textContent = "В видимой области карты ничего нет";
            el.categoryResults.appendChild(empty);

            updateMarkerHighlight();

            return;

        }

        items.forEach(function (item) {

            var row = document.createElement("div");
            row.className = "entity-list-item entity-list-item-selectable";

            var label =
                activeCategory.kind === "marker"
                    ? (item.title || "Без названия")
                    : item.name;

            var iconSpan = document.createElement("span");
            iconSpan.textContent = activeCategory.icon;

            var labelSpan = document.createElement("span");
            labelSpan.textContent = label;

            row.appendChild(iconSpan);
            row.appendChild(labelSpan);

            row.addEventListener("click", function () {

                if (activeCategory.kind === "marker") {
                    window.PISPOP_MARKERS.panTo(item);
                    openViewCard("marker", item);
                } else {
                    focusOnTerritory(item);
                }

            });

            el.categoryResults.appendChild(row);

        });

        updateMarkerHighlight();

    }

    function updateMarkerHighlight() {

        if (window.PISPOP_MARKERS && typeof window.PISPOP_MARKERS.setHighlightCategory === "function") {

            window.PISPOP_MARKERS.setHighlightCategory(
                activeCategory && activeCategory.kind === "marker"
                    ? activeCategory.id
                    : null
            );

        }

    }


    /* ========================================================
       ПОИСК
       ======================================================== */

    function categoryColor(categoryId) {

        var found = window.PISPOP_MARKERS.categories.find(function (c) {
            return c.id === categoryId;
        });

        return found ? found.color : "#6b7280";

    }


    /* ========================================================
       ПРИВЯЗКА УЛИЦЫ К ТЕРРИТОРИИ (НАСЕЛЁННОМУ ПУНКТУ)
       ======================================================== */

    function findTerritoryForPoint(x, z) {

        var settlements =
            (window.PISPOP_SETTLEMENTS &&
                window.PISPOP_SETTLEMENTS.getSettlements()) || [];

        return settlements.find(function (settlement) {

            return (
                Array.isArray(settlement.coordinates) &&
                window.pointInPolygon(x, z, settlement.coordinates)
            );

        }) || null;

    }

    function findTerritoryForStreet(street) {

        if (!Array.isArray(street.coordinates) || street.coordinates.length === 0) {
            return null;
        }

        var firstPoint = street.coordinates[0];

        return findTerritoryForPoint(firstPoint[0], firstPoint[1]);

    }


    /* ========================================================
       ПОИСК ПО КООРДИНАТАМ
       ======================================================== */

    function parseCoordinateQuery(query) {

        var cleaned = query
            .toLowerCase()
            .replace(/x\s*[:=]/g, "")
            .replace(/z\s*[:=]/g, "")
            .trim();

        var match = cleaned.match(
            /^(-?\d+(?:\.\d+)?)\s*[,;\s]\s*(-?\d+(?:\.\d+)?)$/
        );

        if (!match) {
            return null;
        }

        return [parseFloat(match[1]), parseFloat(match[2])];

    }

    function goToCoordinate(coordinate) {

        if (!map) {
            return;
        }

        map.getView().animate({
            center: toViewCoordinate(coordinate),
            zoom: map.getView().getMaxZoom(),
            duration: 400
        });

        if (window.PISPOP_SETTLEMENTS) {
            window.PISPOP_SETTLEMENTS.hide();
        }

        setTimeout(function () {
            showTempMarker(coordinate);
        }, 500);
    }

    function searchTextMatch(value, q) {
        return String(value || "").toLowerCase().includes(q);
    }

    function searchFocusAndOpen(kind, item) {
        if (!item) return;

        if (kind === "marker") {
            if (window.PISPOP_MARKERS && window.PISPOP_MARKERS.panTo) {
                window.PISPOP_MARKERS.panTo(item);
            }
            openViewCard("marker", item);
            return;
        }

        if (kind === "territory") {
            if (window.PISPOP_SETTLEMENTS && window.PISPOP_SETTLEMENTS.show) {
                window.PISPOP_SETTLEMENTS.show(item);
            }
            focusOnTerritory(item);
            openViewCard("territory", item);
            return;
        }

        if (kind === "street") {
            if (Array.isArray(item.coordinates) && item.coordinates.length) {
                goToCoordinate(item.coordinates[0]);
            }
            openViewCard("street", item);
            return;
        }

        if (kind === "house") {
            if (typeof item.x === "number" && typeof item.z === "number") {
                goToCoordinate([item.x, item.z]);
            }
            openViewCard("house", item);
        }
    }

    function renderSearchResults(query) {
        var q = query.trim().toLowerCase();

        if (!q) {
            el.searchResults.classList.remove("visible");
            el.searchResults.innerHTML = "";
            clearTempMarker();
            return;
        }

        var coordinate = parseCoordinateQuery(query);

        if (coordinate) {
            el.searchResults.innerHTML = "";

            var item = document.createElement("div");
            item.className = "search-result-item";
            item.innerHTML =
                '<span class="search-result-dot" style="background:#ffd700"></span>' +
                '<span class="search-result-name"></span>' +
                '<span class="search-result-type">Координаты</span>';

            item.querySelector(".search-result-name").textContent =
                "X: " + coordinate[0] + "   Z: " + coordinate[1];

            item.addEventListener("click", function () {
                goToCoordinate(coordinate);
                el.searchResults.classList.remove("visible");
                el.searchInput.value = "";
            });

            el.searchResults.appendChild(item);
            el.searchResults.classList.add("visible");
            return;
        }

        clearTempMarker();

        /*
         * Основной поиск — ГЛОБАЛЬНЫЙ.
         * Личные метки не ограничивают поиск: они лишь дополнительно
         * помечаются как «Моя метка» и используются отдельно в подсказках
         * полей маршрутизации.
         *
         * Результатов немного, чтобы список оставался компактным внутри
         * большой левой колонки.
         */
        var results = [];
        var markers = (window.PISPOP_MARKERS && window.PISPOP_MARKERS.getMarkers()) || [];
        var settlements = (window.PISPOP_SETTLEMENTS && window.PISPOP_SETTLEMENTS.getSettlements()) || [];
        var streets = (window.PISPOP_STREETS && window.PISPOP_STREETS.getStreets()) || [];
        var houses = (window.PISPOP_ADDRESS && window.PISPOP_ADDRESS.getHouses()) || [];

        markers.forEach(function (marker) {
            if (searchTextMatch(marker.title, q) || searchTextMatch(marker.description, q) || searchTextMatch(marker.address, q)) {
                results.push({ kind: "marker", data: marker, title: marker.title || "Без названия", type: "Моя метка", icon: categoryIconForSearch(marker.category, "📍") });
            }
        });

        settlements.forEach(function (settlement) {
            if (searchTextMatch(settlement.name, q) || searchTextMatch(settlement.description, q)) {
                results.push({ kind: "territory", data: settlement, title: settlement.name || "Без названия", type: "Населённый пункт", icon: "🏘️" });
            }
        });

        streets.forEach(function (street) {
            if (searchTextMatch(street.name, q) || searchTextMatch(street.description, q)) {
                results.push({ kind: "street", data: street, title: street.name || "Без названия", type: "Улица", icon: "🚶" });
            }
        });

        houses.forEach(function (house) {
            var street = streets.find(function (st) { return st.id === house.streetId; });
            var streetName = street && street.name ? street.name : (house.streetName || "Улица");
            var address = streetName + ", д. " + (house.number || "?");
            if (searchTextMatch(address, q) || searchTextMatch(house.number, q)) {
                results.push({ kind: "house", data: house, title: address, type: "Дом", icon: "🏠" });
            }
        });

        // Сначала более точные совпадения по началу названия.
        results.sort(function (a, b) {
            var aq = a.title.toLowerCase().indexOf(q);
            var bq = b.title.toLowerCase().indexOf(q);
            if (aq !== bq) return aq - bq;
            return a.title.localeCompare(b.title, "ru");
        });

        results = results.slice(0, 8);
        el.searchResults.innerHTML = "";

        if (!results.length) {
            var empty = document.createElement("div");
            empty.className = "search-empty";
            empty.textContent = "Ничего не найдено";
            el.searchResults.appendChild(empty);
            el.searchResults.classList.add("visible");
            return;
        }

        results.forEach(function (result) {
            var row = document.createElement("div");
            row.className = "search-result-item";
            row.innerHTML =
                '<span class="search-result-dot search-result-icon"></span>' +
                '<span class="search-result-name"></span>' +
                '<span class="search-result-type"></span>';

            row.querySelector(".search-result-icon").textContent = result.icon;
            row.querySelector(".search-result-name").textContent = result.title;
            row.querySelector(".search-result-type").textContent =
                result.kind === "marker" && result.data.ownerId
                    ? "Моя метка"
                    : result.type;

            row.addEventListener("click", function () {
                searchFocusAndOpen(result.kind, result.data);
                el.searchResults.classList.remove("visible");
                el.searchInput.value = "";
            });

            el.searchResults.appendChild(row);
        });

        el.searchResults.classList.add("visible");
    }

    function categoryIconForSearch(category, fallback) {
        var cats = (window.PISPOP_MARKERS && window.PISPOP_MARKERS.categories) || [];
        var found = cats.find(function (c) { return c.id === category; });
        return found ? found.icon : fallback;
    }

    function setupSearch() {

        el.searchInput.addEventListener("input", function () {
            renderSearchResults(el.searchInput.value);
        });

        el.searchClear.addEventListener("click", function () {
            el.searchInput.value = "";
            renderSearchResults("");
            clearTempMarker();
        });

        document.addEventListener("click", function (event) {

            var withinSearch =
                event.target.closest("#search-wrap") ||
                event.target.closest("#search-results");

            if (!withinSearch) {
                el.searchResults.classList.remove("visible");
            }

        });

    }


    /* ========================================================
       СПИСОК НАСЕЛЁННЫХ ПУНКТОВ
       ======================================================== */

    function renderSettlementList() {

        if (!el.settlementList) {
            return;
        }

        var settlements =
            (window.PISPOP_SETTLEMENTS &&
                window.PISPOP_SETTLEMENTS.getSettlements()) || [];

        el.settlementList.innerHTML = "";

        if (settlements.length === 0) {

            var empty = document.createElement("div");
            empty.className = "entity-list-empty";
            empty.textContent = "Пока нет населённых пунктов";
            el.settlementList.appendChild(empty);
            return;

        }

        settlements.forEach(function (settlement) {

            var item = document.createElement("div");
            item.className = "entity-list-item";

            item.innerHTML =
                '<span class="search-result-dot" style="background:' +
                (settlement.borderColor || "#3c82f6") +
                '"></span><span></span>';

            item.querySelector("span:last-child").textContent =
                settlement.name;

            item.addEventListener("click", function () {
                focusOnTerritory(settlement);
            });

            el.settlementList.appendChild(item);

        });

    }


    /* ========================================================
       СПИСОК МЕТОК (с учётом фильтра)
       ======================================================== */

    function renderMarkerList() {

        if (!el.markerList) {
            return;
        }

        var markers =
            (window.PISPOP_MARKERS && window.PISPOP_MARKERS.getMarkers()) || [];

        var filtered = activeCategory
            ? markers.filter(function (m) { return m.category === activeCategory; })
            : markers;

        el.markerList.innerHTML = "";

        if (filtered.length === 0) {

            var empty = document.createElement("div");
            empty.className = "entity-list-empty";
            empty.textContent = "Меток нет";
            el.markerList.appendChild(empty);
            return;

        }

        filtered.forEach(function (marker) {

            var category = window.PISPOP_MARKERS.categories.find(function (c) {
                return c.id === marker.category;
            });

            var item = document.createElement("div");
            item.className = "entity-list-item";

            item.innerHTML =
                "<span>" + (category ? category.icon : "📍") + "</span><span></span>";

            item.querySelector("span:last-child").textContent =
                marker.title || "Без названия";

            item.addEventListener("click", function () {
                window.PISPOP_MARKERS.panTo(marker);
                openViewCard("marker", marker);
            });

            el.markerList.appendChild(item);

        });

    }


    /* ========================================================
       РЕЖИМ ДОБАВЛЕНИЯ МЕТКИ
       ======================================================== */

    function setupMarkerTool() {

        el.toolAddMarker.addEventListener("click", function () {

            if (window.PISPOP_MARKERS.isAddingMode()) {
                window.PISPOP_MARKERS.cancelAdding();
                return;
            }

            cancelTerritoryDrawing();
            window.PISPOP_ROUTES.stopPicking();

            window.PISPOP_MARKERS.startAdding();

        });

        el.addingCancel.addEventListener("click", function () {
            window.PISPOP_MARKERS.cancelAdding();
            cancelTerritoryDrawing();
            cancelHouseBoundaryDrawing();
            window.PISPOP_ROUTES.stopPicking();
            if (window.PISPOP_WATER) {
                window.PISPOP_WATER.stopDrawing();
            }
        });

        document.addEventListener("pispop:marker-adding-mode", function (event) {

            var active = event.detail;

            el.toolAddMarker.classList.toggle("active", active);
            el.addingHint.classList.toggle("hidden", !active);
            el.addingHint.childNodes[0].textContent =
                "Кликните на карту, чтобы поставить метку ";

        });

        document.addEventListener("pispop:marker-create-request", function (event) {

            var presetCategory =
                activeCategory && activeCategory.kind === "marker"
                    ? activeCategory.id
                    : "default";

            openMarkerCard(
                {
                    x: event.detail.x,
                    z: event.detail.z,
                    title: "",
                    description: "",
                    address: "",
                    category: presetCategory,
                    color: categoryColor(presetCategory)
                },
                true
            );

        });

        document.addEventListener("pispop:marker-open-request", function (event) {
            openViewCard("marker", event.detail);
        });

        document.addEventListener("pispop:markers-loaded", function () {
            renderCategoryResults();
        });

        document.addEventListener("pispop:profile-open", showProfilePanel);
        if (el.profileSidebarBack) el.profileSidebarBack.addEventListener("click", function(){ showPanel("search"); });
        if (el.profileSidebarAvatar) {}

    }


    // Фотографии храним так же, как аватар профиля: прямо в markers.json
    // в виде data:image/... URL. Это надёжнее для локального проекта:
    // не нужен отдельный multipart-запрос и отдельная раздача /data/photos/.
    function photoToDataUrl(file){
        return new Promise(function(resolve,reject){
            if(!file || !/^image\/(png|jpeg|jpg|webp)$/.test(file.type)){
                reject(new Error("Поддерживаются PNG, JPG и WEBP")); return;
            }
            if(file.size > 12*1024*1024){
                reject(new Error("Фото слишком большое (максимум 12 МБ до сжатия)")); return;
            }
            var rd=new FileReader();
            rd.onerror=function(){reject(new Error("Не удалось прочитать фото"));};
            rd.onload=function(){
                var img=new Image();
                img.onerror=function(){reject(new Error("Не удалось открыть изображение"));};
                img.onload=function(){
                    var max=1600, w=img.naturalWidth||img.width, h=img.naturalHeight||img.height;
                    if(w>max || h>max){
                        var k=Math.min(max/w,max/h); w=Math.max(1,Math.round(w*k)); h=Math.max(1,Math.round(h*k));
                    }
                    var canvas=document.createElement("canvas"); canvas.width=w; canvas.height=h;
                    var ctx=canvas.getContext("2d"); ctx.drawImage(img,0,0,w,h);
                    var data=canvas.toDataURL("image/jpeg",0.82);
                    resolve(data);
                };
                img.src=rd.result;
            };
            rd.readAsDataURL(file);
        });
    }


    /* ========================================================
       РИСОВАНИЕ ТЕРРИТОРИИ (ПОЛИГОН)
       ======================================================== */

    function ensureTerritoryDrawLayer() {

        if (territoryDrawLayer) {
            return;
        }

        territoryDrawSource = new ol.source.Vector();

        territoryDrawLayer = new ol.layer.Vector({

            source: territoryDrawSource,
            zIndex: 300000,

            style: new ol.style.Style({

                fill: new ol.style.Fill({
                    color: "rgba(255, 204, 0, 0.15)"
                }),

                stroke: new ol.style.Stroke({
                    color: "#ffcc00",
                    width: 2,
                    lineDash: [6, 6]
                }),

                image: new ol.style.Circle({
                    radius: 5,
                    fill: new ol.style.Fill({ color: "#ffcc00" })
                })

            })

        });

        map.addLayer(territoryDrawLayer);

    }

    function startTerritoryDrawing() {

        if (drawingTerritory) {
            return;
        }

        if (window.PISPOP_MARKERS.isAddingMode()) {
            window.PISPOP_MARKERS.cancelAdding();
        }

        window.PISPOP_ROUTES.stopPicking();

        ensureTerritoryDrawLayer();

        territoryDrawSource.clear();

        territoryDraw = new ol.interaction.Draw({
            source: territoryDrawSource,
            type: "Polygon"
        });

        territoryDraw.on("drawend", function (event) {

            var viewCoordinates =
                event.feature.getGeometry().getCoordinates()[0];

            var coordinates = viewCoordinates.map(toDataCoordinate);

            stopTerritoryDrawing(false);

            openTerritoryCard(
                {
                    name: "",
                    description: "",
                    coordinates: coordinates,
                    fillColor: "rgba(60,130,246,0.16)",
                    borderColor: "#3c82f6"
                },
                true
            );

        });

        map.addInteraction(territoryDraw);

        drawingTerritory = true;

        el.toolAddTerritory.classList.add("active");
        el.addingHint.classList.remove("hidden");
        el.addingHint.childNodes[0].textContent =
            "Нарисуйте границу населённого пункта (двойной клик — закончить) ";

        map.getViewport().style.cursor = "crosshair";

    }

    function stopTerritoryDrawing(clearSource) {

        if (territoryDraw) {
            map.removeInteraction(territoryDraw);
            territoryDraw = null;
        }

        if (clearSource && territoryDrawSource) {
            territoryDrawSource.clear();
        }

        drawingTerritory = false;

        el.toolAddTerritory.classList.remove("active");
        el.addingHint.classList.add("hidden");

        if (map) {
            map.getViewport().style.cursor = "";
        }

    }

    function cancelTerritoryDrawing() {
        stopTerritoryDrawing(true);
    }


    /* ========================================================
       РИСОВАНИЕ ГРАНИЦЫ ДОМА (ПОЛИГОН)
       ======================================================== */

    function ensureHouseBoundaryDrawLayer() {

        if (houseBoundaryDrawLayer) {
            return;
        }

        houseBoundaryDrawSource = new ol.source.Vector();

        houseBoundaryDrawLayer = new ol.layer.Vector({

            source: houseBoundaryDrawSource,
            zIndex: 300000,

            style: new ol.style.Style({

                fill: new ol.style.Fill({
                    color: "rgba(60,110,246,0.15)"
                }),

                stroke: new ol.style.Stroke({
                    color: "#3c6ef6",
                    width: 2,
                    lineDash: [6, 6]
                }),

                image: new ol.style.Circle({
                    radius: 5,
                    fill: new ol.style.Fill({ color: "#3c6ef6" })
                })

            })

        });

        map.addLayer(houseBoundaryDrawLayer);

    }

    function startHouseBoundaryDrawing(house) {

        if (drawingHouseBoundary) {
            return;
        }

        if (window.PISPOP_MARKERS.isAddingMode()) {
            window.PISPOP_MARKERS.cancelAdding();
        }

        cancelTerritoryDrawing();
        window.PISPOP_ROUTES.stopPicking();

        ensureHouseBoundaryDrawLayer();
        houseBoundaryDrawSource.clear();

        houseBoundaryTarget = house;

        houseBoundaryDraw = new ol.interaction.Draw({
            source: houseBoundaryDrawSource,
            type: "Polygon"
        });

        houseBoundaryDraw.on("drawend", function (event) {

            var viewCoordinates =
                event.feature.getGeometry().getCoordinates()[0];

            var coordinates = viewCoordinates.map(toDataCoordinate);

            stopHouseBoundaryDrawing(true);

            if (window.PISPOP_ADDRESS) {
                window.PISPOP_ADDRESS.setHouseTerritory(house, coordinates);
            }

        });

        map.addInteraction(houseBoundaryDraw);

        drawingHouseBoundary = true;

        el.addingHint.classList.remove("hidden");
        el.addingHint.childNodes[0].textContent =
            "Нарисуйте границу дома (двойной клик — закончить) ";

        map.getViewport().style.cursor = "crosshair";

    }

    function stopHouseBoundaryDrawing(clearSource) {

        if (houseBoundaryDraw) {
            map.removeInteraction(houseBoundaryDraw);
            houseBoundaryDraw = null;
        }

        if (clearSource && houseBoundaryDrawSource) {
            houseBoundaryDrawSource.clear();
        }

        drawingHouseBoundary = false;
        houseBoundaryTarget = null;

        el.addingHint.classList.add("hidden");

        if (map) {
            map.getViewport().style.cursor = "";
        }

    }

    function cancelHouseBoundaryDrawing() {
        stopHouseBoundaryDrawing(true);
    }

    function setupTerritoryTool() {

        el.toolAddTerritory.addEventListener("click", function () {

            if (drawingTerritory) {
                cancelTerritoryDrawing();
                return;
            }

            startTerritoryDrawing();

        });

        document.addEventListener("pispop:territory-opened", function (event) {
            openViewCard("territory", event.detail);
        });

    }

    function setupWaterTool() {

        if (!el.toolAddWater) {
            return;
        }

        el.toolAddWater.addEventListener("click", function () {

            if (!window.PISPOP_WATER) {
                return;
            }

            if (window.PISPOP_WATER.isDrawing()) {
                window.PISPOP_WATER.stopDrawing();
                return;
            }

            if (window.PISPOP_MARKERS.isAddingMode()) {
                window.PISPOP_MARKERS.cancelAdding();
            }

            cancelTerritoryDrawing();
            cancelHouseBoundaryDrawing();
            window.PISPOP_ROUTES.stopPicking();

            window.PISPOP_WATER.startDrawing();

        });

        document.addEventListener("pispop:water-drawing", function (event) {

            el.toolAddWater.classList.toggle("active", event.detail);

            el.addingHint.classList.toggle("hidden", !event.detail);

            if (event.detail) {
                el.addingHint.childNodes[0].textContent =
                    "Нарисуйте границу водоёма (двойной клик — закончить) ";
            }

        });

        /* -----------------------------------------------------
           Автоопределение водоёмов по цельной карте
           ----------------------------------------------------- */
        if (el.toolAutoWater) {

            function setAutoWaterStatus(text, visible) {
                if (!el.toolAutoWaterStatus) return;
                el.toolAutoWaterStatus.textContent = text || "";
                el.toolAutoWaterStatus.classList.toggle("hidden", !visible);
            }

            function stopOtherDrawingModes() {
                if (window.PISPOP_MARKERS && window.PISPOP_MARKERS.isAddingMode && window.PISPOP_MARKERS.isAddingMode()) {
                    window.PISPOP_MARKERS.cancelAdding();
                }
                cancelTerritoryDrawing();
                cancelHouseBoundaryDrawing();
                if (window.PISPOP_ROUTES) window.PISPOP_ROUTES.stopPicking();
                if (window.PISPOP_WATER && window.PISPOP_WATER.isDrawing()) {
                    window.PISPOP_WATER.stopDrawing();
                }
            }

            el.toolAutoWater.addEventListener("click", async function () {

                if (!window.PISPOP_AUTH || !window.PISPOP_AUTH.isAdmin()) {
                    return;
                }

                stopOtherDrawingModes();
                el.toolAutoWater.disabled = true;
                el.toolAutoWater.classList.add("active");
                setAutoWaterStatus("Карта загружается…", true);

                try {
                    if (!window.PISPOP_WATER || !window.PISPOP_WATER.autoDetectFromProjectMap) {
                        throw new Error("Автоопределитель водоёмов не загружен");
                    }

                    var result;
                    try {
                        result = await window.PISPOP_WATER.autoDetectFromProjectMap(function (percent, text) {
                            setAutoWaterStatus(text + " " + percent + "%", true);
                        });
                    } catch (projectError) {
                        // Если встроенной карты нет, предлагаем выбрать
                        // цельный файл карты вручную.
                        if (el.toolAutoWaterFile) {
                            setAutoWaterStatus("Выбери цельную карту для анализа…", true);
                            el.toolAutoWaterFile.value = "";
                            el.toolAutoWaterFile.click();
                            return;
                        }
                        throw projectError;
                    }

                    setAutoWaterStatus("Готово: найдено " + result.count + " водоёмов.", true);
                    if (typeof Toastify === "function") {
                        Toastify({
                            text: "🌊 Автоопределение: найдено " + result.count + " водоёмов",
                            duration: 3500,
                            gravity: "bottom",
                            position: "center",
                            close: true
                        }).showToast();
                    }

                } catch (error) {
                    console.error("PISPOP-GIS: автоопределение водоёмов:", error);
                    setAutoWaterStatus("Ошибка: " + (error.message || error), true);
                } finally {
                    el.toolAutoWater.disabled = false;
                    el.toolAutoWater.classList.remove("active");
                }
            });

            if (el.toolAutoWaterFile) {
                el.toolAutoWaterFile.addEventListener("change", async function () {
                    var file = el.toolAutoWaterFile.files && el.toolAutoWaterFile.files[0];
                    if (!file) {
                        el.toolAutoWater.disabled = false;
                        el.toolAutoWater.classList.remove("active");
                        return;
                    }

                    el.toolAutoWater.disabled = true;
                    el.toolAutoWater.classList.add("active");

                    try {
                        var result = await window.PISPOP_WATER.autoDetectFromFile(file, function (percent, text) {
                            setAutoWaterStatus(text + " " + percent + "%", true);
                        });
                        setAutoWaterStatus("Готово: найдено " + result.count + " водоёмов.", true);
                    } catch (error) {
                        console.error("PISPOP-GIS: автоопределение водоёмов из файла:", error);
                        setAutoWaterStatus("Ошибка: " + (error.message || error), true);
                    } finally {
                        el.toolAutoWater.disabled = false;
                        el.toolAutoWater.classList.remove("active");
                    }
                });
            }
        }

    }

    function setupHouseTool() {

        var toolAddHouse = document.getElementById("tool-add-house");
            if (!toolAddHouse) return;

            function notify(text, type) {
                if (typeof Toastify === "function") {
                    Toastify({
                        text: text,
                        duration: 2500,
                        gravity: "bottom",
                        position: "center",
                        close: true,
                        style: {
                            background: type === "error" ? "#c62828" : "#2e7d32"
                        }
                    }).showToast();
                } else {
                    console.log("[PISPOP-GIS]", text);
                }
            }

            toolAddHouse.addEventListener("click", function () {

                if (window.PISPOP_ADDRESS && window.PISPOP_ADDRESS.isAddingMode()) {
                    window.PISPOP_ADDRESS.stopAdding();
                    toolAddHouse.classList.remove("active");
                    return;
                }

                if (!window.PISPOP_STREETS) {
                    notify("Система улиц недоступна", "error");
                    return;
                }

                var streets = window.PISPOP_STREETS.getStreets();

                if (!streets || streets.length === 0) {
                    notify("Сначала создайте улицу", "error");
                    return;
                }

                var selectedStreet = window.PISPOP_STREETS.getSelectedStreet();

                if (!selectedStreet) {
                    notify("Сначала выберите улицу на карте", "error");
                    return;
                }

                window.PISPOP_ADDRESS.addHouse(selectedStreet.id);
                toolAddHouse.classList.add("active");

            });

            document.addEventListener("pispop:add-house-mode", function (event) {
                var active = event.detail.active;
                if (toolAddHouse) {
                    toolAddHouse.classList.toggle("active", active);
                }
            });

            document.addEventListener("pispop:house-selected", function (event) {
                openViewCard("house", event.detail);
            });

            document.addEventListener("pispop:street-selected", function (event) {
                openViewCard("street", event.detail);
            });

        }


    /* ========================================================
       РЕДАКТОР ДОРОГ

       Кнопкой #tool-roads целиком управляет roads-editor.js
       (installRoadEditorButton) - он сам вешает обработчик клика,
       переключает текст/класс "active" и т.д. Раньше здесь ещё
       ставился ВТОРОЙ, отдельный обработчик клика на тот же
       элемент - из-за того что roads-editor.js при инициализации
       подменяет DOM-узел кнопки (cloneNode, чтобы точно снять
       старые обработчики), этот второй обработчик оставался висеть
       на уже отсоединённом от страницы узле - источник путаницы
       при повторных открытиях. Функция оставлена пустой, чтобы не
       трогать порядок вызовов в tryInit().
       ======================================================== */

    function setupRoadsTool() {
    }


    /* ========================================================
       МАРШРУТЫ
       ======================================================== */

    function formatCoord(point) {

        if (!point) {
            return "";
        }

        return "X: " + point[0] + "   Z: " + point[1];

    }

    function placeLabelForCoordinate(point) {
        var x = Number(point[0]), z = Number(point[1]);
        var markers = (window.PISPOP_MARKERS && window.PISPOP_MARKERS.getMarkers()) || [];
        var exact = markers.find(function(m){ return Math.round(Number(m.x))===Math.round(x) && Math.round(Number(m.z))===Math.round(z); });
        if (exact && exact.title) return exact.title;
        var settlements = (window.PISPOP_SETTLEMENTS && window.PISPOP_SETTLEMENTS.getSettlements()) || [];
        for (var i=0;i<settlements.length;i++){ var t=settlements[i]; if(Array.isArray(t.coordinates) && window.pointInPolygon && window.pointInPolygon(x,z,t.coordinates)) return t.name || "Населённый пункт"; }
        return formatCoord(point);
    }

    var routeSuggestions = [];
    var routeSuggestionBox = null;
    var activeRouteInput = null;

    function getFavoriteMarkerIds() {
        var ids = new Set();
        try {
            var raw = localStorage.getItem("pispop-favorites");
            var parsed = raw ? JSON.parse(raw) : [];
            if (Array.isArray(parsed)) parsed.forEach(function (id) { ids.add(String(id)); });
        } catch (e) {}
        return ids;
    }

    function isFavoriteMarker(marker, favoriteIds) {
        return !!(marker && (marker.favorite === true || marker.isFavorite === true || favoriteIds.has(String(marker.id))));
    }

    function getRouteSearchMarkers() {
        var markers = ((window.PISPOP_MARKERS && window.PISPOP_MARKERS.getMarkers()) || []).filter(function (m) {
            return m && m.title && typeof m.x === "number" && typeof m.z === "number";
        });
        var favoriteIds = getFavoriteMarkerIds();
        return markers.sort(function (a, b) {
            var af = isFavoriteMarker(a, favoriteIds) ? 1 : 0;
            var bf = isFavoriteMarker(b, favoriteIds) ? 1 : 0;
            if (af !== bf) return bf - af;
            return String(a.title).localeCompare(String(b.title), "ru");
        });
    }

    function getPersonalRouteMarkers() {
        /*
         * Маршрутизация использует обычный глобальный поиск.
         * Личные/избранные метки только получают приоритет в подсказках.
         */
        return getRouteSearchMarkers();
    }

    function categoryIcon(category) {
        var cats = (window.PISPOP_MARKERS && window.PISPOP_MARKERS.categories) || [];
        var found = cats.find(function (c) { return c.id === category; });
        return found ? found.icon : "📍";
    }

    function refreshRouteSearchList() {
        routeSuggestions = getPersonalRouteMarkers();
        var dl = document.getElementById("route-search-list");
        if (dl) dl.innerHTML = "";
    }

    function hideRouteSuggestions() {
        if (routeSuggestionBox) {
            routeSuggestionBox.remove();
            routeSuggestionBox = null;
        }
        activeRouteInput = null;
    }

    function kindForRouteInput(input) {
        if (input === el.routeFrom) return "from";
        if (input === el.routeTo) return "to";
        return input && input.dataset ? input.dataset.routeKind : "from";
    }

    function showRouteSuggestions(input) {
        hideRouteSuggestions();
        var query = (input.value || "").trim().toLowerCase();
        var matches = getPersonalRouteMarkers().filter(function (m) {
            return !query ||
                (m.title || "").toLowerCase().includes(query);
        }).slice(0, 8);

        if (!matches.length) return;

        routeSuggestionBox = document.createElement("div");
        routeSuggestionBox.className = "route-search-suggestions";

        matches.forEach(function (marker) {
            var row = document.createElement("button");
            row.type = "button";
            row.className = "route-search-suggestion";
            row.innerHTML =
                '<span class="route-search-suggestion-icon">' +
                (categoryIcon(marker.category) || "📍") +
                '</span>' +
                '<span class="route-search-suggestion-text">' +
                '<span class="route-search-suggestion-name"></span>' +
                '<span class="route-search-suggestion-coords">X: ' +
                Number(marker.x) + ' · Z: ' + Number(marker.z) + '</span>' +
                '</span>';
            var favoriteIds = getFavoriteMarkerIds();
            row.querySelector(".route-search-suggestion-name").textContent =
                (isFavoriteMarker(marker, favoriteIds) ? "★ " : "") + marker.title;
            row.addEventListener("mousedown", function (e) {
                e.preventDefault();
                input.value = marker.title;
                input.dataset.routeX = marker.x;
                input.dataset.routeZ = marker.z;
                hideRouteSuggestions();

                // Выбор подсказки сразу становится точкой маршрута.
                // Раньше координаты только попадали в input, а
                // маршрутизатор ждал Enter/change, из-за чего казалось,
                // что маршрут по метке не строится.
                if (kindForRouteInput(input) === "from") {
                    window.PISPOP_ROUTES.setFrom([Number(marker.x), Number(marker.z)]);
                } else {
                    window.PISPOP_ROUTES.setTo([Number(marker.x), Number(marker.z)]);
                }
            });
            routeSuggestionBox.appendChild(row);
        });

        input.parentElement.appendChild(routeSuggestionBox);
        activeRouteInput = input;
    }

    function resolveRouteInput(value) {
        var input = (activeRouteInput && activeRouteInput.value === value)
            ? activeRouteInput
            : null;

        if (input && input.dataset.routeX != null) {
            return [Number(input.dataset.routeX), Number(input.dataset.routeZ)];
        }

        var q = (value || "").trim().toLowerCase();
        var found = getPersonalRouteMarkers().find(function (it) {
            return it.title.toLowerCase() === q;
        });
        if (found) return [Number(found.x), Number(found.z)];

        return parseCoordinateQuery(value);
    }

    function setupRoutes() {

        [el.routeFrom, el.routeTo].forEach(function (input) {
            if (!input) return;
            input.setAttribute("autocomplete", "off");
            input.setAttribute("name", "pispop-route-" + input.id);
            input.dataset.routeKind = (input === el.routeFrom ? "from" : "to");
            input.addEventListener("focus", function () {
                showRouteSuggestions(input);
            });
            input.addEventListener("input", function () {
                input.dataset.routeX = "";
                input.dataset.routeZ = "";
                showRouteSuggestions(input);
            });
            input.addEventListener("keydown", function (event) {
                if (event.key === "Escape") hideRouteSuggestions();
            });
        });

        document.addEventListener("click", function (event) {
            if (!event.target.closest(".route-point-row")) {
                hideRouteSuggestions();
            }
        });

        el.routePick.addEventListener("click", function () {

            if (window.PISPOP_ROUTES.isPicking()) {
                window.PISPOP_ROUTES.stopPicking();
                el.routePick.classList.remove("active");
                el.addingHint.classList.add("hidden");
                return;
            }

            window.PISPOP_MARKERS.cancelAdding();
            cancelTerritoryDrawing();
            cancelHouseBoundaryDrawing();
            if (window.PISPOP_WATER) {
                window.PISPOP_WATER.stopDrawing();
            }

            window.PISPOP_ROUTES.clear();
            el.routeFrom.value = "";
            el.routeTo.value = "";
            el.routeSummary.classList.add("hidden");

            window.PISPOP_ROUTES.startPicking();

        });

        el.routeClear.addEventListener("click", function () {

            window.PISPOP_ROUTES.clear();
            el.routeFrom.value = "";
            el.routeTo.value = "";
            el.routeSummary.classList.add("hidden");

        });

        el.routeSwap.addEventListener("click", function () {
            window.PISPOP_ROUTES.swap();
        });

        refreshRouteSearchList();
        function bindRouteInput(input, kind) {
            if(!input)return;
            input.addEventListener("focus", refreshRouteSearchList);
            input.addEventListener("change", function(){
                var c=resolveRouteInput(input.value);
                if(c){ if(kind==="from") window.PISPOP_ROUTES.setFrom(c); else window.PISPOP_ROUTES.setTo(c); input.value=placeLabelForCoordinate(c); }
            });
            input.addEventListener("keydown", function(e){
                if(e.key==="Enter"){ e.preventDefault(); var c=resolveRouteInput(input.value); if(c){if(kind==="from")window.PISPOP_ROUTES.setFrom(c);else window.PISPOP_ROUTES.setTo(c); input.value=placeLabelForCoordinate(c);} }
            });
        }
        bindRouteInput(el.routeFrom,"from");
        bindRouteInput(el.routeTo,"to");

        document.addEventListener("pispop:markers-loaded", refreshRouteSearchList);
        document.addEventListener("pispop:settlements-loaded", refreshRouteSearchList);

        document.addEventListener("pispop:route-picking", function (event) {

            var active = event.detail;

            el.routePick.classList.toggle("active", active);
            el.addingHint.classList.toggle("hidden", !active);

            if (active) {
                el.addingHint.childNodes[0].textContent =
                    "Кликните точку А, затем точку Б ";
            }

        });

        function fillSteps(listEl, steps) {

            listEl.innerHTML = "";

            (steps || []).forEach(function (step) {
                var li = document.createElement("li");
                li.textContent = step;
                listEl.appendChild(li);
            });

        }

        function showGuide(which) {

            var showWalk = which === "walk";
            var showIce = which === "ice";

            el.routeGuideWalk.classList.toggle("hidden", !showWalk);
            el.routeGuideIce.classList.toggle("hidden", !showIce);

            el.routeGuideWalkBtn.classList.toggle("active", showWalk);
            el.routeGuideIceBtn.classList.toggle("active", showIce);

        }

        el.routeGuideWalkBtn.addEventListener("click", function () {
            var isOpen = !el.routeGuideWalk.classList.contains("hidden");
            showGuide(isOpen ? null : "walk");
        });

        el.routeGuideIceBtn.addEventListener("click", function () {
            var isOpen = !el.routeGuideIce.classList.contains("hidden");
            showGuide(isOpen ? null : "ice");
        });

        document.addEventListener("pispop:route-updated", function (event) {

            var detail = event.detail;

            el.routeFrom.value = detail.from ? placeLabelForCoordinate(detail.from) : "";
            el.routeTo.value = detail.to ? placeLabelForCoordinate(detail.to) : "";

            if (detail.from && detail.to) {

                // Компактная сводка - только цифры в блоках,
                // подробная пошаговая инструкция - отдельно ниже.
                el.routeSummary.classList.remove("hidden");
                el.routeSummary.innerHTML = "";

                function fmtTime(seconds) {
                    if (seconds == null || !isFinite(seconds)) return "—";
                    var min = Math.max(1, Math.round(seconds / 60));
                    if (min < 60) return min + " мин";
                    var h = Math.floor(min / 60), m = min % 60;
                    return h + " ч" + (m ? " " + m + " мин" : "");
                }
                var totalSeconds = detail.iceRoute ? detail.iceRoute.timeSeconds : detail.walkTimeSeconds;
                var top = document.createElement("div");
                top.className = "route-total-time";
                top.textContent = "~" + fmtTime(totalSeconds);
                el.routeSummary.appendChild(top);

                if (detail.iceRoute) {
                    var modes = document.createElement("div");
                    modes.className = "route-mode-line";
                    modes.innerHTML = "<span>🚶</span><i></i><span>🚙</span><i></i><span>🚶</span>";
                    el.routeSummary.appendChild(modes);
                    var seg = document.createElement("div");
                    seg.className = "route-segments";
                    seg.innerHTML = "<div><b>🚶</b><span>пешком " + fmtTime(detail.iceRoute.walkToRoadSeconds) + "</span></div><div><b>🚙</b><span>по ледяной дороге " + fmtTime(detail.iceRoute.iceSeconds) + "</span></div><div><b>🚶</b><span>пешком " + fmtTime(detail.iceRoute.walkFromRoadSeconds) + "</span></div>";
                    el.routeSummary.appendChild(seg);
                } else {
                    var walkRow = document.createElement("div");
                    walkRow.className = "route-summary-row";
                    walkRow.textContent = "🚶 Пешком " + fmtTime(detail.walkTimeSeconds);
                    el.routeSummary.appendChild(walkRow);
                }

                if (detail.waterCrossing) {

                    var waterRow = document.createElement("div");
                    waterRow.className = "route-summary-details route-summary-warning";
                    waterRow.textContent =
                        "🌊 На этом пути придётся переплыть ~" +
                        detail.waterCrossing.distance + " блоков";
                    el.routeSummary.appendChild(waterRow);

                }

                if (detail.iceRoute) {

                    var iceRow = document.createElement("div");
                    iceRow.className = "route-summary-row";
                    iceRow.textContent =
                        "🧊 Через ледяную дорогу: " + Math.round(detail.iceRoute.distance) + " блоков";
                    el.routeSummary.appendChild(iceRow);

                }

                // Подробные инструкции - отдельным блоком под сводкой,
                // открываются по кнопке, как маршрут в 2ГИС.
                el.routeGuideTabs.classList.remove("hidden");

                fillSteps(el.routeGuideWalk, detail.walkSteps);

                if (detail.iceRoute) {
                    el.routeGuideIceBtn.classList.remove("hidden");
                    fillSteps(el.routeGuideIce, detail.iceRoute.steps);
                } else {
                    el.routeGuideIceBtn.classList.add("hidden");
                    el.routeGuideIce.innerHTML = "";
                }

                showGuide(null);

            } else {

                el.routeSummary.classList.add("hidden");
                el.routeGuideTabs.classList.add("hidden");
                el.routeGuideWalk.classList.add("hidden");
                el.routeGuideIce.classList.add("hidden");
                el.routeGuideWalk.innerHTML = "";
                el.routeGuideIce.innerHTML = "";

            }

        });

    }


    /* ========================================================
       ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ escapeHtml
       ======================================================== */

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }


    /* ========================================================
       КАРТОЧКА РЕДАКТИРОВАНИЯ (внутри панели)
       ======================================================== */

    function renderCategoryChips(selectedCategory) {

        el.cardCategories.innerHTML = "";

        window.PISPOP_MARKERS.categories.forEach(function (category) {

            var chip = document.createElement("div");
            chip.className = "category-chip";

            if (category.id === selectedCategory) {
                chip.classList.add("selected");
            }

            chip.innerHTML =
                '<span class="category-dot" style="background:' +
                category.color +
                '"></span><span></span>';

            chip.querySelector("span:last-child").textContent =
                category.icon + " " + category.label;

            chip.addEventListener("click", function () {

                cardContext.data.category = category.id;
                cardContext.data.color = category.color;

                renderCategoryChips(category.id);
                el.cardColor.style.background = category.color;

            });

            el.cardCategories.appendChild(chip);

        });

    }

    function renderTerritoryCategoryChips(selectedCategory) {

        el.cardCategories.innerHTML = "";

        (window.PISPOP_SETTLEMENTS ? window.PISPOP_SETTLEMENTS.categories : [])
            .forEach(function (category) {

                var chip = document.createElement("div");
                chip.className = "category-chip";

                if (category.id === selectedCategory) {
                    chip.classList.add("selected");
                }

                chip.innerHTML =
                    '<span class="category-dot" style="background:' +
                    category.color +
                    '"></span><span></span>';

                chip.querySelector("span:last-child").textContent =
                    category.icon + " " + category.label;

                chip.addEventListener("click", function () {

                    cardContext.data.category = category.id;
                    cardContext.data.borderColor = category.color;

                    renderTerritoryCategoryChips(category.id);
                    el.cardColor.style.background = category.color;

                });

                el.cardCategories.appendChild(chip);

            });

    }


    function openMarkerPhotoModal(src) {
        if (!el.markerPhotoModal || !el.markerPhotoModalImage || !src) return;
        el.markerPhotoModalImage.src = src;
        el.markerPhotoModal.classList.remove("hidden");
        document.body.classList.add("marker-photo-modal-open");
    }

    function closeMarkerPhotoModal() {
        if (!el.markerPhotoModal) return;
        el.markerPhotoModal.classList.add("hidden");
        if (el.markerPhotoModalImage) el.markerPhotoModalImage.removeAttribute("src");
        document.body.classList.remove("marker-photo-modal-open");
    }

    function renderMarkerPhotos(photos, previewEl, editable){
        if(!previewEl)return;
        previewEl.innerHTML="";
        (photos||[]).forEach(function(src,i){
            if(!src)return;
            var wrap=document.createElement("div");
            wrap.className="marker-photo-edit-item";
            var img=document.createElement("img");
            img.src=src;
            img.alt="Фото "+(i+1);
            wrap.appendChild(img);

            if(editable && window.PISPOP_AUTH && window.PISPOP_AUTH.isAdmin()){
                var del=document.createElement("button");
                del.type="button";
                del.className="marker-photo-delete-btn";
                del.textContent="✕";
                del.title="Удалить фотографию";
                del.addEventListener("click", async function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    if(!cardContext || cardContext.kind!=="marker") return;
                    if(!confirm("Удалить эту фотографию?")) return;
                    var current=Array.isArray(cardContext.data.photos) ? cardContext.data.photos.slice() : [];
                    cardContext.data.photos=current.filter(function(photo){ return photo!==src; });
                    cardContext.deletedPhotos = Array.isArray(cardContext.deletedPhotos) ? cardContext.deletedPhotos : [];
                    if(cardContext.deletedPhotos.indexOf(src)===-1) cardContext.deletedPhotos.push(src);
                    renderMarkerPhotos(cardContext.data.photos, previewEl, true);
                });
                wrap.appendChild(del);
            }
            previewEl.appendChild(wrap);
        });
    }

    function openMarkerCard(marker, isNew) {

        el.panelSearch.classList.add("hidden");
        el.viewCardContainer.classList.add("hidden");
        el.cardContainer.classList.remove("hidden");

        cardContext = { kind: "marker", data: Object.assign({}, marker), isNew: isNew, pendingPhotoFiles: [], deletedPhotos: [] };

        var isShop = marker.category === "shop";

        el.cardTitle.textContent = isShop ? (isNew ? "🛒 Новый магазин" : "🛒 Редактирование магазина") 
                                          : (isNew ? "Новая метка" : "Редактирование метки");
        el.cardColor.style.background = marker.color || categoryColor("default");
        document.getElementById("panel-card-title-input").value = marker.title || "";
        el.cardAddress.value = marker.address || "";
        el.cardDescription.value = marker.description || "";
        renderMarkerPhotos(marker.photos || [], el.markerPhotoPreview, true);

        // Специальные поля для магазина
        var oldShopFields = document.getElementById("panel-card-shop-fields");
        if (oldShopFields) oldShopFields.remove();

        if (isShop) {
            var shopFields = document.createElement("div");
            shopFields.id = "panel-card-shop-fields";
            shopFields.className = "panel-card-shop-fields";
            
            // Формируем список сделок для отображения в текстовом поле
            var dealsText = '';
            if (marker.deals && marker.deals.length > 0) {
                dealsText = marker.deals.map(function(d) {
                    return d.buy + ' → ' + d.sell;
                }).join('\n');
            }
            
            shopFields.innerHTML = `
                <div class="panel-card-shop-row">
                    <label>🔄 Сделки (каждая с новой строки)</label>
                    <textarea id="panel-card-deals" class="panel-card-address" rows="6" placeholder="Формат: что даю → что получаю&#10;Например:&#10;16 стекла → 1 изумруд&#10;32 булыжника → 1 изумруд&#10;1 алмаз → 3 изумруда">${escapeHtml(dealsText)}</textarea>
                </div>
                <div class="panel-card-shop-row" style="font-size:12px;color:var(--pispop-text-soft);padding:4px 0;">
                    💡 Пишите каждую сделку с новой строки. Используйте → или - или : для разделения
                </div>
            `;
            el.cardDescription.parentNode.insertBefore(shopFields, el.cardDescription.nextSibling);
        }

        el.cardCategories.style.display = "flex";
        renderCategoryChips(marker.category || "default");

        el.cardDelete.style.display = isNew ? "none" : "block";
        el.cardSave.textContent = isShop ? "💾 Сохранить магазин" : (isNew ? "Добавить метку" : "Сохранить");

        document.getElementById("panel-card-title-input").focus();

        clearTempMarker();

    }

    function openTerritoryCard(territory, isNew) {

        el.panelSearch.classList.add("hidden");
        el.viewCardContainer.classList.add("hidden");
        el.cardContainer.classList.remove("hidden");

        cardContext = {
            kind: "territory",
            data: Object.assign({}, territory),
            isNew: isNew
        };

        el.cardTitle.textContent = isNew ? "Новый населённый пункт" : "Редактирование населённого пункта";
        el.cardColor.style.background = territory.borderColor || "#3c82f6";
        document.getElementById("panel-card-title-input").value = territory.name || "";
        el.cardAddress.value = "";
        el.cardDescription.value = territory.description || "";

        el.cardCategories.style.display = "flex";
        renderTerritoryCategoryChips(territory.category || "residential");

        el.cardDelete.style.display = isNew ? "none" : "block";
        el.cardSave.textContent = isNew ? "Создать населённый пункт" : "Сохранить";

        document.getElementById("panel-card-title-input").focus();

    }

    function closeCard() {

        el.cardContainer.classList.add("hidden");
        el.panelSearch.classList.remove("hidden");

        if (
            cardContext &&
            cardContext.kind === "territory" &&
            cardContext.isNew
        ) {
            cancelTerritoryDrawing();
        }

        cardContext = null;

    }

    async function saveCard() {

        if (!cardContext) {
            return;
        }

        var titleInput = document.getElementById("panel-card-title-input");

        if (cardContext.kind === "marker") {

            var payload = {
                x: cardContext.data.x,
                z: cardContext.data.z,
                title: titleInput.value.trim() || "Без названия",
                address: el.cardAddress.value.trim(),
                description: el.cardDescription.value.trim(),
                category: cardContext.data.category || "default",
                color: cardContext.data.color || categoryColor("default"),
                photos: Array.isArray(cardContext.data.photos) ? cardContext.data.photos : [],
            };

            // Если это магазин — парсим сделки
            if (payload.category === "shop") {
                var dealsInput = document.getElementById("panel-card-deals");
                
                if (dealsInput) {
                    var lines = dealsInput.value.split('\n').filter(function(s) { return s.trim().length > 0; });
                    payload.deals = lines.map(function(line) {
                        // Пробуем разные разделители: →, -, :, ;
                        var parts = line.split(/→|-|:|;/).map(function(s) { return s.trim(); });
                        if (parts.length >= 2) {
                            return {
                                buy: parts[0],
                                sell: parts.slice(1).join(' → ')
                            };
                        }
                        return { buy: line.trim(), sell: '' };
                    }).filter(function(d) { return d.buy.length > 0 && d.sell.length > 0; });
                }
            }

            var savedMarker;
            if (cardContext.isNew) {
                savedMarker = await window.PISPOP_MARKERS.create(payload);
            } else {
                savedMarker = await window.PISPOP_MARKERS.update(cardContext.data.id, payload);

                // После успешного сохранения удаляем с диска старые файловые фото,
                // которые администратор убрал из карточки.
                var deletedPhotos = Array.isArray(cardContext.deletedPhotos) ? cardContext.deletedPhotos : [];
                for (var dpi = 0; dpi < deletedPhotos.length; dpi++) {
                    var deletedPhoto = deletedPhotos[dpi];
                    if (/^\/data\/photos\//.test(deletedPhoto)) {
                        try {
                            await fetch(API_BASE + "/api/markers/" + encodeURIComponent(cardContext.data.id) + "/photos?url=" + encodeURIComponent(deletedPhoto), {
                                method: "DELETE", credentials: "include"
                            });
                        } catch (photoDeleteError) {
                            console.warn("PISPOP-GIS: файл фотографии не удалось удалить", photoDeleteError);
                        }
                    }
                }
            }
            // Фото уже входят в payload и сохраняются вместе с самой меткой.
            await window.PISPOP_MARKERS.refresh();

        } else if (cardContext.kind === "territory") {

            var payload = {
                name: titleInput.value.trim() || "Без названия",
                description: el.cardDescription.value.trim(),
                category: cardContext.data.category || "residential",
                coordinates: cardContext.data.coordinates,
                fillColor: cardContext.data.fillColor,
                borderColor: cardContext.data.borderColor
            };

            if (cardContext.isNew) {
                await window.PISPOP_SETTLEMENTS.create(payload);
            } else {
                await window.PISPOP_SETTLEMENTS.update(cardContext.data.id, payload);
            }

        }

        renderCategoryResults();

        closeCard();

    }

    async function deleteCard() {

        if (!cardContext || cardContext.isNew) {
            return;
        }

        if (cardContext.kind === "marker") {
            await window.PISPOP_MARKERS.remove(cardContext.data.id);
        } else if (cardContext.kind === "territory") {
            await window.PISPOP_SETTLEMENTS.remove(cardContext.data.id);
        }

        renderCategoryResults();

        closeCard();

    }

    function setupCard() {

        el.cardBack.addEventListener("click", closeCard);
        el.cardSave.addEventListener("click", saveCard);
        el.cardDelete.addEventListener("click", deleteCard);

        if (el.markerPhotoModalClose) {
            el.markerPhotoModalClose.addEventListener("click", closeMarkerPhotoModal);
        }
        if (el.markerPhotoModal) {
            el.markerPhotoModal.addEventListener("click", function(e) {
                if (e.target === el.markerPhotoModal) closeMarkerPhotoModal();
            });
        }
        document.addEventListener("keydown", function(e) {
            if (e.key === "Escape" && el.markerPhotoModal && !el.markerPhotoModal.classList.contains("hidden")) {
                closeMarkerPhotoModal();
            }
        });

        document.getElementById("panel-card-title-input").addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                saveCard();
            }
        });

        // Обработчик фотографий подключаем ПОСЛЕ setupElements(),
        // иначе el.markerPhotoInput ещё не существует и обработчик не назначается.
        if (el.markerPhotoInput) {
            el.markerPhotoInput.addEventListener("change", async function(){
                if(!cardContext || cardContext.kind !== "marker") return;
                var files = Array.from(el.markerPhotoInput.files || []);
                el.markerPhotoInput.value = "";
                if(!files.length) return;
                try {
                    var existing = Array.isArray(cardContext.data.photos) ? cardContext.data.photos.slice() : [];
                    if(existing.length + files.length > 8) {
                        throw new Error("Можно добавить максимум 8 фотографий к одной метке");
                    }
                    for(var i = 0; i < files.length; i++) {
                        existing.push(await photoToDataUrl(files[i]));
                    }
                    cardContext.data.photos = existing;
                    renderMarkerPhotos(existing, el.markerPhotoPreview, true);
                } catch(e) {
                    console.error("PISPOP-GIS: ошибка добавления фото", e);
                    alert("Не удалось добавить фото: " + (e.message || e));
                }
            });
        }

    }


    /* ========================================================
       ТАБЛО ПРОСМОТРА (внутри панели, без редактирования)
       ======================================================== */

    var viewCardContext = null;

    function openViewCard(kind, data) {

        el.panelSearch.classList.add("hidden");
        el.cardContainer.classList.add("hidden");
        el.viewCardContainer.classList.remove("hidden");

        viewCardContext = { kind: kind, data: data };

        if (el.viewCardAddMarker) {
            el.viewCardAddMarker.classList.add("hidden");
        }

        if (el.viewCardBoundary) {
            el.viewCardBoundary.classList.add("hidden");
        }

        var belongsTo = document.getElementById("panel-view-card-belongs-to");
        if (belongsTo) {
            belongsTo.classList.add("hidden");
            belongsTo.innerHTML = "";
        }

        var coordsEl = document.getElementById("panel-view-card-coords");
        if (coordsEl) {
            coordsEl.classList.add("hidden");
            coordsEl.innerHTML = "";
        }

        // Скрываем кнопку группового добавления при открытии
        var bulkBtn = document.getElementById("panel-view-card-bulk-add");
        if (bulkBtn) {
            bulkBtn.classList.add("hidden");
        }

        if (kind === "marker") {

            var category = window.PISPOP_MARKERS.categories.find(function (c) {
                return c.id === data.category;
            });

            el.viewCardIcon.textContent = category ? category.icon : "📍";
            el.viewCardIcon.style.background = data.color || categoryColor("default");
            el.viewCardTitle.textContent = category ? category.label : "Метка";
            el.viewCardName.textContent = data.title || "Без названия";
            var markerCategoryEl = document.getElementById("panel-view-card-category");
            if (markerCategoryEl) {
                markerCategoryEl.textContent = category ? category.label : "Метка";
                markerCategoryEl.classList.remove("hidden");
            }
            if (el.viewCardTitle) {
                el.viewCardTitle.classList.add("hidden");
            }

            // Координаты
            if (coordsEl && typeof data.x === "number" && typeof data.z === "number") {
                coordsEl.classList.remove("hidden");
                coordsEl.textContent = "📍 X: " + data.x + "   Z: " + data.z;
            }

            if (data.address) {
                el.viewCardAddress.textContent = data.address;
                el.viewCardAddress.classList.remove("hidden");
            } else {
                el.viewCardAddress.classList.add("hidden");
            }

            // Если это магазин — показываем сделки
            if (data.category === "shop") {
                var shopHTML = '';

                if (data.deals && data.deals.length > 0) {
                    shopHTML += '<div class="shop-deals"><span class="shop-deals-title">🔄 Сделки:</span><ul class="shop-deals-list">';
                    data.deals.forEach(function (deal) {
                        shopHTML += '<li><span class="deal-buy">' + escapeHtml(deal.buy) + '</span> <span class="deal-arrow">→</span> <span class="deal-sell">' + escapeHtml(deal.sell) + '</span></li>';
                    });
                    shopHTML += '</ul></div>';
                } else {
                    shopHTML += '<div class="shop-empty">❌ Сделок пока нет</div>';
                }

                if (shopHTML) {
                    el.viewCardDescription.innerHTML = shopHTML;
                    el.viewCardDescription.classList.remove("hidden");
                } else {
                    el.viewCardDescription.textContent = "Описание пока не добавлено.";
                }

                el.viewCardEdit.textContent = "✏️ Редактировать магазин";
                el.viewCardEdit.classList.remove("danger-btn");
                el.viewCardEdit.classList.add("primary-btn");

            } else {
                el.viewCardDescription.textContent = data.description || "Описание пока не добавлено.";
                el.viewCardEdit.textContent = "Изменить";
                el.viewCardEdit.classList.remove("danger-btn");
                el.viewCardEdit.classList.add("primary-btn");
            }

            // Фотографии метки: одна большая фотография + слайдер
            if (el.viewCardPhotos) {
                el.viewCardPhotos.innerHTML = "";
                var photos = (Array.isArray(data.photos) ? data.photos : []).filter(Boolean);
                el.viewCardPhotos.classList.toggle("hidden", photos.length === 0);

                if (photos.length) {
                    var photoIndex = 0;
                    var frame = document.createElement("div");
                    frame.className = "marker-photo-carousel";

                    var image = document.createElement("img");
                    image.className = "marker-photo-carousel-image";
                    image.alt = "Фото метки";
                    image.addEventListener("click", function(){
                        openMarkerPhotoModal(photos[photoIndex]);
                    });
                    frame.appendChild(image);

                    var prev = document.createElement("button");
                    prev.type = "button";
                    prev.className = "marker-photo-carousel-btn marker-photo-carousel-prev";
                    prev.textContent = "‹";
                    prev.title = "Предыдущее фото";

                    var next = document.createElement("button");
                    next.type = "button";
                    next.className = "marker-photo-carousel-btn marker-photo-carousel-next";
                    next.textContent = "›";
                    next.title = "Следующее фото";

                    var counter = document.createElement("div");
                    counter.className = "marker-photo-carousel-counter";
                    frame.appendChild(counter);

                    function updateMarkerPhotoCarousel() {
                        image.src = photos[photoIndex];
                        image.alt = "Фото " + (photoIndex + 1) + " из " + photos.length;
                        counter.textContent = (photoIndex + 1) + " / " + photos.length;
                        prev.disabled = photos.length <= 1;
                        next.disabled = photos.length <= 1;
                    }

                    prev.addEventListener("click", function(e){
                        e.stopPropagation();
                        if (photos.length > 1) {
                            photoIndex = (photoIndex - 1 + photos.length) % photos.length;
                            updateMarkerPhotoCarousel();
                        }
                    });
                    next.addEventListener("click", function(e){
                        e.stopPropagation();
                        if (photos.length > 1) {
                            photoIndex = (photoIndex + 1) % photos.length;
                            updateMarkerPhotoCarousel();
                        }
                    });

                    frame.appendChild(prev);
                    frame.appendChild(next);

                    // Перелистывание свайпом на телефоне/планшете.
                    var touchStartX = null;
                    frame.addEventListener("touchstart", function(e){
                        if (e.touches && e.touches.length) touchStartX = e.touches[0].clientX;
                    }, {passive:true});
                    frame.addEventListener("touchend", function(e){
                        if (touchStartX === null || !e.changedTouches || !e.changedTouches.length) return;
                        var dx = e.changedTouches[0].clientX - touchStartX;
                        touchStartX = null;
                        if (Math.abs(dx) < 35 || photos.length <= 1) return;
                        if (dx < 0) next.click(); else prev.click();
                    }, {passive:true});

                    el.viewCardPhotos.appendChild(frame);
                    updateMarkerPhotoCarousel();
                }
            }

            // Принадлежность
            if (belongsTo) {
                var houseInfo = null;
                if (window.PISPOP_ADDRESS) {
                    var houses = window.PISPOP_ADDRESS.getHouses();
                    for (var h = 0; h < houses.length; h++) {
                        if (Math.abs(houses[h].x - data.x) < 2 && Math.abs(houses[h].z - data.z) < 2) {
                            houseInfo = houses[h];
                            break;
                        }
                    }
                }

                if (houseInfo) {
                    var streetName = "Улица";
                    if (window.PISPOP_STREETS) {
                        var streets = window.PISPOP_STREETS.getStreets();
                        var street = streets.find(function (s) { return s.id === houseInfo.streetId; });
                        if (street) streetName = street.name;
                    }
                    belongsTo.classList.remove("hidden");
                    belongsTo.innerHTML = "🏠 Дом №" + houseInfo.number + ", " + streetName;
                } else {
                    var territoryName = null;
                    if (window.PISPOP_SETTLEMENTS) {
                        var settlements = window.PISPOP_SETTLEMENTS.getSettlements();
                        for (var s = 0; s < settlements.length; s++) {
                            if (Array.isArray(settlements[s].coordinates) && 
                                window.pointInPolygon(data.x, data.z, settlements[s].coordinates)) {
                                territoryName = settlements[s].name;
                                break;
                            }
                        }
                    }
                    if (territoryName) {
                        belongsTo.classList.remove("hidden");
                        belongsTo.innerHTML = "🗺 " + territoryName;
                    }
                }
            }

        } else if (kind === "territory") {

            var category = (window.PISPOP_SETTLEMENTS ? window.PISPOP_SETTLEMENTS.categories : [])
                .find(function (c) { return c.id === data.category; });

            el.viewCardIcon.textContent = category ? category.icon : "🗺";
            el.viewCardIcon.style.background = data.borderColor || "#3c82f6";
            el.viewCardTitle.textContent = category ? category.label : "Населённый пункт";
            el.viewCardTitle.classList.remove("hidden");
            el.viewCardName.textContent = data.name || "Без названия";
            var territoryCategoryEl = document.getElementById("panel-view-card-category");
            if (territoryCategoryEl) {
                territoryCategoryEl.textContent = "";
                territoryCategoryEl.classList.add("hidden");
            }

            if (coordsEl && Array.isArray(data.coordinates) && data.coordinates.length > 0) {
                var centerX = 0, centerZ = 0;
                for (var p = 0; p < data.coordinates.length; p++) {
                    centerX += data.coordinates[p][0];
                    centerZ += data.coordinates[p][1];
                }
                centerX = Math.round(centerX / data.coordinates.length);
                centerZ = Math.round(centerZ / data.coordinates.length);
                coordsEl.classList.remove("hidden");
                coordsEl.textContent = "📍 Центр: X: " + centerX + "   Z: " + centerZ;
            }

            el.viewCardAddress.classList.add("hidden");

            el.viewCardDescription.textContent = data.description || "Описание пока не добавлено.";

            el.viewCardEdit.textContent = "Изменить";
            el.viewCardEdit.classList.remove("danger-btn");
            el.viewCardEdit.classList.add("primary-btn");

            if (belongsTo) {
                var housesCount = 0;
                var streetsCount = 0;
                if (window.PISPOP_ADDRESS) {
                    var allHouses = window.PISPOP_ADDRESS.getHouses();
                    housesCount = allHouses.filter(function (h) {
                        return window.pointInPolygon(h.x, h.z, data.coordinates);
                    }).length;
                }
                if (window.PISPOP_STREETS) {
                    var allStreets = window.PISPOP_STREETS.getStreets();
                    streetsCount = allStreets.filter(function (s) {
                        return Array.isArray(s.coordinates) && s.coordinates.length > 0 &&
                            window.pointInPolygon(s.coordinates[0][0], s.coordinates[0][1], data.coordinates);
                    }).length;
                }
                if (housesCount > 0 || streetsCount > 0) {
                    belongsTo.classList.remove("hidden");
                    var parts = [];
                    if (housesCount > 0) parts.push("🏠 Домов: " + housesCount);
                    if (streetsCount > 0) parts.push("🚶 Улиц: " + streetsCount);
                    belongsTo.innerHTML = parts.join(" &bull; ");
                }
            }

        } else if (kind === "house") {

            var street =
                (window.PISPOP_STREETS ? window.PISPOP_STREETS.getStreets() : [])
                    .find(function (s) { return s.id === data.streetId; });

            var streetName = (street && street.name) || data.streetName || "Улица";

            el.viewCardIcon.textContent = String(data.number || "?");
            el.viewCardIcon.style.background = "transparent";
            el.viewCardTitle.textContent = "Дом";
            el.viewCardName.textContent = streetName + ", д. " + data.number;

            if (coordsEl && typeof data.x === "number" && typeof data.z === "number") {
                coordsEl.classList.remove("hidden");
                coordsEl.textContent = "📍 X: " + data.x + "   Z: " + data.z;
            }

            el.viewCardAddress.textContent = "X: " + data.x + "   Z: " + data.z;
            el.viewCardAddress.classList.remove("hidden");

            el.viewCardDescription.textContent = "";

            if (el.viewCardAddMarker) {
                el.viewCardAddMarker.textContent = "📍 Добавить метку";
                el.viewCardAddMarker.classList.remove("hidden");
            }

            if (el.viewCardBoundary) {
                el.viewCardBoundary.textContent = (data.territory && data.territory.length >= 3)
                    ? "🗑 Убрать границу"
                    : "🖊 Нарисовать границу";
                el.viewCardBoundary.classList.remove("hidden");
            }

            el.viewCardEdit.textContent = "Удалить";
            el.viewCardEdit.classList.remove("primary-btn");
            el.viewCardEdit.classList.add("danger-btn");

            if (belongsTo) {
                var territoryName = null;
                if (window.PISPOP_SETTLEMENTS) {
                    var settlements = window.PISPOP_SETTLEMENTS.getSettlements();
                    for (var s2 = 0; s2 < settlements.length; s2++) {
                        if (Array.isArray(settlements[s2].coordinates) && 
                            window.pointInPolygon(data.x, data.z, settlements[s2].coordinates)) {
                            territoryName = settlements[s2].name;
                            break;
                        }
                    }
                }
                if (territoryName) {
                    belongsTo.classList.remove("hidden");
                    belongsTo.innerHTML = "🗺 " + territoryName;
                } else {
                    belongsTo.classList.remove("hidden");
                    belongsTo.innerHTML = "🚶 " + streetName;
                }
            }

        } else if (kind === "street") {

            var housesCount = 0;
            if (window.PISPOP_ADDRESS) {
                housesCount = window.PISPOP_ADDRESS.getHouses().filter(function (h) {
                    return h.streetId === data.id;
                }).length;
            }

            var pointsCount = (data.coordinates && data.coordinates.length) || 0;

            el.viewCardIcon.textContent = "🚶";
            el.viewCardIcon.style.background = "#3c6ef6";
            el.viewCardTitle.textContent = "Улица";
            el.viewCardName.textContent = data.name || "Без названия";

            if (coordsEl && Array.isArray(data.coordinates) && data.coordinates.length > 0) {
                var firstPoint = data.coordinates[0];
                coordsEl.classList.remove("hidden");
                coordsEl.textContent = "📍 Начало: X: " + firstPoint[0] + "   Z: " + firstPoint[1];
            }

            el.viewCardAddress.textContent =
                "🏠 Домов: " + housesCount + "    📍 " + pointsCount + " точек";
            el.viewCardAddress.classList.remove("hidden");

            el.viewCardDescription.textContent = "";

            // Кнопка "Добавить дом" (один)
            if (el.viewCardAddMarker) {
                el.viewCardAddMarker.textContent = "🏠 Добавить дом";
                el.viewCardAddMarker.classList.remove("hidden");
            }

            // ===== КНОПКА "Добавить дома группой" — ПОКАЗЫВАЕМ =====
            var bulkBtn = document.getElementById("panel-view-card-bulk-add");
            if (bulkBtn) {
                bulkBtn.classList.remove("hidden");
                // Обработчик
                bulkBtn.onclick = function() {
                    if (window.PISPOP_ADDRESS && window.PISPOP_ADDRESS.bulkAdd) {
                        window.PISPOP_ADDRESS.bulkAdd(data.id);
                        closeViewCardUI();
                    } else {
                        showToast("Система адресации недоступна", "error");
                    }
                };
            } else {
                console.warn("[PISPOP-GIS] #panel-view-card-bulk-add not found in DOM!");
            }

            el.viewCardEdit.textContent = "🗑 Удалить улицу";
            el.viewCardEdit.classList.remove("primary-btn");
            el.viewCardEdit.classList.add("danger-btn");

            // Принадлежность
            if (belongsTo && Array.isArray(data.coordinates) && data.coordinates.length > 0) {
                var firstPoint = data.coordinates[0];
                var territoryName = null;
                if (window.PISPOP_SETTLEMENTS) {
                    var settlements = window.PISPOP_SETTLEMENTS.getSettlements();
                    for (var s3 = 0; s3 < settlements.length; s3++) {
                        if (Array.isArray(settlements[s3].coordinates) && 
                            window.pointInPolygon(firstPoint[0], firstPoint[1], settlements[s3].coordinates)) {
                            territoryName = settlements[s3].name;
                            break;
                        }
                    }
                }
                if (territoryName) {
                    belongsTo.classList.remove("hidden");
                    belongsTo.innerHTML = "🗺 " + territoryName;
                }
            }

        }

    }

    function closeViewCardUI() {

        el.viewCardContainer.classList.add("hidden");
        el.panelSearch.classList.remove("hidden");
        viewCardContext = null;

        // Скрываем кнопку группового добавления
        var bulkBtn = document.getElementById("panel-view-card-bulk-add");
        if (bulkBtn) {
            bulkBtn.classList.add("hidden");
        }

    }

    function closeViewCard() {

        var context = viewCardContext;

        closeViewCardUI();

        if (context && context.kind === "house" && window.PISPOP_ADDRESS) {
            window.PISPOP_ADDRESS.deselectHouse();
        } else if (context && context.kind === "street" && window.PISPOP_STREETS) {
            window.PISPOP_STREETS.deselectStreet();
        }

    }

    function getViewCardCoordinate(kind, data) {

        if (kind === "marker" || kind === "house") {
            if (typeof data.x === "number" && typeof data.z === "number") {
                return [data.x, data.z];
            }
            return null;
        }

        if (kind === "street") {
            if (Array.isArray(data.coordinates) && data.coordinates.length > 0) {
                return data.coordinates[0];
            }
            return null;
        }

        if (kind === "territory") {
            if (Array.isArray(data.coordinates) && data.coordinates.length > 0) {
                var cx = 0, cz = 0;
                data.coordinates.forEach(function (p) {
                    cx += p[0];
                    cz += p[1];
                });
                return [
                    Math.round(cx / data.coordinates.length),
                    Math.round(cz / data.coordinates.length)
                ];
            }
            return null;
        }

        return null;

    }

    function setupViewCard() {

        el.viewCardBack.addEventListener("click", closeViewCard);
        el.viewCardClose.addEventListener("click", closeViewCard);

        if (el.viewCardRouteFrom) {

            el.viewCardRouteFrom.addEventListener("click", function () {

                if (!viewCardContext) {
                    return;
                }

                var coord = getViewCardCoordinate(viewCardContext.kind, viewCardContext.data);

                if (!coord) {
                    return;
                }

                closeViewCard();
                window.PISPOP_ROUTES.setFrom(coord);
                showPanel("routes");

            });

        }

        if (el.viewCardRouteTo) {

            el.viewCardRouteTo.addEventListener("click", function () {

                if (!viewCardContext) {
                    return;
                }

                var coord = getViewCardCoordinate(viewCardContext.kind, viewCardContext.data);

                if (!coord) {
                    return;
                }

                closeViewCard();
                window.PISPOP_ROUTES.setTo(coord);
                showPanel("routes");

            });

        }

        document.addEventListener("pispop:house-deselected", function () {
            if (viewCardContext && viewCardContext.kind === "house") {
                closeViewCardUI();
            }
        });

        document.addEventListener("pispop:street-deselected", function () {
            if (viewCardContext && viewCardContext.kind === "street") {
                closeViewCardUI();
            }
        });

        el.viewCardEdit.addEventListener("click", function () {

            if (!viewCardContext) {
                return;
            }

            var kind = viewCardContext.kind;
            var data = viewCardContext.data;

            if (kind === "house") {

                if (!confirm("Удалить дом №" + data.number + "?")) {
                    return;
                }

                if (window.PISPOP_ADDRESS && typeof window.PISPOP_ADDRESS.deleteHouse === "function") {
                    window.PISPOP_ADDRESS.deleteHouse(data);
                }

                closeViewCardUI();
                return;

            }

            if (kind === "street") {

                if (!confirm("Удалить улицу \"" + data.name + "\" и все дома на ней?")) {
                    return;
                }

                if (window.PISPOP_STREETS && typeof window.PISPOP_STREETS.deleteStreet === "function") {
                    window.PISPOP_STREETS.deleteStreet(data);
                }

                closeViewCardUI();
                return;

            }

            closeViewCard();

            if (kind === "marker") {
                openMarkerCard(data, false);
            } else {
                openTerritoryCard(data, false);
            }

        });

        if (el.viewCardBoundary) {

            el.viewCardBoundary.addEventListener("click", function () {

                if (!viewCardContext || viewCardContext.kind !== "house") {
                    return;
                }

                var house = viewCardContext.data;

                if (house.territory && house.territory.length >= 3) {
                    if (!confirm("Убрать границу дома №" + house.number + "?")) {
                        return;
                    }
                    if (window.PISPOP_ADDRESS) {
                        window.PISPOP_ADDRESS.clearHouseTerritory(house);
                    }
                    house.territory = null;
                    el.viewCardBoundary.textContent = "🖊 Нарисовать границу";
                    return;
                }

                startHouseBoundaryDrawing(house);

            });

        }

        if (el.viewCardAddMarker) {

            el.viewCardAddMarker.addEventListener("click", async function () {

                if (!viewCardContext) {
                    return;
                }

                if (viewCardContext.kind === "street") {
                    var street = viewCardContext.data;
                    closeViewCardUI();
                    if (window.PISPOP_ADDRESS) {
                        window.PISPOP_ADDRESS.addHouse(street.id);
                    }
                    return;
                }

                if (viewCardContext.kind !== "house") {
                    return;
                }

                var house = viewCardContext.data;

                var street =
                    (window.PISPOP_STREETS ? window.PISPOP_STREETS.getStreets() : [])
                        .find(function (s) { return s.id === house.streetId; });

                var streetName = (street && street.name) || house.streetName || "Улица";
                var address = streetName + ", д. " + house.number;

                closeViewCardUI();

                openMarkerCard(
                    {
                        x: house.x,
                        z: house.z,
                        title: "",
                        description: "",
                        address: address,
                        category: "default",
                        color: categoryColor("default")
                    },
                    true
                );

            });

        }

    }


    /* ========================================================
       СОБЫТИЯ ДАННЫХ
       ======================================================== */

    function setupDataEvents() {

        document.addEventListener("pispop:territories-loaded", renderSettlementList);

    }


    /* ========================================================
       ЗУМ (кнопки +/- и ползунок справа по центру)
       ======================================================== */

    function setupZoomControls() {

        var zoomIn = document.getElementById("zoom-in");
        var zoomOut = document.getElementById("zoom-out");
        var zoomSlider = document.getElementById("zoom-slider");

        if (!zoomIn || !zoomOut || !map) {
            return;
        }

        var view = map.getView();

        function zoomToSliderValue(zoom) {

            var min = view.getMinZoom();
            var max = view.getMaxZoom();

            if (
                typeof min !== "number" ||
                typeof max !== "number" ||
                max === min
            ) {
                return 50;
            }

            return Math.round(((zoom - min) / (max - min)) * 100);

        }

        function sliderValueToZoom(value) {

            var min = view.getMinZoom();
            var max = view.getMaxZoom();

            if (
                typeof min !== "number" ||
                typeof max !== "number"
            ) {
                return view.getZoom();
            }

            return min + (value / 100) * (max - min);

        }

        function syncSlider() {

            var zoom = view.getZoom();

            if (typeof zoom === "number") {
                if (zoomSlider) zoomSlider.value = zoomToSliderValue(zoom);
            }

        }

        zoomIn.style.opacity = "1";
        zoomOut.style.opacity = "1";
        zoomIn.style.visibility = "visible";
        zoomOut.style.visibility = "visible";

        zoomIn.addEventListener("click", function () {

            var zoom = view.getZoom();

            if (typeof zoom === "number") {
                view.animate({ zoom: zoom + 1, duration: 200 });
            }

        });

        zoomOut.addEventListener("click", function () {

            var zoom = view.getZoom();

            if (typeof zoom === "number") {
                view.animate({ zoom: zoom - 1, duration: 200 });
            }

        });

        if (zoomSlider) {
            zoomSlider.addEventListener("input", function () {
                var zoom = sliderValueToZoom(Number(zoomSlider.value));
                view.setZoom(zoom);
            });
        }

        view.on("change:resolution", syncSlider);

        syncSlider();

    }


    /* ========================================================
       КООРДИНАТЫ (курсор)
       ======================================================== */

    function setupCoordinates() {

        var coordinates = document.getElementById("coordinates");

        if (!coordinates || !map) {
            return;
        }

        map.on("pointermove", function (event) {

            var dataCoord = toDataCoordinate(event.coordinate);

            coordinates.textContent =
                "X: " + Math.round(dataCoord[0]) +
                "    Z: " + Math.round(dataCoord[1]);

        });

    }


    /* ========================================================
       МЕТКА-УКАЗАТЕЛЬ ПО КЛИКУ НА КАРТЕ
       ======================================================== */

    function isAnyEditingModeActive() {

        if (window.PISPOP_STREETS && window.PISPOP_STREETS.isDrawing()) {
            return true;
        }

        if (window.PISPOP_ROADS && window.PISPOP_ROADS.isDrawing && window.PISPOP_ROADS.isDrawing()) {
            return true;
        }

        if (window.PISPOP_ADDRESS && (window.PISPOP_ADDRESS.isAddingMode() || window.PISPOP_ADDRESS.isBulkMode())) {
            return true;
        }

        if (window.PISPOP_MARKERS && window.PISPOP_MARKERS.isAddingMode()) {
            return true;
        }

        if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking && window.PISPOP_ROUTES.isPicking()) {
            return true;
        }

        if (drawingTerritory) {
            return true;
        }

        if (drawingHouseBoundary) {
            return true;
        }

        if (window.PISPOP_WATER && window.PISPOP_WATER.isDrawing()) {
            return true;
        }

        return false;

    }

    function setupClickToPin() {

        if (!map) {
            return;
        }

        map.on("singleclick", function (event) {

            if (isAnyEditingModeActive()) {
                return;
            }

            var hasFeature = map.hasFeatureAtPixel(event.pixel, {
                hitTolerance: 12
            });

            if (hasFeature) {
                return;
            }

            var dataCoord = toDataCoordinate(event.coordinate);
            var coordinate = [Math.round(dataCoord[0]), Math.round(dataCoord[1])];

            showTempMarker(coordinate);

        });

    }


    /* ========================================================
       ПУБЛИЧНЫЙ API UI
       ======================================================== */

    window.PISPOP_UI = {
        refreshFilters: function() {
            renderCategoryFilters();
            renderCategoryResults();
        },
        refreshAll: function() {
            renderCategoryFilters();
            renderCategoryResults();
            renderSettlementList();
            renderMarkerList();
        }
    };


    /* ========================================================
       ИНИЦИАЛИЗАЦИЯ
       ======================================================== */

    var attempts = 0;
    var MAX_ATTEMPTS = 100;

    function tryInit() {

        attempts++;

        map = getMap();

        if (!map) {

            if (attempts >= MAX_ATTEMPTS) {
                console.error("PISPOP-GIS: ui.js не нашёл карту.");
                return;
            }

            setTimeout(tryInit, 200);
            return;

        }

        cacheEls();
        setupMapTitle();
        setupAdminGate();
        setupRail();
        setupCollapse();
        setupLayerToggles();
        renderCategoryFilters();
        setupSearch();
        setupMarkerTool();
        setupTerritoryTool();
        setupWaterTool();
        setupRoadsTool();
        setupHouseTool();
        setupRoutes();
        setupCard();
        setupViewCard();
        setupDataEvents();
        setupCoordinates();
        setupZoomControls();
        setupClickToPin();

        map.on("moveend", function () {

            if (activeCategory) {
                renderCategoryResults();
            }

        });

        console.log("PISPOP-GIS: ui.js подключён.");

    }

    tryInit();

}());