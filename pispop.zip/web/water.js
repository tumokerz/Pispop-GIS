/*
 * ============================================================
 * PISPOP-GIS
 * water.js
 *
 * Водоёмы - полигоны, которые пользователь рисует вручную поверх
 * воды на карте. Своей карточки не имеют - только рисуются
 * полупрозрачным слоем и используются routes.js, чтобы
 * определить, пересекает ли пеший маршрут воду (и предупредить,
 * что этот участок придётся переплыть).
 *
 * ============================================================
 */

(function () {

    "use strict";

    let map = null;

    let waterSource = null;
    let waterLayer = null;

    let drawInteraction = null;
    let drawing = false;

    let zones = [];

    let initialized = false;


    /* ========================================================
       КАРТА / КООРДИНАТЫ
       ======================================================== */

    function getMap() {

        if (
            window.unmined &&
            window.unmined.map &&
            typeof window.unmined.map.getView === "function"
        ) {
            return window.unmined.map;
        }

        if (window.unmined) {

            const keys = Object.keys(window.unmined);

            for (let i = 0; i < keys.length; i++) {

                const value = window.unmined[keys[i]];

                if (
                    value &&
                    typeof value.getView === "function" &&
                    typeof value.addLayer === "function"
                ) {
                    return value;
                }

            }

        }

        return null;

    }

    function toDataCoordinate(viewCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return viewCoordinate;
        }

        return ol.proj.transform(
            viewCoordinate,
            window.unmined.viewProjection,
            window.unmined.dataProjection
        );

    }

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }


    /* ========================================================
       ЗАГРУЗКА / СОХРАНЕНИЕ
       ======================================================== */

    async function loadZones() {

        try {

            const response = await fetch("/api/water", { cache: "no-cache" });

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            const data = await response.json();

            zones = Array.isArray(data) ? data : [];

        } catch (error) {

            console.error("PISPOP-GIS: не удалось загрузить водоёмы:", error);
            zones = [];

        }

    }

    async function createZone(coordinates) {

        const response = await fetch("/api/water", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ coordinates: coordinates })
        });

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        const zone = await response.json();
        zones.push(zone);
        render();

        return zone;

    }

    async function deleteZone(id) {

        const response = await fetch("/api/water/" + encodeURIComponent(id), {
            method: "DELETE"
        });

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        zones = zones.filter(function (z) { return z.id !== id; });
        render();

    }


    /* ========================================================
       ОТРИСОВКА
       ======================================================== */

    function render() {

        if (!waterSource) return;
        waterSource.clear();

        zones.forEach(function (zone) {

            if (!Array.isArray(zone.coordinates) || zone.coordinates.length < 3) {
                return;
            }

            const ring = zone.coordinates.map(toViewCoordinate);

            waterSource.addFeature(new ol.Feature({
                geometry: new ol.geom.Polygon([ring]),
                waterZoneData: zone
            }));

        });

    }

    const waterStyle = new ol.style.Style({
        fill: new ol.style.Fill({ color: "rgba(28,107,209,0.22)" }),
        stroke: new ol.style.Stroke({ color: "#1c6bd1", width: 1.5, lineDash: [3, 5] })
    });


    /* ========================================================
       РИСОВАНИЕ
       ======================================================== */

    function startDrawing() {

        if (drawing || !map) return;

        drawInteraction = new ol.interaction.Draw({
            source: new ol.source.Vector(),
            type: "Polygon"
        });

        drawInteraction.on("drawend", function (event) {

            const viewCoordinates = event.feature.getGeometry().getCoordinates()[0];
            const coordinates = viewCoordinates.map(toDataCoordinate);

            stopDrawing();

            createZone(coordinates).catch(function (error) {
                console.error("PISPOP-GIS: не удалось сохранить водоём:", error);
            });

        });

        map.addInteraction(drawInteraction);
        drawing = true;

        document.dispatchEvent(new CustomEvent("pispop:water-drawing", { detail: true }));

    }

    function stopDrawing() {

        if (drawInteraction && map) {
            map.removeInteraction(drawInteraction);
        }

        drawInteraction = null;
        drawing = false;

        document.dispatchEvent(new CustomEvent("pispop:water-drawing", { detail: false }));

    }


    /* ========================================================
       ПЕРЕСЕЧЕНИЕ ОТРЕЗКА С ВОДОЙ (для routes.js)
       ======================================================== */

    function segmentsIntersect(p1, p2, p3, p4) {

        function cross(o, a, b) {
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
        }

        const d1 = cross(p3, p4, p1);
        const d2 = cross(p3, p4, p2);
        const d3 = cross(p1, p2, p3);
        const d4 = cross(p1, p2, p4);

        if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
            ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
            return true;
        }

        return false;

    }

    function pointInPolygon(point, ring) {

        let inside = false;

        for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {

            const xi = ring[i][0], zi = ring[i][1];
            const xj = ring[j][0], zj = ring[j][1];

            const intersect =
                ((zi > point[1]) !== (zj > point[1])) &&
                (point[0] < (xj - xi) * (point[1] - zi) / (zj - zi) + xi);

            if (intersect) {
                inside = !inside;
            }

        }

        return inside;

    }

    /*
     * Проверяет, пересекает ли отрезок from->to хотя бы один
     * нарисованный водоём, и если да - прикидывает, сколько
     * блоков этого отрезка проходит по воде (грубая оценка:
     * если обе точки внутри полигона - весь отрезок; если одна
     * внутри - примерно половина расстояния до пересечения
     * границы; иначе считается по факту пересечения рёбер).
     */
    function checkCrossing(from, to) {

        let totalSwim = 0;
        let crossed = false;

        zones.forEach(function (zone) {

            const ring = zone.coordinates;

            if (!Array.isArray(ring) || ring.length < 3) {
                return;
            }

            const fromInside = pointInPolygon(from, ring);
            const toInside = pointInPolygon(to, ring);

            const intersections = [];

            for (let i = 0; i < ring.length; i++) {

                const a = ring[i];
                const b = ring[(i + 1) % ring.length];

                if (segmentsIntersect(from, to, a, b)) {
                    intersections.push(true);
                }

            }

            if (!fromInside && !toInside && intersections.length === 0) {
                return;
            }

            crossed = true;

            if (fromInside && toInside) {

                totalSwim += distance(from, to);

            } else if (intersections.length > 0) {

                // Грубая оценка длины пересечения: если ровно одна
                // точка внутри - примерно половина всего отрезка,
                // если снаружи обе, но линия проходит сквозь
                // полигон - тоже примерно половина. Точная геометрия
                // тут избыточна для ориентировочной оценки "сколько
                // придётся плыть".
                totalSwim += distance(from, to) * 0.5;

            }

        });

        function distance(a, b) {
            const dx = a[0] - b[0];
            const dz = a[1] - b[1];
            return Math.sqrt(dx * dx + dz * dz);
        }

        return crossed ? { distance: Math.round(totalSwim) } : null;

    }


    /* ========================================================
       АВТОМАТИЧЕСКОЕ ОПРЕДЕЛЕНИЕ ВОДОЁМОВ ПО ЦЕЛЬНОЙ КАРТЕ
       ========================================================

       Алгоритм работает полностью в браузере и не требует Python,
       OpenCV или других зависимостей:
         1) уменьшаем изображение карты;
         2) выделяем характерные синие цвета воды;
         3) закрываем мелкие дырки и шум;
         4) находим связные области;
         5) строим контуры областей по ячейкам маски;
         6) переводим пиксели в координаты Minecraft X/Z;
         7) одной операцией заменяем water.json на результат.

       Это позволяет в дальнейшем просто заменить
       data/map-source/map.jpg на новую цельную карту и нажать
       «Автоопределить водоёмы».
    */

    const AUTO_DETECT_DOWNSAMPLE = 3;
    const AUTO_DETECT_MIN_COMPONENT_CELLS = 20;
    const AUTO_DETECT_MAX_ZONES = 120;
    const AUTO_DETECT_MAX_VERTICES = 220;

    function rgbToHsv(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const d = max - min;
        let h = 0;

        if (d !== 0) {
            if (max === r) h = ((g - b) / d) % 6;
            else if (max === g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h /= 6;
            if (h < 0) h += 1;
        }

        const s = max === 0 ? 0 : d / max;
        return [h, s, max];
    }

    function isWaterPixel(r, g, b) {
        const hsv = rgbToHsv(r, g, b);
        const h = hsv[0];
        const sat = hsv[1];
        const val = hsv[2];

        // Minecraft-вода на uNmINeD обычно лежит в синем диапазоне.
        // Светлый лёд/снег отсекаем повышенным порогом насыщенности.
        return (
            h >= 0.264 && h <= 0.375 &&
            sat >= 0.39 &&
            val >= 0.18 &&
            b > r * 1.10 &&
            b > g * 1.02 &&
            (b - r) >= 25
        );
    }

    function morphMask(input, width, height, radius, dilate) {
        const output = new Uint8Array(input.length);
        const size = radius * 2 + 1;

        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                let hit = dilate ? false : true;

                for (let dy = -radius; dy <= radius; dy++) {
                    const yy = y + dy;
                    if (yy < 0 || yy >= height) {
                        if (!dilate) { hit = false; break; }
                        continue;
                    }

                    for (let dx = -radius; dx <= radius; dx++) {
                        const xx = x + dx;
                        if (xx < 0 || xx >= width) {
                            if (!dilate) { hit = false; break; }
                            continue;
                        }

                        const value = input[yy * width + xx] !== 0;
                        if (dilate && value) {
                            hit = true;
                            break;
                        }
                        if (!dilate && !value) {
                            hit = false;
                            break;
                        }
                    }

                    if ((dilate && hit) || (!dilate && !hit)) break;
                }

                output[y * width + x] = hit ? 1 : 0;
            }
        }

        return output;
    }

    function closeMask(mask, width, height, radius) {
        return morphMask(
            morphMask(mask, width, height, radius, true),
            width,
            height,
            radius,
            false
        );
    }

    function openMask(mask, width, height, radius) {
        return morphMask(
            morphMask(mask, width, height, radius, false),
            width,
            height,
            radius,
            true
        );
    }

    function simplifyPolyline(points, tolerance) {
        if (points.length <= 3) return points.slice();

        function sqDist(p, q) {
            const dx = p[0] - q[0];
            const dy = p[1] - q[1];
            return dx * dx + dy * dy;
        }

        function sqSegDist(p, a, b) {
            let x = a[0];
            let y = a[1];
            let dx = b[0] - x;
            let dy = b[1] - y;

            if (dx !== 0 || dy !== 0) {
                const t = ((p[0] - x) * dx + (p[1] - y) * dy) / (dx * dx + dy * dy);
                if (t > 1) { x = b[0]; y = b[1]; }
                else if (t > 0) { x += dx * t; y += dy * t; }
            }

            dx = p[0] - x;
            dy = p[1] - y;
            return dx * dx + dy * dy;
        }

        function simplifyDP(points, first, last, sqTolerance, simplified) {
            let maxSqDist = sqTolerance;
            let index = -1;

            for (let i = first + 1; i < last; i++) {
                const sqDist = sqSegDist(points[i], points[first], points[last]);
                if (sqDist > maxSqDist) {
                    index = i;
                    maxSqDist = sqDist;
                }
            }

            if (index !== -1) {
                if (index - first > 1) simplifyDP(points, first, index, sqTolerance, simplified);
                simplified.push(points[index]);
                if (last - index > 1) simplifyDP(points, index, last, sqTolerance, simplified);
            }
        }

        const sqTolerance = tolerance * tolerance;
        const result = [points[0]];
        simplifyDP(points, 0, points.length - 1, sqTolerance, result);
        result.push(points[points.length - 1]);
        return result;
    }

    function buildComponentContours(mask, width, height, componentId, labels) {
        const edges = new Map();

        function addEdge(ax, ay, bx, by) {
            const key = ax + "," + ay;
            if (!edges.has(key)) edges.set(key, []);
            edges.get(key).push([bx, by]);
        }

        function isComponent(x, y) {
            return x >= 0 && x < width && y >= 0 && y < height &&
                labels[y * width + x] === componentId;
        }

        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                if (!isComponent(x, y)) continue;

                if (!isComponent(x, y - 1)) addEdge(x, y, x + 1, y);
                if (!isComponent(x + 1, y)) addEdge(x + 1, y, x + 1, y + 1);
                if (!isComponent(x, y + 1)) addEdge(x + 1, y + 1, x, y + 1);
                if (!isComponent(x - 1, y)) addEdge(x, y + 1, x, y);
            }
        }

        const loops = [];

        while (edges.size) {
            const startKey = edges.keys().next().value;
            const start = startKey.split(",").map(Number);
            const loop = [start];
            let current = start;
            let guard = 0;

            while (guard++ < 100000) {
                const key = current[0] + "," + current[1];
                const list = edges.get(key);
                if (!list || !list.length) break;

                const next = list.pop();
                if (!list.length) edges.delete(key);
                current = next;

                if (current[0] === start[0] && current[1] === start[1]) break;
                loop.push(current);
            }

            if (loop.length >= 4) loops.push(loop);
        }

        loops.sort(function (a, b) { return b.length - a.length; });
        return loops;
    }

    function getAutoMapBounds(imageWidth, imageHeight) {
        const props = window.UnminedMapProperties || {};
        const minRegionX = Number.isFinite(Number(props.minRegionX)) ? Number(props.minRegionX) : -14;
        const maxRegionX = Number.isFinite(Number(props.maxRegionX)) ? Number(props.maxRegionX) : 13;
        const minRegionZ = Number.isFinite(Number(props.minRegionZ)) ? Number(props.minRegionZ) : -14;
        const maxRegionZ = Number.isFinite(Number(props.maxRegionZ)) ? Number(props.maxRegionZ) : 13;
        const centerX = Number.isFinite(Number(props.centerX)) ? Number(props.centerX) : 0;
        const centerZ = Number.isFinite(Number(props.centerZ)) ? Number(props.centerZ) : -16;

        const worldWidth = (maxRegionX - minRegionX + 1) * 512;
        const worldHeight = (maxRegionZ - minRegionZ + 1) * 512;

        return {
            left: centerX - worldWidth / 2,
            top: centerZ - worldHeight / 2,
            scaleX: worldWidth / imageWidth,
            scaleZ: worldHeight / imageHeight
        };
    }

    function pixelToData(px, py, bounds) {
        return [
            Number((bounds.left + px * bounds.scaleX).toFixed(2)),
            Number((bounds.top + py * bounds.scaleZ).toFixed(2))
        ];
    }

    async function detectWaterFromImage(source, progressCallback) {
        const image = new Image();
        image.decoding = "async";

        let objectUrl = null;
        if (source instanceof Blob) objectUrl = URL.createObjectURL(source);
        else objectUrl = String(source);

        try {
            await new Promise(function (resolve, reject) {
                image.onload = resolve;
                image.onerror = function () { reject(new Error("Не удалось загрузить карту")); };
                image.src = objectUrl;
            });

            const width = image.naturalWidth || image.width;
            const height = image.naturalHeight || image.height;
            const ds = AUTO_DETECT_DOWNSAMPLE;
            const gridWidth = Math.max(1, Math.floor(width / ds));
            const gridHeight = Math.max(1, Math.floor(height / ds));

            const canvas = document.createElement("canvas");
            canvas.width = gridWidth;
            canvas.height = gridHeight;
            const ctx = canvas.getContext("2d", { willReadFrequently: true });
            ctx.drawImage(image, 0, 0, gridWidth, gridHeight);

            const pixels = ctx.getImageData(0, 0, gridWidth, gridHeight).data;
            let mask = new Uint8Array(gridWidth * gridHeight);

            for (let i = 0, p = 0; i < mask.length; i++, p += 4) {
                mask[i] = isWaterPixel(pixels[p], pixels[p + 1], pixels[p + 2]) ? 1 : 0;
            }

            if (progressCallback) progressCallback(20, "Анализ цветов воды…");

            // Закрываем небольшие разрывы воды между соседними тайлами
            // и удаляем одиночный пиксельный шум.
            mask = closeMask(mask, gridWidth, gridHeight, 2);
            mask = openMask(mask, gridWidth, gridHeight, 1);

            if (progressCallback) progressCallback(45, "Поиск отдельных водоёмов…");

            const labels = new Int32Array(mask.length);
            let componentId = 0;
            const components = [];
            const queue = new Int32Array(mask.length);

            for (let start = 0; start < mask.length; start++) {
                if (!mask[start] || labels[start]) continue;
                componentId++;
                let head = 0;
                let tail = 0;
                queue[tail++] = start;
                labels[start] = componentId;
                let area = 0;

                while (head < tail) {
                    const index = queue[head++];
                    area++;
                    const x = index % gridWidth;
                    const y = Math.floor(index / gridWidth);

                    const neighbors = [index - 1, index + 1, index - gridWidth, index + gridWidth];
                    if (x === 0) neighbors[0] = -1;
                    if (x === gridWidth - 1) neighbors[1] = -1;
                    if (y === 0) neighbors[2] = -1;
                    if (y === gridHeight - 1) neighbors[3] = -1;

                    for (let n = 0; n < 4; n++) {
                        const ni = neighbors[n];
                        if (ni >= 0 && ni < mask.length && mask[ni] && !labels[ni]) {
                            labels[ni] = componentId;
                            queue[tail++] = ni;
                        }
                    }
                }

                if (area >= AUTO_DETECT_MIN_COMPONENT_CELLS) {
                    components.push({ id: componentId, area: area });
                }
            }

            components.sort(function (a, b) { return b.area - a.area; });
            components.splice(AUTO_DETECT_MAX_ZONES);

            const bounds = getAutoMapBounds(width, height);
            const zonesDetected = [];

            components.forEach(function (component, index) {
                const loops = buildComponentContours(mask, gridWidth, gridHeight, component.id, labels);
                if (!loops.length) return;

                const loop = loops[0];
                let simplified = simplifyPolyline(loop, 1.5);
                if (simplified.length > AUTO_DETECT_MAX_VERTICES) {
                    simplified = simplifyPolyline(loop, 3.0);
                }
                if (simplified.length < 3) return;

                const coordinates = simplified.map(function (point) {
                    return pixelToData(
                        (point[0] + 0.0) * ds,
                        (point[1] + 0.0) * ds,
                        bounds
                    );
                });

                zonesDetected.push({
                    id: "water-auto-" + String(index + 1).padStart(3, "0"),
                    name: "",
                    coordinates: coordinates,
                    source: "auto",
                    sourceImage: "map.jpg"
                });
            });

            if (progressCallback) progressCallback(80, "Подготовка контуров…");

            return zonesDetected;

        } finally {
            if (source instanceof Blob && objectUrl) URL.revokeObjectURL(objectUrl);
        }
    }

    async function replaceWithAutoDetectedZones(source, progressCallback) {
        const detected = await detectWaterFromImage(source, progressCallback);

        const response = await fetch("/api/water/replace", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ zones: detected })
        });

        if (!response.ok) {
            let detail = "HTTP " + response.status;
            try {
                const body = await response.json();
                if (body && body.error) detail = body.error;
            } catch (_) {}
            throw new Error(detail);
        }

        const result = await response.json();
        zones = detected;
        render();

        if (progressCallback) progressCallback(100, "Готово");
        return { count: Number(result.count || detected.length), zones: detected };
    }

    async function autoDetectFromProjectMap(progressCallback) {
        const response = await fetch("/data/map-source/map.jpg", { cache: "no-cache" });
        if (!response.ok) throw new Error("В проекте нет data/map-source/map.jpg");
        const blob = await response.blob();
        return replaceWithAutoDetectedZones(blob, progressCallback);
    }

    async function autoDetectFromFile(file, progressCallback) {
        if (!file) throw new Error("Файл карты не выбран");
        if (!/^image\/(jpeg|jpg|png|webp)$/i.test(file.type || "")) {
            throw new Error("Нужен PNG, JPG или WEBP файл карты");
        }
        return replaceWithAutoDetectedZones(file, progressCallback);
    }

    /* ========================================================
       ИНИЦИАЛИЗАЦИЯ
       ======================================================== */

    async function initialize() {

        if (initialized) {
            return true;
        }

        map = getMap();

        if (!map) {
            return false;
        }

        waterSource = new ol.source.Vector();
        waterLayer = new ol.layer.Vector({
            source: waterSource,
            zIndex: 5000,
            style: waterStyle
        });

        map.addLayer(waterLayer);

        await loadZones();
        render();

        initialized = true;

        console.log("PISPOP-GIS: water.js подключён.");

        return true;

    }

    let attempts = 0;
    const MAX_ATTEMPTS = 100;

    function waitForMap() {

        attempts++;

        initialize().then(function (ok) {

            if (ok) return;

            if (attempts >= MAX_ATTEMPTS) {
                console.error("PISPOP-GIS: карта не найдена (water).");
                return;
            }

            setTimeout(waitForMap, 200);

        });

    }


    /* ========================================================
       ПУБЛИЧНЫЙ API
       ======================================================== */

    window.PISPOP_WATER = {

        getZones: function () {
            return zones;
        },

        startDrawing: startDrawing,
        stopDrawing: stopDrawing,

        isDrawing: function () {
            return drawing;
        },

        deleteZone: deleteZone,

        // Проверка пересечения отрезка (data-координаты) с водой,
        // используется routes.js для пешего маршрута.
        checkCrossing: checkCrossing,

        // Автоматически определяет водоёмы по цельной карте.
        autoDetectFromProjectMap: autoDetectFromProjectMap,
        autoDetectFromFile: autoDetectFromFile,
        detectWaterFromImage: detectWaterFromImage

    };


    waitForMap();

}());
