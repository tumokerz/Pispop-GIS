/*
 * ============================================================
 * PISPOP-GIS
 * markers.js
 *
 * Система меток.
 *
 * - Метки хранятся на сервере (/api/markers), поэтому видны
 *   всем, кто заходит на карту (сайт, приложение и т.д.).
 * - Режим добавления: кнопка "Добавить метку" -> клик по карте
 *   -> открывается карточка для ввода названия/описания/цвета.
 * - Клик по существующей метке открывает карточку объекта
 *   с возможностью редактирования и удаления.
 *
 * ============================================================
 */

(function () {

    "use strict";

    var API_BASE = window.PISPOP_API_BASE || "";

    var MARKER_CATEGORIES = [
        { id: "default", label: "Обычная", color: "#6b7280", icon: "📍" },
        { id: "warehouse", label: "Склады", color: "#8d6e63", icon: "📦" },
        { id: "farm", label: "Фермы", color: "#588157", icon: "🌾" },
        { id: "factory", label: "Заводы", color: "#6d597a", icon: "🏭" },
        { id: "landmark", label: "Достопримечательности", color: "#e09f3e", icon: "🏛" },
        { id: "park", label: "Парки", color: "#2a9d8f", icon: "🌳" },
        { id: "ice_station", label: "Станция ледяной дороги", color: "#8cbbd9", icon: "🚉" },
        { id: "rail_station", label: "ЖД-станция", color: "#6b7280", icon: "🚆" },
        { id: "metro_station", label: "Станция метро", color: "#b04cff", icon: "🚇" },
        { id: "food", label: "Места питания", color: "#e76f51", icon: "🍽️" },
        { id: "statue", label: "Статуи", color: "#b8860b", icon: "🗿" },
        { id: "mobspawn", label: "Фермы мобов", color: "#4e4e4c", icon: "💀" },
        { id: "shop", label: "Магазин", color: "#f59e0b", icon: "🛒" }
    ];

    /*
     * Пользовательская шкала зума: 1 (близко) — 6 (далеко).
     * Обычные метки видны на уровнях 1-3.
     * При выборе категории метки этой категории видны на любом зуме.
     */
    var MARKER_VISIBLE_MIN_LEVEL = 1;
    var MARKER_VISIBLE_MAX_LEVEL = 3;

    var map = null;
    var markerSource = null;
    var markerLayer = null;

    var markers = [];

    var highlightCategory = null;

    var addingMode = false;

    var initialized = false;


    /* ========================================================
       API
       ======================================================== */

    async function fetchMarkers() {

        try {

            var response = await fetch(API_BASE + "/api/markers", { credentials: "include", cache: "no-cache" });

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            var data = await response.json();

            return Array.isArray(data) ? data : [];

        } catch (error) {

            console.error(
                "PISPOP-GIS: не удалось загрузить метки:",
                error
            );

            return [];

        }

    }


    async function createMarkerOnServer(marker) {

        var response = await fetch(API_BASE + "/api/markers", {

            method: "POST",

            headers: { "Content-Type": "application/json" },
            credentials: "include",

            body: JSON.stringify(marker)

        });

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }


    async function updateMarkerOnServer(id, patch) {

        var response = await fetch(
            API_BASE + "/api/markers/" + encodeURIComponent(id),
            {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(patch)
            }
        );

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }


    async function deleteMarkerOnServer(id) {

        var response = await fetch(
            API_BASE + "/api/markers/" + encodeURIComponent(id),
            { method: "DELETE", credentials: "include" }
        );

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }


    /* ========================================================
       КАРТА
       ======================================================== */

    function getMap() {

        if (
            window.unmined &&
            window.unmined.map &&
            typeof window.unmined.map.getView === "function"
        ) {
            return window.unmined.map;
        }

        if (
            window.unmined &&
            window.unmined.olMap &&
            typeof window.unmined.olMap.getView === "function"
        ) {
            return window.unmined.olMap;
        }

        if (window.unmined) {

            var keys = Object.keys(window.unmined);

            for (var i = 0; i < keys.length; i++) {

                var value = window.unmined[keys[i]];

                if (
                    value &&
                    typeof value.getView === "function" &&
                    typeof value.addLayer === "function"
                ) {
                    return value;
                }

            }

        }

        return null;

    }


    /* ========================================================
       ПРЕОБРАЗОВАНИЕ КООРДИНАТ
       ======================================================== */

    function toDataCoordinate(viewCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return viewCoordinate;
        }

        return ol.proj.transform(
            viewCoordinate,
            window.unmined.viewProjection,
            window.unmined.dataProjection
        );

    }

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }


    /* ========================================================
       СТИЛЬ МЕТКИ
       ======================================================== */

    function markerStyle(feature) {

        var color = feature.get("color") || "#e63946";
        var title = feature.get("title") || "";
        var iconText = feature.get("icon") || "📍";
        var highlighted = feature.get("highlighted");

        return [

            new ol.style.Style({

                image: new ol.style.Circle({

                    radius: highlighted ? 15 : 12,

                    fill: new ol.style.Fill({ color: color }),

                    stroke: new ol.style.Stroke({
                        color: highlighted ? "#ffd60a" : "#ffffff",
                        width: highlighted ? 3 : 2
                    })

                }),

                text: new ol.style.Text({

                    text: iconText,
                    font: highlighted ? "16px sans-serif" : "13px sans-serif",
                    textAlign: "center",
                    textBaseline: "middle"

                }),

                zIndex: highlighted ? 10 : 0

            }),

            new ol.style.Style({

                text: new ol.style.Text({

                    text: title,

                    font: "600 12px 'Inter', Arial, sans-serif",

                    fill: new ol.style.Fill({ color: "#1f2430" }),

                    stroke: new ol.style.Stroke({
                        color: "rgba(255,255,255,0.85)",
                        width: 3
                    }),

                    offsetY: highlighted ? 23 : 20,
                    textAlign: "center",
                    textBaseline: "top",
                    overflow: true

                }),

                zIndex: highlighted ? 10 : 0

            })

        ];

    }


    /* ========================================================
       ОТРИСОВКА
       ======================================================== */

    function categoryIcon(categoryId) {

        var found = MARKER_CATEGORIES.find(function (c) {
            return c.id === categoryId;
        });

        return found ? found.icon : "📍";

    }

    function renderMarkers() {

        markerSource.clear();

        markers.forEach(function (marker) {

            if (
                typeof marker.x !== "number" ||
                typeof marker.z !== "number"
            ) {
                return;
            }

            var isHighlighted = highlightCategory && marker.category === highlightCategory;

            var feature = new ol.Feature({

                geometry: new ol.geom.Point(
                    toViewCoordinate([marker.x, marker.z])
                ),
                markerId: marker.id,
                title: marker.title,
                description: marker.description,
                address: marker.address,
                category: marker.category,
                color: marker.color,
                icon: categoryIcon(marker.category),
                highlighted: isHighlighted,
                x: marker.x,
                z: marker.z,

                // Данные магазина
                deals: marker.deals || []

            });

            markerSource.addFeature(feature);

        });

        updateVisibilityByZoom();

    }


    /* ========================================================
       ЗАГРУЗКА
       ======================================================== */

    async function reload() {

        markers = await fetchMarkers();

        renderMarkers();

        document.dispatchEvent(
            new CustomEvent("pispop:markers-loaded", {
                detail: markers
            })
        );

    }


    /* ========================================================
       РЕЖИМ ДОБАВЛЕНИЯ
       ======================================================== */

    function setAddingMode(value) {

        addingMode = value;

        document.dispatchEvent(
            new CustomEvent("pispop:marker-adding-mode", {
                detail: addingMode
            })
        );

        if (map) {

            var viewport = map.getViewport();

            if (viewport) {
                viewport.style.cursor = addingMode ? "crosshair" : "";
            }

        }

    }


    function findMarkerById(id) {

        return markers.find(function (marker) {
            return marker.id === id;
        }) || null;

    }


    /* ========================================================
       КЛИК ПО КАРТЕ
       ======================================================== */

    function setupClick() {

        map.on("singleclick", function (event) {

            if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking()) {
                return;
            }

            if (window.PISPOP_RULER && window.PISPOP_RULER.isActive()) {
                return;
            }

            if (addingMode) {

                if (window.PISPOP_RULER && window.PISPOP_RULER.isActive()) {
                    return;
                }

                var coordinate = toDataCoordinate(event.coordinate);

                document.dispatchEvent(
                    new CustomEvent("pispop:marker-create-request", {
                        detail: {
                            x: Math.round(coordinate[0]),
                            z: Math.round(coordinate[1])
                        }
                    })
                );

                setAddingMode(false);

                return;

            }

            var clickedMarker = null;

            map.forEachFeatureAtPixel(

                event.pixel,

                function (feature, layer) {

                    if (layer !== markerLayer) {
                        return false;
                    }

                    var id = feature.get("markerId");

                    if (!id) {
                        return false;
                    }

                    clickedMarker = findMarkerById(id);

                    return true;

                }

            );

            if (clickedMarker) {

                document.dispatchEvent(
                    new CustomEvent("pispop:marker-open-request", {
                        detail: clickedMarker
                    })
                );

            }

        });

    }


    /* ========================================================
       ВИДИМОСТЬ ПО ЗУМУ
       ======================================================== */

    function getMaxZoom() {

        if (!map) {
            return null;
        }

        var view = map.getView();

        if (!view) {
            return null;
        }

        var maxZoom = view.getMaxZoom();

        return (typeof maxZoom === "number" && Number.isFinite(maxZoom))
            ? maxZoom
            : null;

    }


    /* ========================================================
       ВИДИМОСТЬ ПО ЗУМУ С УЧЁТОМ ВЫБРАННОЙ КАТЕГОРИИ
       ======================================================== */

    function updateVisibilityByZoom() {

        if (!map || !markerLayer || !markerSource) {
            return;
        }

        var view = map.getView();

        if (!view) {
            return;
        }

        var zoom = view.getZoom();
        var maxZoom = getMaxZoom();

        if (
            typeof zoom !== "number" ||
            !Number.isFinite(zoom) ||
            typeof maxZoom !== "number"
        ) {
            markerSource.getFeatures().forEach(function (feature) {
                feature.setStyle(new ol.style.Style({}));
            });
            return;
        }

        var userLevel = maxZoom - zoom + 1;
        var isZoomedIn = userLevel >= MARKER_VISIBLE_MIN_LEVEL && 
                           userLevel <= MARKER_VISIBLE_MAX_LEVEL;

        var features = markerSource.getFeatures();

        features.forEach(function (feature) {
            var category = feature.get("category");
            var isHighlighted = highlightCategory && category === highlightCategory;
            
            var shouldShow = isZoomedIn || isHighlighted;

            if (shouldShow) {
                feature.setStyle(null);
            } else {
                feature.setStyle(new ol.style.Style({}));
            }
        });

        markerLayer.changed();

    }


    /* ========================================================
       ИНИЦИАЛИЗАЦИЯ
       ======================================================== */

    async function initialize() {

        if (initialized) {
            return true;
        }

        map = getMap();

        if (!map) {
            return false;
        }

        markerSource = new ol.source.Vector();

        markerLayer = new ol.layer.Vector({
            source: markerSource,
            zIndex: 200000,
            style: markerStyle
        });

        map.addLayer(markerLayer);

        setupClick();

        var view = map.getView();

        if (view) {
            view.on("change:resolution", function() {
                updateVisibilityByZoom();
            });
        }

        document.addEventListener("pispop:category-changed", function (event) {
            highlightCategory = event.detail;
            renderMarkers();
        });

        await reload();

        setTimeout(updateVisibilityByZoom, 100);

        initialized = true;

        console.log("PISPOP-GIS: markers.js подключён.");

        return true;

    }


    var attempts = 0;
    var MAX_ATTEMPTS = 100;

    function waitForMap() {

        attempts++;

        initialize().then(function (ok) {

            if (ok) {
                return;
            }

            if (attempts >= MAX_ATTEMPTS) {
                console.error("PISPOP-GIS: карта не найдена (markers).");
                return;
            }

            setTimeout(waitForMap, 200);

        });

    }


    /* ========================================================
       ПУБЛИЧНЫЙ API
       ======================================================== */

    window.PISPOP_MARKERS = {

        categories: MARKER_CATEGORIES,

        getMarkers: function () {
            return markers;
        },

        isAddingMode: function () {
            return addingMode;
        },

        startAdding: function () {
            setAddingMode(true);
        },

        cancelAdding: function () {
            setAddingMode(false);
        },

        create: async function (marker) {

            var payload = Object.assign(
                { createdAt: new Date().toISOString() },
                marker
            );

            var created = await createMarkerOnServer(payload);

            await reload();

            return created;

        },

        update: async function (id, patch) {

            var payload = Object.assign(
                { updatedAt: new Date().toISOString() },
                patch
            );

            var updated = await updateMarkerOnServer(id, payload);

            await reload();

            return updated;

        },

        remove: async function (id) {

            var result = await deleteMarkerOnServer(id);

            await reload();

            return result;

        },

        refresh: function () {
            return reload();
        },

        setHighlightCategory: function (category) {

            highlightCategory = category;

            document.dispatchEvent(new CustomEvent("pispop:category-changed", {
                detail: category
            }));

            renderMarkers();

        },

        panTo: function (marker) {

            if (!map) {
                return;
            }

            map.getView().animate({
                center: toViewCoordinate([marker.x, marker.z]),
                duration: 300
            });

        }

    };


    waitForMap();

}());