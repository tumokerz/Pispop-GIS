(function(){
  "use strict";
  var user=null, selectedAvatar="👤", avatarData=null;
  function qs(id){return document.getElementById(id);}
  function setAdminVisibility(){document.querySelectorAll(".admin-only").forEach(function(el){el.classList.toggle("hidden",!user||user.role!=="admin");});}
  function avatarFor(u){return (u&&u.avatarData)?u.avatarData:((u&&u.avatar)||"👤");}
  function setAvatar(el,value){if(!el)return;el.innerHTML=""; if(String(value).indexOf("data:image/")===0){var img=document.createElement("img");img.src=value;el.appendChild(img);}else el.textContent=value||"👤";}
  function updateProfile(){setAvatar(qs("profile-avatar"),avatarFor(user));setAvatar(qs("sidebar-profile-avatar"),avatarFor(user));var n=qs("sidebar-profile-name"),b=qs("sidebar-profile-bio");if(n)n.textContent=user?user.username:"Гость";if(b)b.textContent=user?(user.bio||"Расскажите о себе"):"Войдите, чтобы открыть профиль";}
  async function request(path,body){var r=await fetch(path,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify(body||{})});var d={};try{d=await r.json();}catch(e){}if(!r.ok)throw new Error(d.error||("HTTP "+r.status));return d;}
  function open(){qs("auth-modal").classList.remove("hidden");render();}
  function close(){qs("auth-modal").classList.add("hidden");}
  function render(){var status=qs("auth-status"),form=qs("auth-form"),logout=qs("auth-logout");if(user){status.textContent="Вы вошли как "+user.username+(user.role==="admin"?" · администратор":"");form.classList.add("hidden");logout.classList.remove("hidden");}else{status.textContent="Войдите, чтобы получить доступ к инструментам.";form.classList.remove("hidden");logout.classList.add("hidden");}updateProfile();setAdminVisibility();}
  async function me(){try{var r=await fetch("/api/auth/me",{credentials:"same-origin"});var d=await r.json();user=d.user||null;}catch(e){user=null;}render();document.dispatchEvent(new CustomEvent("pispop:auth-changed",{detail:user}));}
  async function login(){try{var d=await request("/api/auth/login",{username:qs("auth-username").value,password:qs("auth-password").value});user=d.user;render();close();document.dispatchEvent(new CustomEvent("pispop:auth-changed",{detail:user}));}catch(e){qs("auth-status").textContent="Ошибка: "+e.message;}}
  async function register(){try{var d=await request("/api/auth/register",{username:qs("auth-username").value,password:qs("auth-password").value,avatar:selectedAvatar,avatarData:avatarData});user=d.user;render();close();document.dispatchEvent(new CustomEvent("pispop:auth-changed",{detail:user}));}catch(e){qs("auth-status").textContent="Ошибка: "+e.message;}}
  async function logout(){await request("/api/auth/logout",{}).catch(function(){});user=null;render();document.dispatchEvent(new CustomEvent("pispop:auth-changed",{detail:null}));}
  async function saveProfile(patch){var d=await request("/api/profile",patch);user=d.user;render();document.dispatchEvent(new CustomEvent("pispop:auth-changed",{detail:user}));}
  function editBio(){if(!user){open();return;}var bio=prompt("Расскажите о себе",user.bio||"");if(bio!==null)saveProfile({bio:bio.slice(0,300)}).catch(function(e){alert("Ошибка: "+e.message);});}
  function openProfilePopover(){
    if(!user){open();return;}
    document.dispatchEvent(new CustomEvent("pispop:profile-open"));
  }
  function closeProfilePopover(){}
  function uploadProfileAvatar(file){
    if(!file)return Promise.resolve(); if(file.type!=="image/png"){alert("Нужен PNG");return Promise.resolve();} if(file.size>4*1024*1024){alert("PNG не должен быть больше 4 МБ");return Promise.resolve();}
    return new Promise(function(resolve,reject){var rd=new FileReader(); rd.onload=function(){saveProfile({avatarData:rd.result,avatar:""}).then(function(){document.dispatchEvent(new CustomEvent("pispop:profile-open"));resolve();}).catch(function(e){alert("Ошибка: "+e.message);reject(e);});}; rd.onerror=reject; rd.readAsDataURL(file);});
  }
  document.addEventListener("DOMContentLoaded",function(){var account=qs("rail-account"),profile=qs("profile-button");if(account)account.addEventListener("click",open);if(profile)profile.addEventListener("click",openProfilePopover);var pc=qs("profile-popover-close");if(pc)pc.addEventListener("click",closeProfilePopover);var pf=qs("profile-avatar-file");if(pf)pf.addEventListener("change",function(){uploadProfileAvatar(pf.files&&pf.files[0]);});
    var sf=qs("sidebar-avatar-file");if(sf)sf.addEventListener("change",function(){uploadProfileAvatar(sf.files&&sf.files[0]).then(function(){document.dispatchEvent(new CustomEvent("pispop:profile-open"));});});var pe=qs("profile-popover-edit");if(pe)pe.addEventListener("click",editBio);if(qs("profile-settings"))qs("profile-settings").addEventListener("click",open);if(qs("profile-edit-bio"))qs("profile-edit-bio").addEventListener("click",editBio);qs("auth-close").addEventListener("click",close);qs("auth-login").addEventListener("click",login);qs("auth-register").addEventListener("click",register);qs("auth-logout").addEventListener("click",logout);document.querySelectorAll("#avatar-picker [data-avatar]").forEach(function(b){b.addEventListener("click",function(){selectedAvatar=b.getAttribute("data-avatar");avatarData=null;document.querySelectorAll("#avatar-picker button").forEach(function(x){x.classList.remove("selected")});b.classList.add("selected");});});var af=qs("avatar-file");if(af)af.addEventListener("change",function(){var f=af.files&&af.files[0];if(!f)return;if(f.type!=="image/png"){alert("Нужен PNG");af.value="";return;}if(f.size>2*1024*1024){alert("PNG не должен быть больше 2 МБ");af.value="";return;}var rd=new FileReader();rd.onload=function(){avatarData=rd.result;selectedAvatar="";document.querySelectorAll("#avatar-picker button").forEach(function(x){x.classList.remove("selected")});};rd.readAsDataURL(f);});me();});
  window.PISPOP_AUTH={getUser:function(){return user;},isAdmin:function(){return !!user&&user.role==="admin";},open:open,saveProfile:saveProfile};
})();
