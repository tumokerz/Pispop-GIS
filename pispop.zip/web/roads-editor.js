/* ============================================================
   PISPOP-GIS
   roads-editor.js
   Редактор дорожной сети
   ============================================================ */

(function () {
    "use strict";

    console.log("[PISPOP-GIS] roads-editor.js loading...");

    /* =========================================================
       НАСТРОЙКИ
       ========================================================= */

    const ROADS_FILE = "roads.json";

    const DEFAULT_ROAD_TYPE = "ice";

    const DEFAULT_ROAD_NAME = "Ледяная дорога";

    const DEFAULT_ROAD_COLOR = "#8cbbd9";
    const ROAD_TYPES = {
        ice: { name: "Ледяная дорога", color: "#8cbbd9", routing: true },
        rail: { name: "Железная дорога", color: "#6b7280", routing: false },
        metro: { name: "Метро", color: "#b04cff", routing: false }
    };

    /* =========================================================
       СОСТОЯНИЕ
       ========================================================= */

    let roadsData = {
        version: 1,
        project: "PISPOP-GIS",
        description: "Ручная разметка дорожной сети",

        roadTypes: ROAD_TYPES,

        roads: []
    };

    let roadsLoaded = false;

    let roadEditorEnabled = false;

    let drawingRoad = false;
    let currentRoadType = "ice";

    let currentRoadCoordinates = [];

    let selectedRoad = null;

    let map = null;

    let roadVectorSource = null;

    let roadVectorLayer = null;

    let drawingVectorSource = null;

    let drawingVectorLayer = null;

    let clickHandler = null;

    /* =========================================================
       ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
       ========================================================= */

    function log() {
        console.log.apply(console, [
            "[PISPOP-GIS][ROADS]"
        ].concat(Array.from(arguments)));
    }

    function warn() {
        console.warn.apply(console, [
            "[PISPOP-GIS][ROADS]"
        ].concat(Array.from(arguments)));
    }

    function showToast(text, type) {

        if (typeof Toastify === "function") {

            Toastify({
                text: text,
                duration: 2500,
                gravity: "bottom",
                position: "center",
                close: true,
                style: {
                    background:
                        type === "error"
                            ? "#c62828"
                            : type === "success"
                                ? "#2e7d32"
                                : "#333"
                }
            }).showToast();

        } else {

            console.log(text);

        }
    }

    function generateId() {

        return (
            "ice-" +
            Date.now().toString(36) +
            "-" +
            Math.random()
                .toString(36)
                .substring(2, 8)
        );

    }

    /* =========================================================
       ПОИСК КАРТЫ OPENLAYERS
       ========================================================= */

    function findMap() {

        if (map) {
            return map;
        }

        /*
         * Вариант 1.
         * Иногда карта доступна через window.map.
         */

        if (
            typeof window.map !== "undefined" &&
            window.map &&
            typeof window.map.getView === "function"
        ) {

            map = window.map;

            log("Map found: window.map");

            return map;

        }

        /*
         * Вариант 2.
         * Некоторые версии uNmINeD хранят OpenLayers Map
         * внутри объекта unmined.
         */

        if (
            typeof window.unmined !== "undefined" &&
            window.unmined
        ) {

            const candidates = [
                window.unmined.map,
                window.unmined.olMap,
                window.unmined._map,
                window.unmined.mapObject
            ];

            for (const candidate of candidates) {

                if (
                    candidate &&
                    typeof candidate.getView === "function"
                ) {

                    map = candidate;

                    log("Map found inside window.unmined");

                    return map;

                }

            }

        }

        /*
         * Вариант 3.
         * Поиск объекта OpenLayers среди глобальных переменных.
         */

        for (const key of Object.keys(window)) {

            try {

                const value = window[key];

                if (
                    value &&
                    typeof value === "object" &&
                    typeof value.getView === "function" &&
                    typeof value.getLayers === "function"
                ) {

                    map = value;

                    log(
                        "Map automatically found in window." +
                        key
                    );

                    return map;

                }

            } catch (e) {
                // Некоторые window-свойства нельзя читать.
            }

        }

        return null;
    }

    /* =========================================================
       ПРЕОБРАЗОВАНИЕ КООРДИНАТ
       ========================================================= */

    /*
     * Карта unmined.js хранит геометрию в собственной
     * "view"-проекции (кастомная нелинейная система с инверсией
     * оси Z), а реальные координаты мира Minecraft (X, Z) —
     * в отдельной "data"-проекции. Все точки, полученные с карты
     * (event.coordinate) или отправляемые на карту, обязаны
     * проходить через ol.proj.transform, иначе X/Z будут неверными.
     */

    function toDataCoordinate(viewCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return viewCoordinate;
        }

        return ol.proj.transform(
            viewCoordinate,
            window.unmined.viewProjection,
            window.unmined.dataProjection
        );

    }

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }

    /* =========================================================
       ЗАГРУЗКА roads.json
       ========================================================= */

    async function loadRoads() {

        log("Loading roads from server: /api/roads");

        try {

            const response = await fetch(
                "/api/roads",
                {
                    cache: "no-cache"
                }
            );

            if (!response.ok) {

                throw new Error(
                    "HTTP " +
                    response.status +
                    " при загрузке /api/roads"
                );

            }

            const json = await response.json();

            if (!json || typeof json !== "object") {

                throw new Error(
                    "/api/roads вернул неправильный JSON."
                );

            }

            if (!Array.isArray(json.roads)) {

                json.roads = [];

            }

            roadsData = json;

            roadsLoaded = true;

            log(
                "Loaded roads:",
                roadsData.roads.length
            );

            return true;

        } catch (error) {

            roadsLoaded = false;

            console.error(
                "[PISPOP-GIS][ROADS] Cannot load /api/roads:",
                error
            );

            showToast(
                "Не удалось загрузить дороги с сервера",
                "error"
            );

            return false;
        }
    }

    /* =========================================================
       СОЗДАНИЕ OPENLAYERS СЛОЁВ
       ========================================================= */

    function createLayers() {

        if (!map) {

            warn("Map not found. Layers cannot be created.");

            return false;
        }

        if (
            typeof ol === "undefined" ||
            !ol.source ||
            !ol.layer ||
            !ol.format
        ) {

            warn(
                "OpenLayers API is unavailable."
            );

            return false;
        }

        /*
         * Основной источник дорог.
         */

        roadVectorSource =
            new ol.source.Vector();

        /*
         * Основной слой дорог.
         */

        roadVectorLayer =
            new ol.layer.Vector({
                source: roadVectorSource,

                zIndex: 1000,

                visible: true
            });

        map.addLayer(roadVectorLayer);

        /*
         * Источник текущей редактируемой дороги.
         */

        drawingVectorSource =
            new ol.source.Vector();

        drawingVectorLayer =
            new ol.layer.Vector({
                source: drawingVectorSource,

                zIndex: 2000,

                visible: true
            });

        map.addLayer(drawingVectorLayer);

        log("Road layers created.");

        return true;
    }

    /* =========================================================
       СТИЛЬ ДОРОГИ
       ========================================================= */

    function getRoadStyle(road) {

        const color =
            (roadsData.roadTypes && roadsData.roadTypes[road.type] && roadsData.roadTypes[road.type].color) ||
            road.color ||
            (
                roadsData.roadTypes &&
                roadsData.roadTypes[road.type] &&
                roadsData.roadTypes[road.type].color
            ) ||
            DEFAULT_ROAD_COLOR;

        return new ol.style.Style({

            stroke: new ol.style.Stroke({
                color: color,
                width: road.type === "metro" ? 5 : (road.type === "rail" ? 4 : 6),
                lineCap: "round",
                lineJoin: "round",
                lineDash: road.type === "metro" ? [12, 8] : (road.type === "rail" ? [10, 6] : undefined)
            })

        });
    }

    function getSelectedRoadStyle(road) {

        const SELECTED_ROAD_COLOR = "#ffd60a";

        return new ol.style.Style({

            stroke: new ol.style.Stroke({

                color: SELECTED_ROAD_COLOR,

                width: 10,

                lineCap: "round",

                lineJoin: "round"

            })

        });
    }

    function getDrawingStyle() {

        return new ol.style.Style({

            stroke: new ol.style.Stroke({

                color: ROAD_TYPES[currentRoadType]?.color || DEFAULT_ROAD_COLOR,

                width: 7,

                lineCap: "round",

                lineJoin: "round",

                lineDash: [
                    12,
                    8
                ]

            }),

            image: new ol.style.Circle({

                radius: 5,

                fill: new ol.style.Fill({
                    color: DEFAULT_ROAD_COLOR
                }),

                stroke: new ol.style.Stroke({
                    color: "#ffffff",
                    width: 2
                })

            })

        });
    }

    /* =========================================================
       ПРЕОБРАЗОВАНИЕ ДОРОГИ В FEATURE
       ========================================================= */

    function roadToFeature(road) {

        if (!road) {
            return null;
        }

        /*
         * Дорога хранится как набор сегментов (MultiLineString).
         * Старый формат (одна запись = один путь через
         * road.coordinates) тоже поддерживается для совместимости.
         */

        const segments =
            Array.isArray(road.segments) && road.segments.length > 0
                ? road.segments
                : (Array.isArray(road.coordinates) ? [road.coordinates] : []);

        const validSegments =
            segments.filter(function (segment) {
                return Array.isArray(segment) && segment.length >= 2;
            });

        if (validSegments.length === 0) {
            return null;
        }

        try {

            /*
             * roads.json хранит координаты в Minecraft X/Z
             * (data-проекция), поэтому перед отрисовкой на карте
             * их нужно перевести в view-проекцию.
             */

            const geometry =
                new ol.geom.MultiLineString(
                    validSegments.map(function (segment) {
                        return segment.map(toViewCoordinate);
                    })
                );

            const feature =
                new ol.Feature({
                    geometry: geometry
                });

            feature.setId(road.id);

            feature.set(
                "pispopRoad",
                road
            );

            feature.set(
                "roadId",
                road.id
            );

            feature.setStyle(
                getRoadStyle(road)
            );

            return feature;

        } catch (error) {

            console.error(
                "Road conversion error:",
                road,
                error
            );

            return null;
        }
    }

    /* =========================================================
       ОТРИСОВКА ВСЕХ ДОРОГ
       ========================================================= */

    function renderRoads() {

        if (!roadVectorSource) {

            warn(
                "Road source does not exist."
            );

            return;
        }

        roadVectorSource.clear();

        if (!Array.isArray(roadsData.roads)) {

            return;
        }

        for (const road of roadsData.roads) {

            const feature =
                roadToFeature(road);

            if (feature) {

                roadVectorSource.addFeature(
                    feature
                );

            }

        }

        log(
            "Rendered roads:",
            roadsData.roads.length
        );

        updateRoadEditorInfo();
    }

    /* =========================================================
       ОБНОВЛЕНИЕ ТЕКУЩЕГО РИСОВАНИЯ
       ========================================================= */

    function renderCurrentDrawing() {

        if (!drawingVectorSource) {
            return;
        }

        drawingVectorSource.clear();

        if (
            !currentRoadCoordinates ||
            currentRoadCoordinates.length === 0
        ) {

            return;
        }

        /*
         * Точки.
         */

        for (
            let i = 0;
            i < currentRoadCoordinates.length;
            i++
        ) {

            const point =
                new ol.Feature({
                    geometry:
                        new ol.geom.Point(
                            toViewCoordinate(currentRoadCoordinates[i])
                        )
                });

            point.setStyle(
                new ol.style.Style({

                    image:
                        new ol.style.Circle({

                            radius: 6,

                            fill:
                                new ol.style.Fill({
                                    color:
                                        DEFAULT_ROAD_COLOR
                                }),

                            stroke:
                                new ol.style.Stroke({
                                    color: "#ffffff",
                                    width: 2
                                })

                        })

                })
            );

            drawingVectorSource.addFeature(
                point
            );
        }

        /*
         * Линия.
         */

        if (
            currentRoadCoordinates.length >= 2
        ) {

            const line =
                new ol.Feature({

                    geometry:
                        new ol.geom.LineString(
                            currentRoadCoordinates.map(toViewCoordinate)
                        )

                });

            line.setStyle(
                getDrawingStyle()
            );

            drawingVectorSource.addFeature(
                line
            );
        }
    }

    /* =========================================================
       ПЕРЕКЛЮЧЕНИЕ РЕДАКТОРА
       ========================================================= */

    function toggleRoadEditor() {

        roadEditorEnabled = !roadEditorEnabled;

        if (roadEditorEnabled) {

            enableRoadEditor();

        } else {

            disableRoadEditor();

        }
    }

    function enableRoadEditor() {

        roadEditorEnabled = true;

        const button = document.getElementById("tool-roads");

        if (button) {

            button.classList.add("active");
            // Меняем текст на кнопке, чтобы было понятно, что это выход
            button.textContent = "🚧 Выйти из редактора дорог";

        }

        // Показываем слой дорог
        if (roadVectorLayer) {
            roadVectorLayer.setVisible(true);
        }

        // Показываем дополнительную кнопку "Нарисовать дорогу"
        const startBtn = document.getElementById("tool-start-road");
        if (startBtn) {
            startBtn.classList.remove("hidden");
        }

        // Скрываем кнопку добавления дома (она не нужна для ледяных дорог)
        const addHouseBtn = document.getElementById("tool-add-house");
        if (addHouseBtn) {
            addHouseBtn.classList.add("hidden");
        }

        showToast("Редактор дорог включён", "success");
        updateRoadEditorInfo();

        log("Road editor ENABLED.");
    }

    function disableRoadEditor() {

        roadEditorEnabled = false;

        // Останавливаем рисование, если оно активно
        stopDrawing();

        const button = document.getElementById("tool-roads");

        if (button) {

            button.classList.remove("active");
            button.textContent = "🚧 Редактор дорог";

        }

        // Скрываем кнопку "Нарисовать дорогу"
        const startBtn = document.getElementById("tool-start-road");
        if (startBtn) {
            startBtn.classList.add("hidden");
        }

        // Показываем кнопку добавления дома обратно
        const addHouseBtn = document.getElementById("tool-add-house");
        if (addHouseBtn) {
            addHouseBtn.classList.remove("hidden");
        }

        // Скрываем подсказку, если она есть
        removeDrawingHint();

        showToast("Редактор дорог выключен");
        updateRoadEditorInfo();

        log("Road editor DISABLED.");
    }

    /* =========================================================
       НАЧАТЬ РИСОВАНИЕ
       ========================================================= */

    function startDrawing() {

        if (!roadEditorEnabled) {
            enableRoadEditor();
        }

        if (!map) {
            map = findMap();
        }

        if (!map) {
            showToast("Карта OpenLayers не найдена", "error");
            console.error("[PISPOP-GIS] Не найден объект карты.");
            return;
        }

        stopDrawing();

        drawingRoad = true;
        currentRoadCoordinates = [];

        // Меняем курсор на крестик
        map.getViewport().style.cursor = "crosshair";

        renderCurrentDrawing();

        showToast("Кликайте по карте, чтобы строить дорогу");

        createDrawingHint();

        clickHandler = function (event) {
            if (!drawingRoad) return;

            const coordinate = toDataCoordinate(event.coordinate);
            if (!coordinate || coordinate.length < 2) return;

            currentRoadCoordinates.push([
                Math.round(coordinate[0]),
                Math.round(coordinate[1])
            ]);

            renderCurrentDrawing();
            updateRoadEditorInfo();

            log("Road point:", coordinate);
        };

        map.on("click", clickHandler);

        log("Drawing started.");
    }

    /* =========================================================
       ОСТАНОВИТЬ РИСОВАНИЕ
       ========================================================= */

      function stopDrawing() {

        drawingRoad = false;

        if (map && clickHandler) {
            try {
                map.un("click", clickHandler);
            } catch (error) {
                console.warn(error);
            }
        }

        clickHandler = null;

        // Удаляем подсказку
        removeDrawingHint();

        renderCurrentDrawing();

        // Возвращаем курсор
        if (map) {
            map.getViewport().style.cursor = "";
        }
    }

    /* =========================================================
       ЗАВЕРШИТЬ ДОРОГУ
       ========================================================= */

    function finishDrawing() {

        if (
            !currentRoadCoordinates ||
            currentRoadCoordinates.length < 2
        ) {

            showToast(
                "Нужно поставить минимум 2 точки",
                "error"
            );

            return;
        }

        const newSegment =
            currentRoadCoordinates.map(
                function (point) {
                    return [
                        point[0],
                        point[1]
                    ];
                }
            );

        /*
         * Вся дорожная сеть — это ОДНА дорога.
         * Каждая новая нарисованная линия добавляется как
         * очередной сегмент к единственной существующей записи,
         * а не создаёт отдельный объект в roadsData.roads.
         */

        let road = roadsData.roads.find(function (r) { return r.type === currentRoadType; });

        if (!road) {

            road = {

                id: generateId(),

                type: currentRoadType,

                name: ROAD_TYPES[currentRoadType]?.name || DEFAULT_ROAD_NAME,

                color: DEFAULT_ROAD_COLOR,

                status: "confirmed",

                segments: []

            };

            roadsData.roads.push(road);

        }

        if (!Array.isArray(road.segments)) {

            /*
             * Совместимость со старым форматом (одна дорога
             * с полем coordinates вместо segments).
             */

            road.segments =
                Array.isArray(road.coordinates) &&
                road.coordinates.length >= 2
                    ? [road.coordinates]
                    : [];

            delete road.coordinates;

        }

        road.segments.push(newSegment);

        log(
            "Segment added to the single road:",
            newSegment,
            "total segments:",
            road.segments.length
        );

        stopDrawing();

        currentRoadCoordinates = [];

        renderCurrentDrawing();

        renderRoads();

        selectRoad(road.id);

        showToast(
            "Сегмент дороги добавлен",
            "success"
        );

        /*
         * Автосохранение на сервер — видно всем,
         * кто открывает карту.
         */

        saveRoadsToServer();
    }

    /* =========================================================
       ОТМЕНА РИСОВАНИЯ
       ========================================================= */

    function cancelDrawing() {

        stopDrawing();

        currentRoadCoordinates = [];

        renderCurrentDrawing();

        showToast(
            "Рисование отменено"
        );

        updateRoadEditorInfo();
    }

    /* =========================================================
       ПОДСКАЗКА
       ========================================================= */

    function createDrawingHint() {

        let hint =
            document.getElementById(
                "roads-editor-hint"
            );

        if (hint) {
            return;
        }

        hint =
            document.createElement(
                "div"
            );

        hint.id =
            "roads-editor-hint";

        hint.innerHTML =
            "<strong>🚧 Редактор дорог</strong>" +
            "<br>" +
            "Кликайте по карте для добавления точек." +
            "<br>" +
            "<span>Двойной клик — завершить дорогу.</span>" +
            "<br>" +
            "Тип: <select id=\"roads-type-select\"><option value=\"ice\">❄ Ледяная</option><option value=\"rail\">🚆 Железная</option><option value=\"metro\">🚇 Метро</option></select>" +
            "<br><br>" +
            "<button id=\"roads-finish-btn\">Готово</button> " +
            "<button id=\"roads-cancel-btn\">Отмена</button>";

        document.body.appendChild(
            hint
        );

        /*
         * Минимальное встроенное оформление.
         * Чтобы работало даже без CSS.
         */

        hint.style.position =
            "fixed";

        hint.style.left =
            "50%";

        hint.style.bottom =
            "25px";

        hint.style.transform =
            "translateX(-50%)";

        hint.style.zIndex =
            "99999";

        hint.style.padding =
            "12px 16px";

        hint.style.borderRadius =
            "10px";

        hint.style.background =
            "rgba(25,25,25,.95)";

        hint.style.color =
            "#fff";

        hint.style.fontFamily =
            "Arial,sans-serif";

        hint.style.fontSize =
            "14px";

        hint.style.boxShadow =
            "0 5px 25px rgba(0,0,0,.35)";

        const finish =
            document.getElementById(
                "roads-finish-btn"
            );

        const typeSelect = document.getElementById("roads-type-select");
        if (typeSelect) {
            typeSelect.value = currentRoadType;
            typeSelect.addEventListener("change", function(){ currentRoadType = this.value; });
        }

        const cancel =
            document.getElementById(
                "roads-cancel-btn"
            );

        if (finish) {

            finish.addEventListener(
                "click",
                finishDrawing
            );

        }

        if (cancel) {

            cancel.addEventListener(
                "click",
                cancelDrawing
            );

        }
    }

    function removeDrawingHint() {

        const hint =
            document.getElementById(
                "roads-editor-hint"
            );

        if (hint) {

            hint.remove();

        }
    }

    /* =========================================================
       ДВОЙНОЙ КЛИК — ЗАВЕРШЕНИЕ ДОРОГИ
       ========================================================= */

    function installDoubleClickHandler() {

        if (!map) {
            return;
        }

        map.on(
            "dblclick",
            function (event) {

                if (!drawingRoad) {
                    return;
                }

                /*
                 * Не даём OpenLayers
                 * дополнительно обрабатывать
                 * двойной клик.
                 */

                if (
                    event &&
                    typeof event.preventDefault ===
                    "function"
                ) {

                    event.preventDefault();

                }

                finishDrawing();

            }
        );
    }

    /* =========================================================
       ВЫБОР ДОРОГИ
       ========================================================= */

    function installRoadSelection() {

        if (!map) {
            return;
        }

        map.on(
            "singleclick",
            function (event) {

                if (
                    drawingRoad
                ) {

                    return;
                }

                if (
                    !roadVectorLayer ||
                    !roadVectorSource
                ) {

                    return;
                }

                const feature =
                    map.forEachFeatureAtPixel(
                        event.pixel,
                        function (
                            feature,
                            layer
                        ) {

                            if (
                                layer ===
                                roadVectorLayer
                            ) {

                                return feature;

                            }

                            return null;

                        }
                    );

                if (!feature) {

                    if (selectedRoad) {

                        selectedRoad = null;

                        renderRoads();

                    }

                    hideRoadCard();

                    return;
                }

                const road =
                    feature.get(
                        "pispopRoad"
                    );

                if (!road) {
                    return;
                }

                selectRoad(
                    road.id
                );
            }
        );
    }

    function selectRoad(id) {

        const road =
            roadsData.roads.find(
                function (item) {
                    return item.id === id;
                }
            );

        if (!road) {
            return;
        }

        selectedRoad = road;

        // ======== ДОБАВИТЬ ЭТУ СТРОКУ ========
        if (window.PISPOP_ROADS && window.PISPOP_ROADS._setSelectedRoad) {
            window.PISPOP_ROADS._setSelectedRoad(road);
        }
        // =====================================

        /*
         * Обновляем стили.
         */

        roadVectorSource
            .getFeatures()
            .forEach(
                function (feature) {

                    const featureRoad =
                        feature.get(
                            "pispopRoad"
                        );

                    if (
                        featureRoad &&
                        featureRoad.id ===
                        road.id
                    ) {

                        feature.setStyle(
                            getSelectedRoadStyle(
                                road
                            )
                        );

                    } else if (
                        featureRoad
                    ) {

                        feature.setStyle(
                            getRoadStyle(
                                featureRoad
                            )
                        );

                    }

                }
            );

        showRoadCard(
            road
        );

        log(
            "Selected road:",
            road.id
        );
    }

    /* =========================================================
       КАРТОЧКА ДОРОГИ
       ========================================================= */

    function showRoadCard(road) {
        // Карточки дорожной сети пользователю не показываем.
        // Дорога остаётся интерактивной для редактора, но не создаёт
        // отдельное окно в правом/нижнем углу.
        return;
    }

    function hideRoadCard() {

        const card =
            document.getElementById(
                "roads-object-card"
            );

        if (card) {

            card.style.display =
                "none";

        }
    }

    function escapeHtml(value) {

        return String(value)
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );

    }

    /* =========================================================
       УДАЛЕНИЕ ДОРОГИ
       ========================================================= */

    function deleteSelectedRoad() {

        if (!selectedRoad) {

            showToast(
                "Сначала выберите дорогу",
                "error"
            );

            return;
        }

        const roadName =
            selectedRoad.name ||
            DEFAULT_ROAD_NAME;

        const confirmed =
            window.confirm(
                "Удалить дорогу «" +
                roadName +
                "»?"
            );

        if (!confirmed) {

            return;
        }

        const id =
            selectedRoad.id;

        roadsData.roads =
            roadsData.roads.filter(
                function (road) {
                    return road.id !== id;
                }
            );

        selectedRoad = null;

        hideRoadCard();

        renderRoads();

        showToast(
            "Дорога удалена",
            "success"
        );

        saveRoadsToServer(true);

        log(
            "Road deleted:",
            id
        );
    }

    /* =========================================================
       СОХРАНЕНИЕ НА СЕРВЕР (/api/roads)
       ========================================================= */

    let saveRoadsTimer = null;

    function saveRoadsToServer(immediate) {

        if (saveRoadsTimer) {
            clearTimeout(saveRoadsTimer);
            saveRoadsTimer = null;
        }

        const doSave = async function () {

            try {

                const response = await fetch("/api/roads", {

                    method: "PUT",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify(roadsData)

                });

                if (!response.ok) {
                    throw new Error("HTTP " + response.status);
                }

                log("Roads saved to server.");

            } catch (error) {

                console.error(
                    "[PISPOP-GIS][ROADS] Cannot save to /api/roads:",
                    error
                );

                showToast(
                    "Не удалось сохранить дороги на сервере",
                    "error"
                );

            }

        };

        if (immediate) {
            doSave();
        } else {
            saveRoadsTimer = setTimeout(doSave, 600);
        }

    }

    /* =========================================================
       СОХРАНЕНИЕ roads.json (локальный экспорт в файл)
       ========================================================= */

    function saveRoadsToFile() {

        try {

            const json =
                JSON.stringify(
                    roadsData,
                    null,
                    2
                );

            const blob =
                new Blob(
                    [json],
                    {
                        type:
                            "application/json;charset=utf-8"
                    }
                );

            const url =
                URL.createObjectURL(
                    blob
                );

            const a =
                document.createElement(
                    "a"
                );

            a.href = url;

            a.download =
                "roads.json";

            document.body.appendChild(
                a
            );

            a.click();

            a.remove();

            setTimeout(
                function () {

                    URL.revokeObjectURL(
                        url
                    );

                },
                1000
            );

            log(
                "roads.json generated."
            );

        } catch (error) {

            console.error(
                "Cannot save roads.json:",
                error
            );

            showToast(
                "Ошибка сохранения roads.json",
                "error"
            );
        }
    }

    /* =========================================================
       ПЕРЕКЛЮЧАТЕЛЬ СЛОЯ ДОРОГ
       ========================================================= */

    function installRoadLayerToggle() {

        const checkbox =
            document.getElementById(
                "layer-roads"
            );

        if (!checkbox) {
            // Слои сейчас намеренно убраны из интерфейса.
            // Отсутствие переключателя не является ошибкой и не должно
            // засорять консоль предупреждением. Сам редактор дорог при этом работает.
            return;
        }

        checkbox.addEventListener(
            "change",
            function () {

                if (
                    roadVectorLayer
                ) {

                    roadVectorLayer.setVisible(
                        checkbox.checked
                    );

                }

            }
        );
    }

    /* =========================================================
       КНОПКА РЕДАКТОРА ДОРОГ
       ========================================================= */

        /* =========================================================
       КНОПКА РЕДАКТОРА ДОРОГ
       ========================================================= */

    function installRoadEditorButton() {

        const button = document.getElementById("tool-roads");

        if (!button) {

            console.error(
                "[PISPOP-GIS] Кнопка #tool-roads не найдена!"
            );

            return;
        }

        // Удаляем старые обработчики через cloneNode
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);

        newButton.addEventListener("click", function (event) {

            event.preventDefault();
            event.stopPropagation();

            toggleRoadEditor();

        });

        log("#tool-roads connected.");

        // Если редактор включён по умолчанию - обновляем UI
        if (roadEditorEnabled) {
            enableRoadEditor();
        }

    }

    /* =========================================================
       КНОПКА ДОБАВЛЕНИЯ ДОРОГИ
       ========================================================= */

    /* =========================================================
       КНОПКА ДОБАВЛЕНИЯ ДОРОГИ (появляется в режиме редактора)
       ========================================================= */

    function installExtraRoadButton() {

        const startRoadBtn = document.getElementById("tool-start-road");
        
        if (!startRoadBtn) {
            console.warn("[PISPOP-GIS] #tool-start-road not found");
            return;
        }

        // Удаляем старые обработчики
        const newBtn = startRoadBtn.cloneNode(true);
        startRoadBtn.parentNode.replaceChild(newBtn, startRoadBtn);

        newBtn.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();
            
            log("Start road button clicked");
            
            if (drawingRoad) {
                // Если уже рисуем - завершаем
                finishDrawing();
            } else {
                // Иначе начинаем рисование
                startDrawing();
            }
        });

        // Если редактор уже включён - показываем кнопку
        if (roadEditorEnabled) {
            newBtn.classList.remove("hidden");
        } else {
            newBtn.classList.add("hidden");
        }

        log("#tool-start-road connected.");
    }

    /* =========================================================
       INFO
       ========================================================= */

    function updateRoadEditorInfo() {

        let info =
            document.getElementById(
                "roads-editor-info"
            );

        if (!info) {

            info =
                document.createElement(
                    "div"
                );

            info.id =
                "roads-editor-info";

            info.style.position =
                "fixed";

            info.style.left =
                "15px";

            info.style.bottom =
                "15px";

            info.style.zIndex =
                "9990";

            info.style.padding =
                "7px 10px";

            info.style.borderRadius =
                "8px";

            info.style.background =
                "rgba(0,0,0,.7)";

            info.style.color =
                "#fff";

            info.style.fontFamily =
                "Arial,sans-serif";

            info.style.fontSize =
                "12px";

            document.body.appendChild(
                info
            );
        }

        const count =
            Array.isArray(roadsData.roads)
                ? roadsData.roads.length
                : 0;

        if (drawingRoad) {

            info.textContent =
                "🚧 Точек: " +
                currentRoadCoordinates.length +
                " | Дорог: " +
                count;

        } else {

            info.textContent =
                "🚧 Дорог: " +
                count;

        }
    }

    /* =========================================================
       ИНИЦИАЛИЗАЦИЯ
       ========================================================= */

    async function initRoadEditor() {

        log(
            "Initializing road editor..."
        );

        /*
         * Ждём uNmINeD.
         */

        let attempts = 0;

        while (
            !map &&
            attempts < 100
        ) {

            map = findMap();

            if (map) {
                break;
            }

            await new Promise(
                function (resolve) {

                    setTimeout(
                        resolve,
                        100
                    );

                }
            );

            attempts++;
        }

        if (!map) {

            console.error(
                "[PISPOP-GIS] OpenLayers map was not found after waiting."
            );

            showToast(
                "Редактор дорог: карта не найдена",
                "error"
            );

            /*
             * Всё равно подключаем кнопки,
             * чтобы интерфейс не был мёртвым.
             */

            installRoadEditorButton();

            installRoadLayerToggle();

            return;
        }

        log(
            "OpenLayers map found."
        );

        /*
         * Создаём слои.
         */

        if (!createLayers()) {

            return;

        }

        /*
         * Загружаем дороги.
         */

        await loadRoads();

        /*
         * Рисуем дороги.
         */

        renderRoads();

        /*
         * События.
         */

        installRoadEditorButton();

        installExtraRoadButton();

        installRoadLayerToggle();

        installRoadSelection();

        installDoubleClickHandler();

        updateRoadEditorInfo();

        log(
            "Road editor initialized successfully."
        );

        showToast(
            "Дорожная сеть готова"
        );
    }

    /* =========================================================
       CSS
       ========================================================= */

    function installStyles() {

        if (
            document.getElementById(
                "pispop-roads-editor-style"
            )
        ) {

            return;
        }

        const style =
            document.createElement(
                "style"
            );

        style.id =
            "pispop-roads-editor-style";

        style.textContent = `

            #tool-roads.active {
                background: #8cbbd9 !important;
                color: #10202b !important;
                font-weight: 700;
            }

            #roads-editor-hint button {
                border: 0;
                border-radius: 6px;
                padding: 7px 12px;
                cursor: pointer;
                margin-right: 4px;
            }

            #roads-finish-btn {
                background: #8cbbd9;
                color: #10202b;
            }

            #roads-cancel-btn {
                background: #555;
                color: #fff;
            }

            #roads-object-card input {
                box-sizing: border-box;
                width: 100%;
                margin-top: 5px;
                margin-bottom: 10px;
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 6px;
            }

            #roads-card-close {
                float: right;
                border: 0;
                background: transparent;
                cursor: pointer;
                font-size: 18px;
            }

            .roads-card-title {
                font-size: 16px;
                font-weight: 700;
                margin-bottom: 12px;
            }

            #roads-card-info {
                font-size: 12px;
                line-height: 1.6;
                margin-bottom: 12px;
                word-break: break-word;
            }

            #roads-card-delete {
                width: 100%;
                border: 0;
                border-radius: 7px;
                padding: 9px;
                background: #d32f2f;
                color: #fff;
                cursor: pointer;
            }

        `;

        document.head.appendChild(
            style
        );
    }

    /* =========================================================
       ЗАПУСК
       ========================================================= */

    function boot() {

        installStyles();

        /*
         * Делаем запуск после полной загрузки страницы.
         */

        initRoadEditor();

    }

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            boot
        );

    } else {

        boot();

    }

        /* =========================================================
       ПУБЛИЧНЫЙ API
       ========================================================= */

    // Создаём объект для хранения состояния, доступного снаружи
    const publicState = {
        _selectedRoad: null,
        
        getSelectedRoad: function () {
            return this._selectedRoad;
        },
        
        setSelectedRoad: function (road) {
            this._selectedRoad = road;
        }
    };

    window.PISPOP_ROADS = {

        getData:
            function () {
                return roadsData;
            },

        reload:
            async function () {

                await loadRoads();

                renderRoads();

            },

        startDrawing:
            startDrawing,

        finishDrawing:
            finishDrawing,

        cancelDrawing:
            cancelDrawing,

        isDrawing:
            function () {
                return drawingRoad;
            },

        toggle:
            toggleRoadEditor,

        save:
            saveRoadsToServer,

        exportFile:
            saveRoadsToFile,

        render:
            renderRoads,

        /* ======== НОВЫЙ МЕТОД ======== */
        getSelectedRoad: function () {
            return publicState.getSelectedRoad();
        },
        /* ============================= */

        // Для внутреннего использования (чтобы обновлять selectedRoad)
        _setSelectedRoad: function (road) {
            publicState.setSelectedRoad(road);
        }
    };

    /* =========================================================
       ВЫБОР ДОРОГИ (улицы) - дополнительный клик для адресации
       ========================================================= */

    // Переопределяем выбор дороги для поддержки улиц
    const originalInstallRoadSelection = installRoadSelection;
    installRoadSelection = function() {
        if (!map) return;

        map.on("singleclick", function (event) {
            if (drawingRoad) return;
            if (!roadVectorLayer || !roadVectorSource) return;
            if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking()) return;

            // Дом лежит поверх дороги/улицы - клик по дому не должен
            // переключать выбор дороги.
            if (window.PISPOP_ADDRESS && window.PISPOP_ADDRESS.hasHouseAtPixel(event.pixel)) {
                return;
            }

            const feature = map.forEachFeatureAtPixel(event.pixel, function (feature, layer) {
                if (layer === roadVectorLayer) {
                    return feature;
                }
                return null;
            });

            // Когда дорога снимается с выбора (в обработчике singleclick)
            if (!feature) {
            if (selectedRoad) {
                selectedRoad = null;
            if (window.PISPOP_ROADS && window.PISPOP_ROADS._setSelectedRoad) {
                window.PISPOP_ROADS._setSelectedRoad(null);
        }
        // =====================================
        
        renderRoads();
        document.dispatchEvent(new CustomEvent("pispop:road-deselected"));
    }
    hideRoadCard();
    return;
}

            const road = feature.get("pispopRoad");
            if (!road) return;

            selectRoad(road.id);
            
            // Отправляем событие о выборе дороги для адресной системы
            document.dispatchEvent(new CustomEvent("pispop:road-selected", {
                detail: road
            }));
        });
    };

    // Вызываем обновлённую функцию
    if (map) {
        // Удаляем старый обработчик, если был
        map.un("singleclick", originalInstallRoadSelection);
        installRoadSelection();
    }

})();