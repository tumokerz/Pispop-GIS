console.log("PISPOP-GIS: app.js загружен");

const map = L.map("map", {
    crs: L.CRS.Simple,
    minZoom: -5,
    maxZoom: 5,
    zoomControl: true,
    attributionControl: false
});

console.log("PISPOP-GIS: Leaflet карта создана");

const PapyrusLayer = L.GridLayer.extend({

    createTile: function(coords, done) {

        const tile = document.createElement("img");

        tile.width = 256;
        tile.height = 256;

        const x = coords.x;
        const y = coords.y;

        const url =
            `/map/dim0/20/${x}/${y}.png`;

        console.log("Загрузка тайла:", url);

        tile.src = url;

        tile.onload = function() {
            console.log("Тайл загружен:", url);
            done(null, tile);
        };

        tile.onerror = function() {
            console.log("Тайл НЕ найден:", url);
            tile.style.visibility = "hidden";
            done(null, tile);
        };

        return tile;
    }
});

const papyrus = new PapyrusLayer({
    tileSize: 256,
    noWrap: true
});

papyrus.addTo(map);

console.log("PISPOP-GIS: слой PapyrusCS добавлен");


// Показываем небольшую область,
// чтобы Leaflet точно запросил тайлы.

map.setView([0, 0], 0);


// Координаты

const coordinates =
    document.getElementById("coordinates");

map.on("mousemove", function(event) {

    const x = Math.round(event.latlng.lng);
    const z = Math.round(-event.latlng.lat);

    coordinates.textContent =
        `X: ${x}    Z: ${z}`;
});