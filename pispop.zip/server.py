"""
PISPOP-GIS сервер.

Раздаёт статику (карту, веб-интерфейс) и предоставляет простое
REST API для системы меток, территорий, дорог, улиц и домов.

Данные хранятся в JSON-файлах на диске (data/*.json).
"""

import json
import os
import re
import threading
import uuid
import hashlib
import secrets
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8080"))

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MARKERS_FILE = DATA_DIR / "markers.json"
TERRITORIES_FILE = DATA_DIR / "territories.json"
ROADS_FILE = DATA_DIR / "roads.json"
STREETS_FILE = DATA_DIR / "streets.json"     
HOUSES_FILE = DATA_DIR / "houses.json"        
WATER_FILE = DATA_DIR / "water.json"
USERS_FILE = DATA_DIR / "users.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
PHOTOS_DIR = DATA_DIR / "photos"
PHOTOS_DIR.mkdir(parents=True, exist_ok=True)

DATA_DIR.mkdir(exist_ok=True)

_lock = threading.Lock()

MARKERS_RE = re.compile(r"^/api/markers/([A-Za-z0-9_\-]+)$")
TERRITORIES_RE = re.compile(r"^/api/territories/([A-Za-z0-9_\-]+)$")
STREETS_RE = re.compile(r"^/api/streets/([A-Za-z0-9_\-]+)$")      
HOUSES_RE = re.compile(r"^/api/houses/([A-Za-z0-9_\-]+)$")        
WATER_RE = re.compile(r"^/api/water/([A-Za-z0-9_\-]+)$")

SESSIONS = {}
SESSION_LOCK = threading.Lock()

def load_sessions():
    if not SESSIONS_FILE.exists():
        return {}
    try:
        with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}

def save_sessions():
    _write_json(SESSIONS_FILE, SESSIONS)

with SESSION_LOCK:
    SESSIONS.update(load_sessions())

def load_users():
    return _read_json(USERS_FILE, [])

def save_users(users):
    _write_json(USERS_FILE, users)

def _hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 210000).hex()
    return salt, digest

def _verify_password(password, user):
    salt = user.get("salt", "")
    expected = user.get("passwordHash", "")
    _, digest = _hash_password(password, salt)
    return secrets.compare_digest(digest, expected)

def _username_valid(username):
    return bool(re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9_\-]{3,32}", username or ""))


def _read_json(path: Path, default):
    if not path.exists():
        return default
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return default


def _write_json(path: Path, data):
    tmp = path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def load_markers():
    return _read_json(MARKERS_FILE, [])


def save_markers(markers):
    _write_json(MARKERS_FILE, markers)


def load_territories():
    return _read_json(TERRITORIES_FILE, [])


def save_territories(territories):
    _write_json(TERRITORIES_FILE, territories)


def load_water():
    return _read_json(WATER_FILE, [])


def save_water(zones):
    _write_json(WATER_FILE, zones)


DEFAULT_ROADS_DATA = {
    "version": 1,
    "project": "PISPOP-GIS",
    "description": "Ручная разметка дорожной сети",
    "roadTypes": {
        "ice": {
            "name": "Ледяная дорога",
            "color": "#8cbbd9",
            "routing": True
        }
    },
    "roads": []
}


def load_roads():
    data = _read_json(ROADS_FILE, None)

    if data is None:
        return dict(DEFAULT_ROADS_DATA)

    if not isinstance(data, dict):
        return dict(DEFAULT_ROADS_DATA)

    if "roads" not in data or not isinstance(data["roads"], list):
        data["roads"] = []

    return data


def save_roads(data):
    _write_json(ROADS_FILE, data)


# ============================================================
# НОВЫЕ ФУНКЦИИ ДЛЯ УЛИЦ И ДОМОВ
# ============================================================

def load_streets():
    """Загружает список улиц из streets.json"""
    return _read_json(STREETS_FILE, [])


def save_streets(streets):
    """Сохраняет список улиц в streets.json"""
    _write_json(STREETS_FILE, streets)


def load_houses():
    """Загружает список домов из houses.json"""
    return _read_json(HOUSES_FILE, [])


def save_houses(houses):
    """Сохраняет список домов в houses.json"""
    _write_json(HOUSES_FILE, houses)


def _safe_photo_part(value):
    return re.sub(r"[^A-Za-z0-9_-]", "_", str(value))[:120]

def _parse_multipart_file(handler):
    ctype = handler.headers.get("Content-Type", "")
    m = re.search(r"boundary=(?:\"([^\"]+)\"|([^;]+))", ctype)
    if not m:
        return None, None, "multipart boundary missing"
    boundary = (m.group(1) or m.group(2)).encode("utf-8")
    length = int(handler.headers.get("Content-Length", "0"))
    raw = handler.rfile.read(length)
    marker = b"--" + boundary
    for part in raw.split(marker):
        if b"Content-Disposition:" not in part:
            continue
        head, sep, body = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        md = re.search(br'filename="([^"]+)"', head)
        if not md:
            continue
        filename = md.group(1).decode("utf-8", "replace")
        if body.endswith(b"\r\n"):
            body = body[:-2]
        return filename, body, None
    return None, None, "file missing"


class PISPOPHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    # ------------------------------------------------------------------
    # utils
    # ------------------------------------------------------------------

    def _cors_headers(self):
        origin = self.headers.get("Origin")
        # Credentials cannot be used with Access-Control-Allow-Origin: *.
        # Return the requesting origin when present; otherwise use the local app origin.
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        else:
            self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:8080")
        self.send_header("Access-Control-Allow-Credentials", "true")

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            return None

    def log_message(self, format, *args):
        print("PISPOP-GIS:", format % args)

    # ------------------------------------------------------------------
    # CORS preflight
    # ------------------------------------------------------------------

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors_headers()
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    # ------------------------------------------------------------------
    # AUTH / SESSION
    # ------------------------------------------------------------------

    def _current_user(self):
        cookie = SimpleCookie()
        cookie.load(self.headers.get("Cookie", ""))
        token = cookie.get("pispop_session")
        if not token:
            return None
        client_ip = self.client_address[0]
        with SESSION_LOCK:
            session = SESSIONS.get(token.value)
        if not session:
            return None
        if isinstance(session, str):
            session = {"user_id": session, "ip": client_ip}
        if session.get("ip") and session.get("ip") != client_ip:
            return None
        with _lock:
            return next((u for u in load_users() if u.get("id") == session.get("user_id")), None)

    def _auth_json(self, status, payload, token=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors_headers()
        if token:
            self.send_header("Set-Cookie", f"pispop_session={token}; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax")
        self.end_headers()
        self.wfile.write(body)

    def _require_admin(self):
        user = self._current_user()
        if not user or user.get("role") != "admin":
            self._send_json(401 if not user else 403, {"error": "admin_required"})
            return None
        return user

    # ------------------------------------------------------------------
    # GET
    # ------------------------------------------------------------------

    def do_GET(self):
        # Photos are stored outside the web/ directory. Serve them explicitly
        # from the project ROOT so this works regardless of the process cwd.
        if self.path.startswith("/data/photos/"):
            rel = self.path[len("/data/photos/"):].split("?", 1)[0]
            # Prevent path traversal; only marker-id/filename is allowed.
            parts = [x for x in rel.split("/") if x]
            if len(parts) == 2 and all(re.fullmatch(r"[A-Za-z0-9_.-]+", x) for x in parts):
                photo = PHOTOS_DIR / parts[0] / parts[1]
                try:
                    resolved = photo.resolve()
                    photos_root = PHOTOS_DIR.resolve()
                    if resolved.is_file() and photos_root in resolved.parents:
                        data = resolved.read_bytes()
                        ctype = {
                            ".png": "image/png",
                            ".jpg": "image/jpeg",
                            ".jpeg": "image/jpeg",
                            ".webp": "image/webp",
                        }.get(resolved.suffix.lower(), "application/octet-stream")
                        self.send_response(200)
                        self.send_header("Content-Type", ctype)
                        self.send_header("Content-Length", str(len(data)))
                        self.send_header("Cache-Control", "public, max-age=31536000")
                        self.end_headers()
                        self.wfile.write(data)
                        return
                except OSError:
                    pass
            self.send_error(404, "Photo not found")
            return

        if self.path == "/api/auth/me":
            user = self._current_user()
            self._send_json(200, {"authenticated": bool(user), "user": ({"id": user["id"], "username": user["username"], "role": user["role"], "avatar": user.get("avatar", "👤"), "avatarData": user.get("avatarData"), "bio": user.get("bio", "") } if user else None)})
            return

        if self.path == "/" or self.path == "/index.html":
            self.send_response(302)
            self.send_header("Location", "/web/index.html")
            self.end_headers()
            return

        if self.path == "/api/markers":
            with _lock:
                self._send_json(200, load_markers())
            return

        if self.path == "/api/territories":
            with _lock:
                self._send_json(200, load_territories())
            return

        if self.path == "/api/water":
            with _lock:
                self._send_json(200, load_water())
            return

        if self.path == "/api/roads":
            with _lock:
                self._send_json(200, load_roads())
            return

        # ======== НОВЫЕ GET-ЗАПРОСЫ ========
        if self.path == "/api/streets":
            with _lock:
                self._send_json(200, load_streets())
            return

        if self.path == "/api/houses":
            with _lock:
                self._send_json(200, load_houses())
            return
        # ===================================

        super().do_GET()

    # ------------------------------------------------------------------
    # POST (create)
    # ------------------------------------------------------------------

    def do_POST(self):
        mphoto = re.match(r"^/api/markers/([A-Za-z0-9_-]+)/photos$", self.path)
        if mphoto:
            if not self._require_admin():
                return
            marker_id = mphoto.group(1)
            filename, content, err = _parse_multipart_file(self)
            if err:
                self._send_json(400, {"error": err}); return
            ext = Path(filename).suffix.lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
                self._send_json(400, {"error": "unsupported_image_type"}); return
            if len(content) > 8 * 1024 * 1024:
                self._send_json(413, {"error": "image_too_large"}); return
            folder = PHOTOS_DIR / _safe_photo_part(marker_id)
            folder.mkdir(parents=True, exist_ok=True)
            out = folder / (uuid.uuid4().hex + ext)
            out.write_bytes(content)
            url = f"/data/photos/{_safe_photo_part(marker_id)}/{out.name}"
            with _lock:
                markers = load_markers()
                found = next((mk for mk in markers if mk.get("id") == marker_id), None)
                if not found:
                    out.unlink(missing_ok=True); self._send_json(404, {"error":"marker_not_found"}); return
                found.setdefault("photos", [])
                found["photos"].append(url)
                save_markers(markers)
            self._send_json(201, {"url": url})
            return

        if self.path == "/api/auth/register":
            body = self._read_json_body()
            username = (body or {}).get("username", "").strip()
            password = (body or {}).get("password", "")
            if not _username_valid(username) or len(password) < 6:
                self._send_json(400, {"error": "username_3_32_and_password_6_required"})
                return
            with _lock:
                users = load_users()
                if any(u.get("username", "").lower() == username.lower() for u in users):
                    self._send_json(409, {"error": "username_taken"})
                    return
                role = "admin" if not users else "user"
                salt, digest = _hash_password(password)
                user = {"id": f"user-{uuid.uuid4().hex[:12]}", "username": username, "role": role, "salt": salt, "passwordHash": digest, "avatar": (body or {}).get("avatar") or "👤", "avatarData": (body or {}).get("avatarData")}
                users.append(user)
                save_users(users)
            token = secrets.token_urlsafe(32)
            with SESSION_LOCK:
                SESSIONS[token] = {"user_id": user["id"], "ip": self.client_address[0]}
                save_sessions()
            self._auth_json(201, {"authenticated": True, "user": {"id": user["id"], "username": username, "role": role, "avatar": user.get("avatar", "👤"), "avatarData": user.get("avatarData"), "bio": user.get("bio", "") }}, token)
            return

        if self.path == "/api/auth/login":
            body = self._read_json_body()
            username = (body or {}).get("username", "").strip()
            password = (body or {}).get("password", "")
            with _lock:
                user = next((u for u in load_users() if u.get("username", "").lower() == username.lower()), None)
                valid = bool(user and _verify_password(password, user))
            if not valid:
                self._send_json(401, {"error": "invalid_credentials"})
                return
            token = secrets.token_urlsafe(32)
            with SESSION_LOCK:
                SESSIONS[token] = {"user_id": user["id"], "ip": self.client_address[0]}
                save_sessions()
            self._auth_json(200, {"authenticated": True, "user": {"id": user["id"], "username": user["username"], "role": user["role"], "avatar": user.get("avatar", "👤"), "avatarData": user.get("avatarData"), "bio": user.get("bio", "") }}, token)
            return

        if self.path == "/api/profile":
            user = self._current_user()
            if not user:
                self._send_json(401, {"error":"auth_required"}); return
            body = self._read_json_body() or {}
            with _lock:
                users = load_users()
                found = next((u for u in users if u.get("id")==user.get("id")), None)
                if not found:
                    self._send_json(404, {"error":"user_not_found"}); return
                if "bio" in body: found["bio"] = str(body.get("bio") or "")[:300]
                if "avatarData" in body:
                    av = body.get("avatarData")
                    if av is not None:
                        if not isinstance(av,str) or not av.startswith("data:image/png;base64,") or len(av)>3_000_000:
                            self._send_json(400,{"error":"invalid_avatar"}); return
                        found["avatarData"] = av
                save_users(users)
                safe={"id":found["id"],"username":found["username"],"role":found["role"],"avatar":found.get("avatar","👤"),"avatarData":found.get("avatarData"),"bio":found.get("bio","")}
            self._send_json(200,{"user":safe}); return

        if self.path == "/api/auth/logout":
            cookie = SimpleCookie(); cookie.load(self.headers.get("Cookie", "")); token = cookie.get("pispop_session")
            if token:
                with SESSION_LOCK:
                    SESSIONS.pop(token.value, None)
                    save_sessions()
            self.send_response(204); self.send_header("Set-Cookie", "pispop_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"); self.end_headers()
            return

        if not self._require_admin():
            return

        if self.path == "/api/markers":
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            if "x" not in body or "z" not in body:
                self._send_json(400, {"error": "x and z are required"})
                return

            marker = {
                "id": body.get("id") or f"marker-{uuid.uuid4().hex[:10]}",
                "x": body["x"],
                "z": body["z"],
                "title": body.get("title", ""),
                "description": body.get("description", ""),
                "address": body.get("address", ""),
                "category": body.get("category", "default"),
                "color": body.get("color", "#e63946"),
                "createdAt": body.get("createdAt"),
                "updatedAt": body.get("updatedAt"),
                "photos": body.get("photos", []) if isinstance(body.get("photos", []), list) else [],
                "ownerId": (self._current_user() or {}).get("id"),
            }

            with _lock:
                markers = load_markers()
                markers.append(marker)
                save_markers(markers)

            self._send_json(201, marker)
            return

        if self.path == "/api/territories":
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            if "coordinates" not in body:
                self._send_json(400, {"error": "coordinates are required"})
                return

            territory = {
                "id": body.get("id") or f"territory-{uuid.uuid4().hex[:10]}",
                "name": body.get("name", "Без названия"),
                "description": body.get("description", ""),
                "category": body.get("category", "residential"),
                "coordinates": body["coordinates"],
                "fillColor": body.get("fillColor", "rgba(70,130,180,0.18)"),
                "borderColor": body.get("borderColor", "#4682b4"),
                "labelX": body.get("labelX"),
                "labelZ": body.get("labelZ"),
            }

            with _lock:
                territories = load_territories()
                territories.append(territory)
                save_territories(territories)

            self._send_json(201, territory)
            return

        if self.path == "/api/water/replace":
            body = self._read_json_body()

            if body is None or not isinstance(body.get("zones"), list):
                self._send_json(400, {"error": "zones are required"})
                return

            incoming = body.get("zones", [])
            if len(incoming) > 500:
                self._send_json(400, {"error": "too_many_water_zones"})
                return

            clean = []
            for index, zone in enumerate(incoming):
                if not isinstance(zone, dict):
                    continue
                coords = zone.get("coordinates")
                if not isinstance(coords, list) or len(coords) < 3 or len(coords) > 500:
                    continue
                valid = True
                normalized = []
                for point in coords:
                    if not isinstance(point, (list, tuple)) or len(point) < 2:
                        valid = False
                        break
                    try:
                        x = float(point[0])
                        z = float(point[1])
                    except (TypeError, ValueError):
                        valid = False
                        break
                    normalized.append([round(x, 2), round(z, 2)])
                if not valid:
                    continue
                clean.append({
                    "id": str(zone.get("id") or f"water-auto-{uuid.uuid4().hex[:10]}"),
                    "name": str(zone.get("name") or ""),
                    "coordinates": normalized,
                    "source": str(zone.get("source") or "auto")[:40],
                    "sourceImage": str(zone.get("sourceImage") or "")[:200],
                })

            with _lock:
                save_water(clean)

            self._send_json(200, {"ok": True, "count": len(clean)})
            return

        if self.path == "/api/water":
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            if "coordinates" not in body:
                self._send_json(400, {"error": "coordinates are required"})
                return

            zone = {
                "id": body.get("id") or f"water-{uuid.uuid4().hex[:10]}",
                "name": body.get("name", ""),
                "coordinates": body["coordinates"],
            }

            with _lock:
                zones = load_water()
                zones.append(zone)
                save_water(zones)

            self._send_json(201, zone)
            return

        # ======== НОВЫЙ POST ДЛЯ УЛИЦ ========
        if self.path == "/api/streets":
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            if "coordinates" not in body or not isinstance(body["coordinates"], list):
                self._send_json(400, {"error": "coordinates are required"})
                return

            street = {
                "id": body.get("id") or f"street-{uuid.uuid4().hex[:10]}",
                "name": body.get("name", "Новая улица"),
                "coordinates": body["coordinates"],
                "color": body.get("color", "#e8a87c"),
                "createdAt": body.get("createdAt"),
            }

            with _lock:
                streets = load_streets()
                streets.append(street)
                save_streets(streets)

            self._send_json(201, street)
            return
        # ===================================

        # ======== НОВЫЙ POST ДЛЯ ДОМОВ ========
        if self.path == "/api/houses":
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            if "streetId" not in body or "x" not in body or "z" not in body:
                self._send_json(400, {"error": "streetId, x and z are required"})
                return

            house = {
                "id": body.get("id") or f"house-{uuid.uuid4().hex[:10]}",
                "streetId": body["streetId"],
                "streetName": body.get("streetName", "Улица"),
                "number": body.get("number", 1),
                "x": body["x"],
                "z": body["z"],
                "color": body.get("color", "#e8c35c"),
                "createdAt": body.get("createdAt"),
            }

            with _lock:
                houses = load_houses()
                houses.append(house)
                save_houses(houses)

            self._send_json(201, house)
            return
        # ===================================

        self._send_json(404, {"error": "not found"})

    # ------------------------------------------------------------------
    # PUT (update)
    # ------------------------------------------------------------------

    def do_PUT(self):
        if not self._require_admin():
            return
        if self.path == "/api/roads":
            body = self._read_json_body()

            if body is None or not isinstance(body, dict):
                self._send_json(400, {"error": "invalid json"})
                return

            if "roads" not in body or not isinstance(body["roads"], list):
                body["roads"] = []

            with _lock:
                save_roads(body)

            self._send_json(200, body)
            return

        # ======== НОВЫЙ PUT ДЛЯ УЛИЦ (сохранение всего файла) ========
        if self.path == "/api/streets":
            body = self._read_json_body()

            if body is None or not isinstance(body, list):
                self._send_json(400, {"error": "invalid json, expected array"})
                return

            with _lock:
                save_streets(body)

            self._send_json(200, body)
            return
        # ===================================

        # ======== НОВЫЙ PUT ДЛЯ ДОМОВ (сохранение всего файла) ========
        if self.path == "/api/houses":
            body = self._read_json_body()

            if body is None or not isinstance(body, list):
                self._send_json(400, {"error": "invalid json, expected array"})
                return

            with _lock:
                save_houses(body)

            self._send_json(200, body)
            return
        # ===================================

        m = MARKERS_RE.match(self.path)
        if m:
            marker_id = m.group(1)
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            with _lock:
                markers = load_markers()
                found = None

                for marker in markers:
                    if marker["id"] == marker_id:
                        marker.update(body)
                        marker["id"] = marker_id
                        found = marker
                        break

                if not found:
                    self._send_json(404, {"error": "marker not found"})
                    return

                save_markers(markers)

            self._send_json(200, found)
            return

        t = TERRITORIES_RE.match(self.path)
        if t:
            territory_id = t.group(1)
            body = self._read_json_body()

            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            with _lock:
                territories = load_territories()
                found = None

                for territory in territories:
                    if territory["id"] == territory_id:
                        territory.update(body)
                        territory["id"] = territory_id
                        found = territory
                        break

                if not found:
                    self._send_json(404, {"error": "territory not found"})
                    return

                save_territories(territories)

            self._send_json(200, found)
            return

        self._send_json(404, {"error": "not found"})

    # ------------------------------------------------------------------
    # DELETE
    # ------------------------------------------------------------------

    def do_DELETE(self):
        if not self._require_admin():
            return

        # Удаление одной фотографии из метки. Работает и для старых
        # data:image... фотографий, и для новых файлов /data/photos/....
        mphoto = re.match(r"^/api/markers/([A-Za-z0-9_-]+)/photos(?:\?(.+))?$", self.path)
        if mphoto:
            marker_id = mphoto.group(1)
            query = mphoto.group(2) or ""
            from urllib.parse import parse_qs, unquote
            params = parse_qs(query, keep_blank_values=True)
            photo_url = unquote((params.get("url") or [""])[0])
            if not photo_url:
                self._send_json(400, {"error": "photo_url_required"})
                return

            with _lock:
                markers = load_markers()
                found = next((mk for mk in markers if mk.get("id") == marker_id), None)
                if not found:
                    self._send_json(404, {"error": "marker_not_found"})
                    return

                photos = found.get("photos") if isinstance(found.get("photos"), list) else []
                if photo_url not in photos:
                    self._send_json(404, {"error": "photo_not_found"})
                    return

                found["photos"] = [photo for photo in photos if photo != photo_url]
                save_markers(markers)

                # Если это файл, удаляем и сам файл с диска.
                if photo_url.startswith("/data/photos/"):
                    rel = photo_url[len("/data/photos/"):].split("?", 1)[0]
                    parts = [x for x in rel.split("/") if x]
                    if len(parts) == 2 and all(re.fullmatch(r"[A-Za-z0-9_.-]+", x) for x in parts):
                        photo_file = PHOTOS_DIR / parts[0] / parts[1]
                        try:
                            resolved = photo_file.resolve()
                            if PHOTOS_DIR.resolve() in resolved.parents and resolved.is_file():
                                resolved.unlink()
                        except OSError:
                            pass

            self._send_json(200, {"deleted": photo_url, "markerId": marker_id})
            return

        m = MARKERS_RE.match(self.path)
        if m:
            marker_id = m.group(1)

            with _lock:
                markers = load_markers()
                new_markers = [mk for mk in markers if mk["id"] != marker_id]

                if len(new_markers) == len(markers):
                    self._send_json(404, {"error": "marker not found"})
                    return

                save_markers(new_markers)

            self._send_json(200, {"deleted": marker_id})
            return

        t = TERRITORIES_RE.match(self.path)
        if t:
            territory_id = t.group(1)

            with _lock:
                territories = load_territories()
                new_territories = [
                    tr for tr in territories if tr["id"] != territory_id
                ]

                if len(new_territories) == len(territories):
                    self._send_json(404, {"error": "territory not found"})
                    return

                save_territories(new_territories)

            self._send_json(200, {"deleted": territory_id})
            return

        w = WATER_RE.match(self.path)
        if w:
            water_id = w.group(1)

            with _lock:
                zones = load_water()
                new_zones = [z for z in zones if z["id"] != water_id]

                if len(new_zones) == len(zones):
                    self._send_json(404, {"error": "water zone not found"})
                    return

                save_water(new_zones)

            self._send_json(200, {"deleted": water_id})
            return

        # ======== НОВЫЙ DELETE ДЛЯ УЛИЦ ========
        s = STREETS_RE.match(self.path)
        if s:
            street_id = s.group(1)

            with _lock:
                streets = load_streets()
                new_streets = [st for st in streets if st["id"] != street_id]

                if len(new_streets) == len(streets):
                    self._send_json(404, {"error": "street not found"})
                    return

                save_streets(new_streets)

            self._send_json(200, {"deleted": street_id})
            return
        # ===================================

        # ======== НОВЫЙ DELETE ДЛЯ ДОМОВ ========
        h = HOUSES_RE.match(self.path)
        if h:
            house_id = h.group(1)

            with _lock:
                houses = load_houses()
                new_houses = [hs for hs in houses if hs["id"] != house_id]

                if len(new_houses) == len(houses):
                    self._send_json(404, {"error": "house not found"})
                    return

                save_houses(new_houses)

            self._send_json(200, {"deleted": house_id})
            return
        # ===================================

        self._send_json(404, {"error": "not found"})


if __name__ == "__main__":
    server = ThreadingHTTPServer((HOST, PORT), PISPOPHandler)

    print("=" * 50)
    print("PISPOP-GIS")
    print("=" * 50)
    print(f"http://127.0.0.1:{PORT}/web/")
    print(f"API:  http://127.0.0.1:{PORT}/api/markers")
    print(f"API:  http://127.0.0.1:{PORT}/api/territories")
    print(f"API:  http://127.0.0.1:{PORT}/api/roads")
    print(f"API:  http://127.0.0.1:{PORT}/api/streets")   # НОВЫЙ
    print(f"API:  http://127.0.0.1:{PORT}/api/houses")    # НОВЫЙ
    print("=" * 50)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nPISPOP-GIS stopped.")
        server.server_close()