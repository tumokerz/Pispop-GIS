(function () {

    "use strict";

    const SETTLEMENT_LABEL_MIN_LEVEL = 3;
    const SETTLEMENT_LABEL_MAX_LEVEL = 6;
    const TERRITORY_CATEGORIES = [
        { id: "residential", label: "Населённый пункт", color: "#457b9d", icon: "🏘️" }
    ];

    const SETTLEMENT_LABEL_COLOR = "#1f2430";
    const SETTLEMENT_LABEL_FONT = "600 14px 'Inter', Arial, sans-serif";

    const SETTLEMENT_TERRITORY_FILL = "rgba(60,130,246,0.16)";
    const SETTLEMENT_TERRITORY_BORDER = "#3c82f6";
    const SETTLEMENT_TERRITORY_WIDTH = 3;

    const API_BASE =
        window.PISPOP_API_BASE || "";

    let map = null;

    let labelSource = null;
    let labelLayer = null;

    let territorySource = null;
    let territoryLayer = null;

    let selectedSettlement = null;

    let initialized = false;
    let settlements = [];


    /* ========================================================
       ЗАГРУЗКА / СОХРАНЕНИЕ С СЕРВЕРА
       ======================================================== */

    async function fetchTerritories() {

        try {

            const response =
                await fetch(API_BASE + "/api/territories");

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            const data = await response.json();

            return Array.isArray(data) ? data : [];

        } catch (error) {

            console.error(
                "PISPOP-GIS: не удалось загрузить территории:",
                error
            );

            return [];

        }

    }


    async function createTerritoryOnServer(territory) {

        const response =
            await fetch(API_BASE + "/api/territories", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(territory)

            });

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }


    async function updateTerritoryOnServer(id, patch) {

        const response =
            await fetch(
                API_BASE + "/api/territories/" + encodeURIComponent(id),
                {
                    method: "PUT",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify(patch)
                }
            );

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }


    async function deleteTerritoryOnServer(id) {

        const response =
            await fetch(
                API_BASE + "/api/territories/" + encodeURIComponent(id),
                { method: "DELETE" }
            );

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        return response.json();

    }

    function polygonCentroid(coordinates) {

        if (!Array.isArray(coordinates) || coordinates.length === 0) {
            return [0, 0];
        }

        let x = 0;
        let z = 0;

        coordinates.forEach(function (point) {
            x += point[0];
            z += point[1];
        });

        return [x / coordinates.length, z / coordinates.length];

    }

    function getMap() {

        if (
            window.unmined &&
            window.unmined.map &&
            typeof window.unmined.map.getView === "function"
        ) {
            return window.unmined.map;
        }

        if (
            window.unmined &&
            window.unmined.olMap &&
            typeof window.unmined.olMap.getView === "function"
        ) {
            return window.unmined.olMap;
        }

        if (window.unmined) {

            const keys = Object.keys(window.unmined);

            for (let i = 0; i < keys.length; i++) {

                const value = window.unmined[keys[i]];

                if (
                    value &&
                    typeof value.getView === "function" &&
                    typeof value.addLayer === "function"
                ) {
                    return value;
                }

            }

        }

        return null;

    }


    /* ========================================================
       ПРЕОБРАЗОВАНИЕ КООРДИНАТ
       ======================================================== */

    /*
     * Смотри пояснение в ui.js/markers.js: карта хранит
     * геометрию в "view"-проекции, а Minecraft X/Z —
     * в "data"-проекции. Без transform координаты неверны.
     */

    function toViewCoordinate(dataCoordinate) {

        if (
            !window.unmined ||
            !window.unmined.viewProjection ||
            !window.unmined.dataProjection
        ) {
            return dataCoordinate;
        }

        return ol.proj.transform(
            dataCoordinate,
            window.unmined.dataProjection,
            window.unmined.viewProjection
        );

    }


    /* ========================================================
       СТИЛЬ НАЗВАНИЯ
       ======================================================== */

    function settlementLabelStyle(feature) {

        return new ol.style.Style({

            text: new ol.style.Text({

                text: feature.get("name"),
                font: SETTLEMENT_LABEL_FONT,

                fill: new ol.style.Fill({
                    color: SETTLEMENT_LABEL_COLOR
                }),

                stroke: new ol.style.Stroke({
                    color: "rgba(255,255,255,0.85)",
                    width: 3
                }),

                padding: [6, 10, 6, 10],
                offsetY: -4,
                overflow: true,
                textAlign: "center",
                textBaseline: "middle"

            })

        });

    }


    /* ========================================================
       СТИЛЬ ТЕРРИТОРИИ
       ======================================================== */

    function settlementTerritoryStyle(feature) {

        const fillColor =
            (feature && feature.get("fillColor")) ||
            SETTLEMENT_TERRITORY_FILL;

        const borderColor =
            (feature && feature.get("borderColor")) ||
            SETTLEMENT_TERRITORY_BORDER;

        return new ol.style.Style({

            fill: new ol.style.Fill({
                color: fillColor
            }),

            stroke: new ol.style.Stroke({
                color: borderColor,
                width: SETTLEMENT_TERRITORY_WIDTH,
                lineDash: [10, 7]
            })

        });

    }


    /* ========================================================
       СОЗДАНИЕ СЛОЁВ
       ======================================================== */

    function createLayers() {

        labelSource = new ol.source.Vector();

        labelLayer = new ol.layer.Vector({
            source: labelSource,
            zIndex: 100001,
            style: settlementLabelStyle,
            visible: false
        });

        territorySource = new ol.source.Vector();

        territoryLayer = new ol.layer.Vector({
            source: territorySource,
            zIndex: 100000,
            style: settlementTerritoryStyle
        });

        map.addLayer(territoryLayer);
        map.addLayer(labelLayer);

    }


    /* ========================================================
       СОЗДАНИЕ НАЗВАНИЙ
       ======================================================== */

    function createSettlementLabels() {

        labelSource.clear();

        settlements.forEach(function (settlement) {

            if (!settlement) {
                return;
            }

            let x = settlement.labelX;
            let z = settlement.labelZ;

            if (
                typeof x !== "number" ||
                typeof z !== "number"
            ) {

                const centroid =
                    polygonCentroid(settlement.coordinates);

                x = centroid[0];
                z = centroid[1];

            }

            const feature = new ol.Feature({

                geometry: new ol.geom.Point(toViewCoordinate([x, z])),
                settlementId: settlement.id,
                name: settlement.name

            });

            labelSource.addFeature(feature);

        });

    }


    /* ========================================================
       ПОЛУЧЕНИЕ MAX ZOOM
       ======================================================== */

    function getMaxZoom() {

        if (!map) {
            return null;
        }

        const view = map.getView();

        if (!view) {
            return null;
        }

        const maxZoom = view.getMaxZoom();

        if (
            typeof maxZoom !== "number" ||
            !Number.isFinite(maxZoom)
        ) {
            return null;
        }

        return maxZoom;

    }


    /* ========================================================
       ПОКАЗ НАЗВАНИЙ
       ======================================================== */

    function updateLabels() {

        if (!map || !labelLayer) {
            return;
        }

        const view = map.getView();

        if (!view) {
            return;
        }

        const zoom = view.getZoom();

        if (
            typeof zoom !== "number" ||
            !Number.isFinite(zoom)
        ) {
            return;
        }

        const maxZoom = getMaxZoom();

        if (typeof maxZoom !== "number") {

            labelLayer.setVisible(false);

            return;

        }

        /*
         * Пользовательская шкала зума: 1 (максимально близко) —
         * 6 (максимально далеко), совпадает с техническими
         * уровнями OpenLayers 1:1 (maxZoom = уровень 1).
         *
         * Название населённого пункта видно на уровнях
         * 3-6 этой шкалы — не при сильном приближении.
         */

        const userLevel = maxZoom - zoom + 1;

        const shouldShow =
            userLevel >= SETTLEMENT_LABEL_MIN_LEVEL &&
            userLevel <= SETTLEMENT_LABEL_MAX_LEVEL;

        labelLayer.setVisible(shouldShow);

    }


    /* ========================================================
       ПОКАЗ ТЕРРИТОРИИ
       ======================================================== */

    function showTerritory(settlement) {

        if (!map || !territorySource) {
            return;
        }

        territorySource.clear();

        if (!settlement) {
            return;
        }

        if (!Array.isArray(settlement.coordinates)) {

            console.warn(
                "PISPOP-GIS: у населённого пункта нет полигона:",
                settlement
            );

            return;

        }

        const viewCoordinates =
            settlement.coordinates.map(toViewCoordinate);

        const geometry =
            new ol.geom.Polygon([viewCoordinates]);

        const feature = new ol.Feature({

            geometry: geometry,
            settlementId: settlement.id,
            settlementName: settlement.name,
            fillColor: settlement.fillColor,
            borderColor: settlement.borderColor

        });

        territorySource.addFeature(feature);

        selectedSettlement = settlement;

        document.dispatchEvent(
            new CustomEvent("pispop:territory-opened", {
                detail: settlement
            })
        );

    }


    /* ========================================================
       СКРЫТИЕ ТЕРРИТОРИИ
       ======================================================== */

    function hideTerritory() {

        if (territorySource) {
            territorySource.clear();
        }

        selectedSettlement = null;

        document.dispatchEvent(
            new CustomEvent("pispop:territory-closed")
        );

    }


    /* ========================================================
       ПОИСК НАСЕЛЁННОГО ПУНКТА
       ======================================================== */

    function findSettlementById(id) {

        return settlements.find(function (settlement) {
            return settlement.id === id;
        }) || null;

    }


    /* ========================================================
       КЛИК ПО НАЗВАНИЮ
       ======================================================== */

    function setupClick() {

        map.on("singleclick", function (event) {

            if (window.PISPOP_ROUTES && window.PISPOP_ROUTES.isPicking()) {
                return;
            }

            if (!labelLayer || !labelLayer.getVisible()) {
                return;
            }

            let clickedSettlement = null;

            map.forEachFeatureAtPixel(

                event.pixel,

                function (feature, layer) {

                    if (layer !== labelLayer) {
                        return false;
                    }

                    const id = feature.get("settlementId");

                    if (!id) {
                        return false;
                    }

                    clickedSettlement = findSettlementById(id);

                    return true;

                }

            );

            if (!clickedSettlement) {
                return;
            }

            if (
                selectedSettlement &&
                selectedSettlement.id === clickedSettlement.id
            ) {

                hideTerritory();

                return;

            }

            showTerritory(clickedSettlement);

        });

    }


    /* ========================================================
       ZOOM LISTENER
       ======================================================== */

    function setupZoomListener() {

        const view = map.getView();

        if (!view) {
            return;
        }

        view.on("change:resolution", updateLabels);

    }


    /* ========================================================
       ЗАГРУЗКА ДАННЫХ И ПЕРВИЧНАЯ ОТРИСОВКА
       ======================================================== */

    async function reload() {

        settlements = await fetchTerritories();

        createSettlementLabels();
        updateLabels();

        document.dispatchEvent(
            new CustomEvent("pispop:territories-loaded", {
                detail: settlements
            })
        );

    }


    /* ========================================================
       ИНИЦИАЛИЗАЦИЯ
       ======================================================== */

    async function initialize() {

        if (initialized) {
            return true;
        }

        map = getMap();

        if (!map) {
            return false;
        }

        createLayers();
        setupClick();
        setupZoomListener();

        await reload();

        initialized = true;

        console.log("PISPOP-GIS: settlements.js подключён.");

        return true;

    }


    /* ========================================================
       ОЖИДАНИЕ КАРТЫ
       ======================================================== */

    let attempts = 0;
    const MAX_ATTEMPTS = 100;

    function waitForMap() {

        attempts++;

        initialize().then(function (ok) {

            if (ok) {
                return;
            }

            if (attempts >= MAX_ATTEMPTS) {
                console.error("PISPOP-GIS: карта не найдена.");
                return;
            }

            setTimeout(waitForMap, 200);

        });

    }


    /* ========================================================
       ПУБЛИЧНЫЙ API
       ======================================================== */

    window.PISPOP_SETTLEMENTS = {

        categories: TERRITORY_CATEGORIES,

        show: function (settlement) {
            showTerritory(settlement);
        },

        hide: function () {
            hideTerritory();
        },

        getSettlements: function () {
            return settlements;
        },

        getSelected: function () {
            return selectedSettlement;
        },

        refresh: function () {
            return reload();
        },

        /*
         * Создать новую территорию (полигон) на сервере
         * и сразу перерисовать список.
         *
         * polygon: { name, description, coordinates, fillColor, borderColor }
         */
        create: async function (polygon) {

            const centroid = polygonCentroid(polygon.coordinates);

            const payload = Object.assign(
                {
                    labelX: centroid[0],
                    labelZ: centroid[1]
                },
                polygon
            );

            const created = await createTerritoryOnServer(payload);

            await reload();

            return created;

        },

        update: async function (id, patch) {

            const updated = await updateTerritoryOnServer(id, patch);

            await reload();

            return updated;

        },

        remove: async function (id) {

            const result = await deleteTerritoryOnServer(id);

            if (selectedSettlement && selectedSettlement.id === id) {
                hideTerritory();
            }

            await reload();

            return result;

        }

    };


    /* ========================================================
       СТАРТ
       ======================================================== */

    waitForMap();

}());

